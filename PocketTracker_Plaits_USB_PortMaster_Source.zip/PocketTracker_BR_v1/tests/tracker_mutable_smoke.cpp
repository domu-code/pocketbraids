#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include "audio-engine.h"
#include "songcore/voice_derive.h"
#include "songcore/project_io.h"
#include "ui/modules/instrument_editor.h"

static uint32_t bits(float f) { uint32_t u; std::memcpy(&u,&f,4); return u; }
int main(int argc, char** argv) {
    for (auto type : {songcore::InstrumentType::MACRO, songcore::InstrumentType::RINGS}) {
        auto engine = std::make_unique<AudioEngine>();
        engine->setDeviceSampleRate(48000);
        engine->setOttDepthForRender(0);
        songcore::Instrument ins;
        ins.instrumentType=type;
        ins.macroModel = type==songcore::InstrumentType::MACRO ? 42 : 1;
        songcore::InstrumentPreset preset; preset.instrument=ins;
        auto restored=songcore::parse_instrument_preset(songcore::json::parse(songcore::serialize_instrument_preset(preset))).instrument;
        if(restored.instrumentType!=type || restored.macroModel!=ins.macroModel ||
           restored.macroTimbre!=ins.macroTimbre || restored.grainSize!=ins.grainSize ||
           restored.grainPosition!=ins.grainPosition || restored.macroColor!=ins.macroColor)return 5;
        auto program=songcore::make_program(restored,1.f,-1);
        engine->setProgram(0,program,nullptr,0);
        songcore::NoteOnPayload note{};
        note.note=57; note.velocity=127; note.velGainBits=bits(1.f);
        note.volGainBits=bits(.75f); note.panBits=bits(.5f);
        note.start=note.slice=note.tableId=note.tableRow=-1;
        engine->scheduleProgramNote(0,0,0,note,120);
        double energy=0;
        float output[512];
        for(int block=0;block<100;++block) {
            engine->processLiveBlock(output,256,2,48000.f);
            for(float x:output) { if(!std::isfinite(x)){std::printf("Nonfinite type %d block %d\n",int(type),block);return 1;} energy+=double(x)*x; }
        }
        if(energy<1e-8){std::puts("FAIL: silent tracker synth route");return 2;}
        engine->scheduleNoteOff(25600,0);
        for(int block=0;block<30;++block)engine->processLiveBlock(output,256,2,48000.f);
        double tail=0;for(float x:output)tail+=double(x)*x;
        if(tail>1e-6){std::puts("FAIL: synth note-off did not settle");return 3;}
        if(argc>1) {
            pt::ui::Canvas canvas;
            pt::ui::InstrumentEditorModule editor;
            pt::ui::InstrumentEditorState state{ins};state.cursorRow=6;
            editor.draw(canvas,10,10,state);
            std::string file=std::string(argv[1])+(type==songcore::InstrumentType::MACRO?"/braids.ppm":"/rings.ppm");
            FILE* f=std::fopen(file.c_str(),"wb");if(!f)return 4;
            std::fprintf(f,"P6\n640 480\n255\n");
            for(int i=0;i<640*480;++i){auto p=canvas.pixels()[i];unsigned char rgb[]={static_cast<unsigned char>(p>>16),static_cast<unsigned char>(p>>8),static_cast<unsigned char>(p)};std::fwrite(rgb,1,3,f);}
            std::fclose(f);
        }
    }
    std::puts("PASS: Braids and Rings play through tracker routing without samples, preset settings survive save/load, and notes stop on note-off.");
}
