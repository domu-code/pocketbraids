#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test_binary=$(mktemp)
trap 'rm -f "$test_binary"' EXIT
g++ -std=c++17 -O2 -I native -I native/vendor/mutable \
  tests/mutable_smoke.cpp \
  native/vendor/mutable/braids/{macro_oscillator,analog_oscillator,digital_oscillator,resources}.cc \
  native/vendor/mutable/rings/dsp/{part,fm_voice,resonator,string}.cc \
  native/vendor/mutable/rings/resources.cc \
  native/vendor/mutable/stmlib/{utils/random,dsp/units}.cc \
  -o "$test_binary"
"$test_binary"
