#include <cassert>
#include <cstdio>
#include <string>
#include "songcore/effects.h"
#include "ui/fx_helper.h"

int main() {
    using namespace songcore;
    const int codes[14] = {
        FX_BMD,FX_BTM,FX_BCL,FX_RMD,FX_RST,FX_RBR,FX_RDP,FX_RPO,
        FX_PMD,FX_PHA,FX_PTM,FX_PMO,FX_PDC,FX_PLG
    };
    for (int code : codes) {
        assert(effect_type_index(code) > 0);
        assert(effect_type_at(effect_type_index(code)) == code);
        assert(std::string(effect_name(code)) != "---");
        assert(pt::ui::fx_code_is_grouped(code));
    }
    assert(effect_value_max(FX_BMD)==46);
    assert(effect_value_max(FX_RMD)==5);
    assert(effect_value_max(FX_PMD)==23);
    const auto& layout = pt::ui::fx_layout_full();
    bool hasSynth = false;
    for (const auto& g : layout.groups) {
        if (std::string(g.title) == "SYNTH") {
            hasSynth=true;
            assert(g.codes.size()==15); // 14 commands plus ---
        }
    }
    assert(hasSynth);
    const auto& descriptions = pt::ui::effect_descriptions();
    assert(static_cast<int>(descriptions.size()) == EFFECT_TYPE_COUNT);
    for (int code: codes) {
       auto i = effect_type_index(code);
       assert(descriptions[static_cast<size_t>(i)].at(0).rfind(effect_name(code), 0) == 0);
    }
    std::puts("PASS: 14 Braids/Rings/Plaits FX codes, names, value ranges and picker group");
}
