#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BINARY="$(mktemp)"
trap 'rm -f "$BINARY"' EXIT
g++ -std=c++17 -O2 -I native tests/synth_fx_schema_smoke.cpp -o "$BINARY"
"$BINARY"
