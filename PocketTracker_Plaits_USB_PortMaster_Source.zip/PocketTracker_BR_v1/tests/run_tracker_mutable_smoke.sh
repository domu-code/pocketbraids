#!/usr/bin/env bash
set -euo pipefail
build_dir=$(realpath "${1:?Pass the existing host CMake build directory}")
cd "$(dirname "$0")/.."
test_binary=$(mktemp)
trap 'rm -f "$test_binary"' EXIT
g++ -std=c++17 -O2 -I native -I native/vendor/mutable \
  tests/tracker_mutable_smoke.cpp -o "$test_binary" -Wl,--start-group \
  "$build_dir/native/libpt-ui.a" "$build_dir/native/libsongcore.a" \
  "$build_dir/native/libpockettracker.a" "$build_dir/native/libopusfile.a" \
  "$build_dir/native/vendor/opus/libopus.a" "$build_dir/native/vendor/ogg/libogg.a" \
  "$build_dir/native/libfaad2.a" -Wl,--end-group -pthread -ldl -lm
"$test_binary"
