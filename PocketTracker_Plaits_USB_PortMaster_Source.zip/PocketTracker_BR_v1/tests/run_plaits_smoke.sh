#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PLAIT=native/vendor/mutable/plaits
[[ -f "$PLAIT/dsp/voice.cc" && -f "$PLAIT/resources.cc" ]] || {
  echo 'Plaits DSP missing, first run bash tools/fetch_plaits.sh' >&2
  exit 1
}
mapfile -d '' SOURCES < <(find "$PLAIT/dsp" -name '*.cc' -print0 | sort -z)
BINARY="$(mktemp)"
trap 'rm -f "$BINARY"' EXIT
g++ -std=c++17 -O2 -DTEST -I native -I native/vendor/mutable \
  tests/plaits_smoke.cpp "${SOURCES[@]}" "$PLAIT/resources.cc" \
  native/vendor/mutable/stmlib/{utils/random,dsp/units}.cc \
  -o "$BINARY"
"$BINARY"
