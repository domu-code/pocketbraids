// Host-side smoke test for the OFFICIAL Plaits DSP adapter, compiled only
// after tools/fetch_plaits.sh has retrieved the pinned original source.
#include <array>
#include <cmath>
#include <cstdio>
#include <memory>
#include "synth/plaits_voice.h"
int main() {
    auto p = std::make_unique<pt::synth::PlaitsVoice>();
    for (float rate : {44100.f, 48000.f}) {
        for (int model = 0; model < 24; ++model) {
            p->reset(model);
            double energy = 0.0;
            for (int sample = 0; sample < static_cast<int>(rate * 0.75f); ++sample) {
                float left = 0, right = 0;
                p->next(220.f, rate, model, .5f, .5f, .5f, .7f, .45f, left, right);
                if (!std::isfinite(left) || !std::isfinite(right)) {
                    std::fprintf(stderr, "Plaits model %d at %.0f Hz emitted NaN/Inf\n", model, rate);
                    return 1;
                }
                energy += double(left) * left + double(right) * right;
            }
            // Not every model necessarily emits a signal at every combination of settings,
            // so log silent configurations rather than falsely fail legitimate engines.
            if (energy < 1e-9) {
                std::fprintf(stderr, "WARNING: Plaits model %d silent at %.0f Hz with test patch\n", model, rate);
            }
        }
    }
    std::puts("PASS: all 24 original Plaits models produced finite samples at 44.1/48 kHz");
}
