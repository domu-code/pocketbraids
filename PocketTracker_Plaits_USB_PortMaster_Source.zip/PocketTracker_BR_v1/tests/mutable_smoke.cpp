#include <cmath>
#include <cstdio>
#include <memory>
#include "synth/braids_voice.h"
#include "synth/rings_voice.h"
int main() {
    auto b=std::make_unique<pt::synth::BraidsVoice>();
    auto r=std::make_unique<pt::synth::RingsVoice>();
    for(float rate : {44100.f,48000.f}) {
        for(int model=0;model<47;++model) {
            b->reset(model); double energy=0;
            for(int i=0;i<int(rate/2);++i) {
                float x=b->next(220.f,rate,model,.48f,.52f);
                if(!std::isfinite(x)) return 1;
                energy+=double(x)*x;
            }
            if(energy<1e-8) { std::printf("Silent Braids model %d\n",model); return 2; }
        }
        for(int model=0;model<6;++model) {
            r->reset(model); double energy=0;
            for(int i=0;i<int(rate);++i) {
                float l=0,rr=0;r->next(220.f,rate,model,.4f,.65f,.55f,.35f,l,rr);
                if(!std::isfinite(l)||!std::isfinite(rr))return 3;
                energy+=double(l)*l+double(rr)*rr;
            }
            if(energy<1e-8){std::printf("Silent Rings model %d\n",model);return 4;}
        }
    }
    std::puts("PASS: 47 Braids + 6 Rings models: finite, nonzero output at 44.1/48 kHz.");
}
