# USB audio and MIDI on PocketTracker BR

## USB MIDI out: already supported

The upstream PocketTracker code already supports EXTERNAL instrument tracks, MIDI channel, bank, program, note length and four MIDI CC slots. On Linux, the backend uses ALSA raw MIDI and discovers MIDI output ports. In the MIDI settings screen, select the output port; then choose an EXTERNAL instrument and its channel (1-16). Save the project and settings. A USB MIDI device will appear only when the RG28XX port is in USB host mode, its firmware supports the controller, and ALSA lists the USB MIDI endpoint. USB-C cable form alone does not guarantee host MIDI. No new MIDI backend was added in this revision.

## USB audio out: new opt-in host-device routing

For a compatible USB DAC or USB audio interface recognised by ALSA:

1. Find the ALSA device with `aplay -l` or `aplay -L` through SSH if available.
2. In `roms/ports/pockettracker_br/data/`, create `audio_device.txt`.
3. Put ONE ALSA device name on the first line, e.g. `plughw:CARD=Device,DEV=0`, replacing `Device` with the actual ALSA card name.
4. Restart PocketTracker BR. The launcher sets `SDL_AUDIODRIVER=alsa` and `AUDIODEV` for that run only.
5. Check `roms/ports/pockettracker_br/log.txt` to confirm the selected route and whether SDL fell back.
6. Delete or empty the file to return to the normal handheld audio path.

This route uses standard ALSA/SDL audio and the existing 48 kHz stereo engine. Availability and latency depend on the Knulli kernel, sound device, hub/OTG support and power supply. It does not create a virtual USB sound card on a connected computer. That **USB gadget audio** feature requires kernel USB Device Controller / configfs `u_audio` or equivalent and hardware device mode; not confirmed on RG28XX and NOT implemented.

## Compatibility

The launcher omits gptokeyb intentionally. No program type, effect ID or existing project serialization has been changed by this USB audio routing addition. The configuration is a plain file, not a new graphical settings menu.

## Additional synthesis engines

Braids and Rings are still the verified native engines in this BR source baseline. Plaits source files are not present in the supplied archive. New engines must be taken from an auditable upstream release, retain their licence and be exercised by audio, editor and ARM64 build tests before being labelled integrated. Potential upstream libraries include Mutable Plaits (MIT), DaisySP (MIT) and Soundpipe (MIT). Do not treat this package as including those ports.
