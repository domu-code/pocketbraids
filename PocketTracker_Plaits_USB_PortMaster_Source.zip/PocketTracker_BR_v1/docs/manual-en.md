# PocketTracker User Manual

**Manual revision:** 1.3  
**Covers:** PocketTracker 0.9.7

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [Installation](#2-installation)
3. [Interface Overview](#3-interface-overview)
4. [Navigation](#4-navigation)
5. [Controls Reference](#5-controls-reference)
6. [Song Structure](#6-song-structure)
7. [SONG Screen](#7-song-screen)
8. [CHAIN Screen](#8-chain-screen)
9. [PHRASE Screen](#9-phrase-screen)
10. [INSTRUMENT Screen](#10-instrument-screen)
11. [SAMPLE EDITOR Screen](#11-sample-editor-screen)
12. [TABLE Screen](#12-table-screen)
13. [GROOVE Screen](#13-groove-screen)
14. [SCALE Screen](#14-scale-screen)
15. [MODULATION Screen](#15-modulation-screen)
16. [MIXER Screen](#16-mixer-screen)
17. [EFFECTS Screen](#17-effects-screen)
18. [EQ EDITOR](#18-eq-editor)
19. [PROJECT Screen](#19-project-screen)
20. [SETTINGS Screen](#20-settings-screen)
21. [THEME EDITOR](#21-theme-editor)
22. [MIDI Screen](#22-midi-screen)
23. [Effects Reference](#23-effects-reference)
24. [Modulation Reference](#24-modulation-reference)
25. [File Management](#25-file-management)
26. [Workflow Tips](#26-workflow-tips)
27. [Configuration File (config.json)](#27-configuration-file-configjson)
28. [Appendix: Controls Cheat Sheet](#appendix-controls-cheat-sheet)

---

## 1. Introduction

PocketTracker is a sample-based music tracker for Android handhelds and budget Android devices. It is inspired by M8, LSDJ, and Little GP Tracker (LGPT/Picotracker), and designed to run natively at **640×480** — the resolution of devices like the Miyoo Flip.

**New to trackers?** A tracker is a music sequencer where notes are arranged in a grid, with time flowing downward. Each row is a step, each column carries a parameter (note, instrument, volume, effect). Songs are built by chaining together short patterns called **phrases**, grouped into **chains**, arranged in a **song**. Think of it as building music from small, reusable blocks.

PocketTracker stores everything in a single project file (`.ptp`). Sounds come from standard `.wav` files or **SoundFont (SF2 / SF3)** files that you load yourself — there are no bundled samples.

### Minimum requirements

- **Android** 8.0 (API 26) or later
- **RAM:** 512 MB
- **Screen:** 640×480 or larger
- **Controls:** Physical buttons or touchscreen

---

## 2. Installation

1. Download the latest `.apk` from the project releases page.
2. On your Android device, enable **Install from unknown sources** in Settings → Security.
3. Open the downloaded `.apk` and tap **Install**.
4. Launch the app and choose a folder for it to work in — see below. PocketTracker asks for **no permissions at all**.

### Choosing your folder

PocketTracker holds no storage permission, so it can only see folders you hand it. The first time you open a file browser — **PROJECT → LOAD**, or **LOAD** on the INSTRUMENT screen — it opens on a list with a single row:

```
> ADD FOLDER...
```

Press **A** on it. Android's own folder picker opens; pick a folder and confirm. That folder becomes PocketTracker's home, and the app creates its ten sub-folders inside it the moment it needs them:

```
Projects/  Samples/  Renders/  Soundfonts/  Instruments/  Themes/  Scales/  Grooves/  Reverbs/  Delays/
```

Anything already in the folder is left exactly as it is — so if you have used PocketTracker before, pick your existing `Documents/PocketTracker` and every project, sample and theme is where it was.

> [!TIP]
> You can add more folders at any time. Climb to the top of the browser — **R+LEFT**, or **A** on the `..` row, repeated until it stops — and you will see every folder you have granted, with `ADD FOLDER...` at the end — that is how you reach a sample library, an SD card or a video in DCIM that lives outside your home folder. Adding a folder never moves your projects: the home folder only changes when you change it yourself.

Android will not let any app be granted a whole volume (`Internal storage`) or the `Download` folder itself. Pick a real folder — `Documents/PocketTracker` is a tidy choice.

### Changing your home folder, and dropping one

That top-level list of granted folders is a screen with two gestures of its own, shown on its top bar whenever the cursor is on a folder:

| | |
|---|---|
| **SELECT + A** | **Make this the home folder.** The app's ten sub-folders move to it — meaning it starts *looking* in the new place; nothing on disk is moved or copied. Confirm with **A**. |
| **SELECT + B** | **Forget this folder.** Hands the access back to Android and removes the row. Confirm with **A**. |

The folder currently in use is marked `(HOME)`. One whose directory has been deleted or unplugged since you granted it is marked `(MISSING)` — the app will not use a missing folder as its home, and `SELECT + B` is how you clear the row.

> [!IMPORTANT]
> **FORGET is not DELETE.** It gives up a permission; every file in the folder stays exactly where it is, and you can grant the same folder again at any time. Nothing in this list can delete your files — `SELECT + B` means DELETE on ordinary files and folders, but on a granted folder it can only ever mean forget.

### Playing in the background

A song that is **playing** when you switch to another app or turn the screen off keeps playing, with a PocketTracker notification that has a **Stop** button. A stopped song stays stopped. On Android 13 and later the app asks once, on first launch, whether it may show notifications — without that permission the song still plays on, but the notification and its Stop are hidden.

### Sample files

PocketTracker has no bundled default samples — all instrument slots start empty. Copy your own `.wav` files into a folder you have granted, and load them from the **INSTRUMENT** screen using the file browser. SF2 and SF3 files are loaded the same way.

> Only the sound you have chosen is loaded, rather than the whole bank around it, so even a very large SoundFont costs about as much memory as the one instrument you are playing. Changing the PATCH row loads the new sound once you stop scrolling. The list of sounds inside a file opens straight away, however large the file is. SF3 stores its samples compressed, so its files are much smaller on disk and take a little longer to open.

### Project files

Below, `<home>` is the folder you chose above.

Projects are saved as `.ptp` files in:

```
<home>/Projects/
```

WAV exports are saved to:

```
<home>/Renders/
```

Resampled instruments and CHOP exports are saved to:

```
<home>/Samples/Resampled/
<home>/Samples/Chops/{name}/
```

On Linux, Windows and PortMaster handhelds there is no folder to choose: the app owns a `PocketTracker` folder of its own and the same ten sub-folders live in it.

---

## 3. Interface Overview

The entire UI renders at a fixed **640×480** pixel canvas, letterboxed on larger screens.

```
┌────────────────────────────────────────────────┐
│  VISUALIZER  (620×70 px)                       │
├──────────────────────────────┬─────────────────┤
│                              │  NAV MAP        │
│  MAIN EDITOR                 │  (80×105 px)    │
│  (varies by screen)          │                 │
│                              │  STATUS LINE    │
│                              │                 │
└──────────────────────────────┴─────────────────┘
```

**Visualizer** — the top bar displays real-time audio. It has six display modes you can switch in SETTINGS:

| Mode | What it shows |
|---|---|
| SCOPE | Classic oscilloscope waveform (ProTracker-style pixel dots) |
| FLAT | Blank bar (saves battery / CPU) |
| OCTA | Mini-scopes side by side, one per active track |
| OCTA.F | All 8 track scopes at once (active or not) |
| SPECT | 40-bin FFT spectrum |
| SPCT.P | FFT spectrum with peak-hold dots |

**Main editor** — the active screen (PHRASE, CHAIN, SONG, etc.).

**Navigation map** — a miniature 5×5 grid in the top-right showing your position in the screen layout.

**Status line** — brief messages (e.g., `SAVED`, `RESAMPLED TO INST 0C`) that auto-dismiss after a few seconds.

Some screens (SAMPLE EDITOR, EQ EDITOR, THEME EDITOR) open as full-screen overlays that temporarily replace the main layout.

> [!TIP]
> If you're on a low-power device and notice audio hiccups, switch the visualizer to **FLAT** — it disables the real-time waveform rendering and frees up CPU for the audio engine.

---

## 4. Navigation

All screens are arranged in a **5×5 grid**. Navigate by holding **R** and pressing the D-pad.

```
     Col 0      Col 1      Col 2      Col 3      Col 4
     ─────      ─────      ─────      ─────      ─────
Row 0  ---        ---       SCALE    INST POOL    ---
Row 1  PROJ       PROJ      GROOVE     MODS       ---
Row 2  SONG      CHAIN     PHRASE     INST       TABLE
Row 3                       MIXER
Row 4                      EFFECTS
```

> **SCALE** and **INST POOL** (Row 0) only appear in column 2 and 3 respectively.  
> **GROOVE** and **MODS** (Row 1) only appear in column 2 and 3 respectively.  
> **MIXER** and **EFFECTS** (rows 3–4) only appear in the column you are currently on — move left/right first, then navigate up/down.

| Combo | Action |
|---|---|
| R + RIGHT / LEFT | Move left / right along Row 2 |
| R + UP | Move to the screen above in the current column |
| R + DOWN | Move to the screen below in the current column |

The navigation map always shows where you are.

**Popup screens** — not in the grid, opened contextually:

| Screen | How to open |
|---|---|
| SAMPLE EDITOR | INSTRUMENT screen → **TYPE** row → cursor on **EDIT >** → **A** |
| EQ EDITOR | INSTRUMENT / INST.POOL / MIXER / EFFECTS → cursor on EQ cell → **A**. Close with **B**. |
| REVERB / DELAY | INSTRUMENT / INST.POOL / MIXER → cursor on a REV or DEL cell → **A**. The same cells as that section of EFFECTS. Close with **B**. |
| TIMESTRETCH | SAMPLE EDITOR → EFFECT row set to SYNC → cursor on **TSTRETCH** → **A**. Close with **B**. |
| SETTINGS | PROJECT screen → cursor on SETTINGS row → A |
| THEME EDITOR | SETTINGS screen → cursor on THEME row → A |

> [!NOTE]
> **A opens, B goes back.** On cells that lead to another screen — the **EQ** cell and the **NAME**
> cell on PROJECT/INSTRUMENT — a quick **tap of A** opens the editor, while **holding A + a direction**
> still edits the value on that same cell (e.g. the EQ slot number). The open fires when you *release* A,
> so a held A never opens by accident. Inside the EQ EDITOR, **B closes** it and **B + LEFT/RIGHT** still
> cycles the EQ preset slot.

---

## 5. Controls Reference

### 5.1 Button Layout

#### Physical gamepad (Android handhelds)

| Physical button | Function |
|---|---|
| D-pad | Move cursor |
| A | Confirm / Insert |
| B | Cancel / Delete |
| L | L modifier |
| R | R modifier |
| SELECT | Show help for the cell under the cursor; file-management modifier in the file browser; cancels the keyboard overlay |
| START | Play / Stop |

#### Keyboard (Bluetooth keyboard or testing on PC)

| Key | Function |
|---|---|
| W / S / A / D or Arrow keys | D-pad |
| K or Enter | A button |
| J or Escape | B button |
| U | L button |
| I | R button |
| Left Shift | SELECT |
| Spacebar | START |

Both keyboard and gamepad work simultaneously.

---

### 5.2 Basic Actions

| Input | Action |
|---|---|
| D-pad | Move cursor |
| A | Insert value (on an empty cell, inserts the last-used value) |
| B | Delete value / cancel |
| SELECT | Show help for the cell under the cursor; file-management modifier in the file browser; cancels the keyboard overlay |
| START | Play / Stop |

> [!TIP]
> Pressing **A** on an empty note cell re-inserts the last note you placed — same pitch, same instrument. This is the fastest way to place a drum pattern: move to the row, press A, move on.

#### Help on SELECT

Tap **SELECT** for help on the cell the cursor is on. **SETTINGS → HELP** chooses what you get:

- **SHORT** — the visualizer strip at the top of the screen becomes three lines describing the cell. Tap **SELECT** again, or press any other button, to put it away. On the sample editor it appears in place of the waveform. The file browser has no room for it, so there it shows nothing.
- **FULL** — a help screen over everything: the same text, and a longer description where one has been written. Any button closes it, and that press does nothing else.
- **OFF** — **SELECT** shows no help.

The strip uses the theme's **VIZ BG** and **VIZ WAVE** colours.

---

### 5.3 Value Editing — A + D-pad

Hold **A** and press a direction to edit the value under the cursor:

| Combo | Step |
|---|---|
| A + RIGHT | +1 (small step) |
| A + LEFT | −1 (small step) |
| A + UP | +16 / +1 octave (large step) |
| A + DOWN | −16 / −1 octave (large step) |
| A + B | Delete / clear value |

- **Key repeat is active:** hold the combo for ~400 ms and it starts repeating, speeding up to ~30/s. Both can be changed in `config.json` — see [section 27](#27-configuration-file-configjson).
- For **note values**, large step = ±12 semitones (one octave).
- For **hex byte values**, large step = ±0x10.
- Under a scale, a note's small step is the next note **of that scale** rather than the next semitone — see [section 14](#14-scale-screen). The large step stays a full octave.
- Where a cell is a short list rather than a number — theme presets, scales, SLICE, SOURCE, an on/off flag, the instrument TYPE — there is no large step, and **A + UP/DOWN walk the list exactly as A + RIGHT/LEFT do**.

---

### 5.4 Context Navigation — B + D-pad

Hold **B** and press LEFT/RIGHT to switch between items of the same type without leaving the screen:

| Screen | B + LEFT / RIGHT |
|---|---|
| CHAIN | Previous / next chain (00–FF) |
| PHRASE | Previous / next phrase (00–FF) |
| INSTRUMENT | Previous / next instrument (00–7F) |
| TABLE | Previous / next table (00–7F) |
| GROOVE | Previous / next groove (00–7F) |

On INSTRUMENT, MODULATION and TABLE, **B + UP/DOWN** jumps 16 at a time and stops at `00` and `7F`.

**`SETTINGS → NAV` is `SONG` by default**, and B + D-pad on CHAIN and PHRASE walks the arrangement instead
of the pools. The cursor becomes a song cell, and the chain or phrase you are looking at is whichever
one that cell holds — the CHAIN and PHRASE headers show it (`CHAIN 20  S01 T3`).

| Screen | B + LEFT / RIGHT | B + UP / DOWN |
|---|---|---|
| CHAIN | Nearest filled cell left / right in the same song row | Nearest filled cell up / down the same track, skipping empty rows |
| PHRASE | Nearest track left / right whose chain also has a phrase at this chain row | Previous / next filled row of the chain you are in |

Nothing to that side means the press does nothing. On PHRASE, plain UP/DOWN off step `00` or `0F` now
moves to the previous or next filled row of the chain instead of wrapping inside the same phrase, and
**R+RIGHT does nothing when the cell under the cursor is empty** — you reach a chain by putting it in
the song first.

> [!IMPORTANT]
> Under `NAV = SONG` a chain or phrase that is not placed in the arrangement cannot be opened at all.
> Nothing is lost — set NAV back to `POOL` and every slot is reachable again.

The other screens are unchanged: SONG still pages by 16, and INSTRUMENT, MODS, TABLE, GROOVE and
INST.POOL still walk their pools.

---

### 5.5 Screen Navigation — R + D-pad

Hold **R** and press a direction to move in the screen grid (see §4).

---

### 5.6 Copy / Paste

Works on PHRASE, CHAIN, SONG, and TABLE screens.

| Input | Action |
|---|---|
| L + B | Enter selection mode (tap again to cycle: CELL → ROW → SCREEN) |
| B (in selection) | Copy selection, exit selection mode |
| L + A (in selection) | Cut (copy + clear), exit selection mode |
| L + A (outside selection) | Paste clipboard at cursor |
| A + B (in selection) | Delete selection (no clipboard), exit selection mode |
| L + B + A | Deep-clone the chain or phrase under the cursor into the next free slot |
| L + R | Leave selection mode (nothing copied) |

**Selection increment:** In selection mode, **A + LEFT/RIGHT** increments or decrements all selected values simultaneously.

**Clearing the clipboard:** the copy buffer deliberately survives leaving a selection — you can select
again by accident without losing what you copied. Press **L + R** when you are *not* selecting to clear
it, which is also how you dismiss the clipboard readout in the top strip.

**L + R** also restores muted and soloed tracks (§5.7). It undoes one thing per press, most recent
first: if you muted a channel after making a selection, the first press brings the channel back and
the second clears the selection — and the other way round if the selection came last.

**Selection modes:**
- **CELL** — single cell under cursor
- **ROW** — full row (all columns)
- **SCREEN** — all rows visible

> [!TIP]
> Use **SCREEN** selection mode to duplicate an entire phrase or chain quickly: enter SCREEN mode → B to copy → navigate to an empty phrase/chain → L+A to paste.

---

### 5.7 Mute & Solo

Works on the SONG and MIXER screens, while playing or stopped.

| Input | Action |
|---|---|
| R + B | Mute / unmute the channel under the cursor |
| R + A | Solo / unsolo it |
| R + B or R + A over a selection | Applies to every track the selection covers |
| L + R | Restore full playback — every track and both send returns |

The sound stops the instant you press, notes already ringing included.

**Hold or latch.** Which button you let go of first decides what happens:

- release **R** first — the change stays;
- release **A** or **B** first — everything that chord did is undone.

So the same chord gives you a momentary drop you can hold through a bar, and a mute you set and walk
away from.

Soloing is additive: solo a second track and both play. A track that is muted stays silent even when
soloed.

A track that is making no sound draws its numbers dimmed — its chain IDs on SONG, its fader value on
MIXER — so soloing one track dims the other seven.

**The send returns.** On MIXER the chord also works on the REV and DEL strips. Muting one drops that
effect out of the mix; soloing one leaves you with just the reverb or just the delay, while the
tracks go on playing and feeding it.

---

### 5.8 Playback Controls

| Input | Action |
|---|---|
| START | Play / Stop (context-aware) |
| START on SONG | Play full song from top |
| START on CHAIN | Play current chain |
| START on PHRASE, INSTRUMENT, MODULATION, TABLE | Play current phrase (loops) |
| R + START on CHAIN, PHRASE, INSTRUMENT, MODULATION, TABLE | Play the whole song from the song row you came through |
| A + START on INSTRUMENT, MODULATION, TABLE | Preview current instrument |
| START on SAMPLE EDITOR | Preview edited sample |
| START on SONG in LIVE mode | Queue the chain under the cursor ([LIVE Mode](#live-mode)) |

---

## 6. Song Structure

PocketTracker organizes music in a four-level hierarchy:

```
PROJECT
  └── SONG  (8 tracks, each is a column of chain IDs)
        └── CHAIN  (up to 16 phrase references + per-row transpose)
              └── PHRASE  (16 steps)
                    └── STEP  (Note + Instrument + Volume + 3 FX slots)
```

- A **STEP** is a single note event with optional effects.
- A **PHRASE** is a short pattern of 16 steps — like a bar of music.
- A **CHAIN** is a sequence of up to 16 phrases. Each phrase slot can have a **transpose** value to shift pitch without duplicating the phrase.
- The **SONG** arranges chains across 8 tracks. All 8 start together on the row you press START from, and each then moves down its own column as its own chains end.
- A track moves down its column until it reaches an empty cell, then loops back to the top of the run of cells it is in and plays it again. A song row left empty on **all 8 tracks** therefore splits the arrangement into separate **parts**, and a part loops until you press STOP — so one project can hold several unrelated sketches that never play into each other.

> [!NOTE]
> Nothing waits for anybody. Two parts of different lengths drift apart as they loop, and a track
> whose cell is empty on the row you pressed START from stays silent for that run. To drop a track
> out for a few bars and bring it back in step, put a chain of empty phrases in those rows rather
> than leaving a gap.

All values (chain IDs, phrase IDs, instrument IDs, etc.) are hexadecimal, ranging from `00` to `FF`.

> [!NOTE]
> All values in PocketTracker are **hexadecimal** (base-16). Decimal 16 = hex `10`, decimal 255 = hex `FF`. The appendix at the end has a [conversion table](#hex--note-quick-reference).

---

## 7. SONG Screen

The SONG screen arranges chains across 8 tracks. Each column is a track (1–8), each row is a song position.

```
     1    2    3    4    5    6    7    8
00   04   --   08   --   --   01   --   --
01   04   --   08   --   --   01   --   --
02   05   --   09   --   --   02   --   --
```

`--` means the track is silent at that position. Numbers are chain IDs (hex).

During playback a `>` appears to the left of the cell each track is on. The eight move independently, so they are rarely all on the same row.

A `>` also marks the playing row on the CHAIN and PHRASE screens. It is only drawn where the screen is showing something that is actually playing — audition a phrase on its own and the chain and song screens stay unmarked, because that phrase need not belong to any chain.

### Controls

| Input | Action |
|---|---|
| D-pad | Move cursor |
| A | Insert last-used chain ID |
| A + LEFT/RIGHT | Increment / decrement chain ID |
| A + UP/DOWN | Increment / decrement by 16 |
| A + B | Delete (set to --) |
| B + UP/DOWN | Page up / down (jump 16 rows) |
| B + LEFT/RIGHT | Switch between SONG and LIVE mode |
| START | Play song from current row |

> [!TIP]
> You can start playback from any row — not just the beginning. Move the cursor to the row where you want playback to start, then press **START**. Useful for jumping to a specific section while mixing.

### LIVE Mode

Press **B + LEFT** or **B + RIGHT** on the SONG screen to switch between the two transport modes. The title changes from `SONG:` to `LIVE:`.

In LIVE mode the song grid is a scene launcher. Each channel plays one chain and repeats it until you queue something else, and START no longer starts or stops the transport — it queues.

| Input | Action |
|---|---|
| START | Queue the chain under the cursor on that channel |
| START again on the same cell | Start it at the next bar instead of waiting for the chain |
| L + START | Queue the whole cursor row — every channel at once |
| R + START | Queue the channel under the cursor to fall silent |
| B + LEFT/RIGHT | Back to SONG mode |

A queued launch blinks a `>` on the row it will jump to, while the solid `>` stays where the channel is now. A queued stop blinks a `_` in place of the channel's marker. Slow blink means it is waiting for the chain to end; fast blink means the next bar.

A blank cell in a queued row silences that channel, so a row sounds the way it looks. With the transport stopped, START and L+START begin playing immediately.

Switching modes never jumps or silences anything: each channel keeps its place, and starts repeating — or resumes walking down its column — from its next chain boundary. LIVE mode lasts for the session and is not saved with the project.

---

## 8. CHAIN Screen

A chain is a sequence of up to 16 phrase references. Each slot has:
- **PH** — phrase ID (`00`–`FF`) or `--` (empty)
- **TSP** — transpose in semitones (`00` = no transpose; values above `7F` are negative)

```
     PH   TSP
00   04   00
01   04   00
02   05   0C   ← +12 semitones (one octave up)
03   05   00
```

When played, the chain loops from slot 00 after the last filled slot.

### Controls

| Input | Action |
|---|---|
| D-pad | Move cursor |
| A | Insert last-used value |
| A + LEFT/RIGHT | Increment / decrement |
| A + UP/DOWN | ±16 (PH) or ±12 semitones (TSP) |
| A + B | Delete slot |
| B + LEFT/RIGHT | Switch to previous / next chain |
| START | Play current chain |

> [!TIP]
> Use **TSP** to play the same phrase at multiple pitches without copying it. One phrase can become a verse, chorus, and bridge by giving it different TSP values across chain slots — `07` = +7 semitones (a perfect fifth up), `0C` = +12 (one octave up).

---

## 9. PHRASE Screen

The phrase editor has 16 rows (steps 00–0F) and 5 columns:

```
     N    V    I    FX1      FX2      FX3
00   C-4  80   03   ---  00  ---  00  ---  00
01   ---  --   --   ---  00  ---  00  ---  00
02   E-4  80   03   ARP  47  ---  00  ---  00
```

| Column | Meaning |
|---|---|
| N | Note (`C-4`, `F#3`, etc.). `---` = no note. |
| V | Volume (`00`–`FF`). Always set — `FF` = full, applied on top of instrument VOL. |
| I | Instrument ID (`00`–`7F`). Always set — no empty state. |
| FX1/FX2/FX3 | Effect type + value (e.g., `RPT 03`, `ARP 47`) |

Notes are written as pitch + octave: `C-4`, `C#4`, `D-4`, … `G-9`. Range is **C-0 to G-9**. Middle C = `C-4` (MIDI note 60).

### Controls

| Input | Action |
|---|---|
| D-pad | Move cursor |
| A | Insert last-used note / value |
| A + LEFT/RIGHT | +1 / −1 semitone (note — or the next note of the scale, see [section 14](#14-scale-screen)), +1 / −1 (other values) |
| A + UP/DOWN | ±1 octave (note), ±16 (other values) |
| A + B | Delete value at cursor |
| A + B on an empty note | Insert **OFF** — the note sounding on the track is let go |
| B + LEFT/RIGHT | Switch to previous / next phrase |
| L + D-pad | Fill rows from the cell under the cursor — see *Fill* below |
| START | Play current phrase (loops) |

### Fill

Hold **L** and press a direction to fill rows from one cell, without
typing each row.

| Input | Action |
|---|---|
| L + RIGHT | Repeat the top row on every 8th, 6th, 4th, 3rd, 2nd row, then on every row |
| L + LEFT | Spread 3, 5, 6, 7, 9, 11 or 13 copies of the top row evenly over the range |
| L + UP | Give every value in the range a new random one |
| L + DOWN | Put the top row on random rows of the range |

**What is filled.** With no selection: the cell under the cursor, from its row down to the end of the
phrase. A note takes its volume and instrument with it, and a command its value. In a selection: the
selected columns, from the selection's top row down to its last.

**L + RIGHT** steps along this line and wraps round:

`as it was` → `8` → `6` → `4` → `3` → `2` → `every row` → `ramp`

**L + LEFT** steps along its own, counted in notes rather than rows:

`as it was` → `3` → `5` → `6` → `7` → `9` → `11` → `13`

That many copies are placed as evenly as they fit, the first on the top row — 5 over a whole phrase
land on rows `00`, `03`, `06`, `09` and `0C`. Each button starts from the phrase as it was, so a press
of one replaces what the other placed.

Rows the fill does not land on are left as they were. A spacing too wide for the range is skipped, and
so is a count that does not fit it or that lands on the same rows as one of the spacings.

**Ramp** is offered in a selection whose first and last rows hold different values in the same column.
The rows between are stepped evenly from one to the other — volume `10` on the first row and `50` on
the fifth gives `20`, `30`, `40` between. Notes ramp in the row's scale. An FX value ramps when both
ends hold the same command; a row that holds a different command there is left alone.

**L + UP** rolls again on every press. Each column draws between the lowest and highest value it
holds in the range. When they are all the same, notes are drawn from the octave above, and volumes and
FX values from their whole range. Notes stay in the row's scale; FX commands are never changed.

**Undo.** `as it was` puts back the phrase from before the first press. It is kept until you move the
cursor or edit something else.

> [!TIP]
> Put a kick on the first row and press **L + RIGHT** three times for a kick on every 4th row. For a
> melody, type one note, fill every 2nd row, then press **L + UP** until you like it.

### FX columns

Each FX slot has two parts: **type** (3-letter code) and **value** (2-digit hex). Use A+LEFT/RIGHT on the type to step through the available effects one at a time, or A+UP/DOWN to open the effect picker. A on an empty type inserts the effect you entered last, with its value. Effects are listed in §23.

The picker groups the commands by what they act on — **SEQUENCE**, **INSTRUMENT**, **GLOBAL** and **MIDI** — and keeps one group open at a time. A closed group shows `→` after its name, the open one `↓`. Move past the last row of a group and the next one opens; every group starts with `---`, which clears the slot. Keep holding A while you look — the description above the grid follows the cursor — and release A on the command you want.

> [!WARNING]
> Some effects (**ARP**, **RPT**, **PBN**, **PVB**, **PVX**) **persist across steps that have no note** — they keep running on empty rows. They are cancelled by: a new note on the same track, any effect in the same FX column, setting the effect to `00`, or **KIL**.

The mixer faders written from a phrase (**VTR**, **VMV**) persist differently: they are not attached to a
note at all, so nothing cancels them but the next `VTR`/`VMV` — and stopping playback, which puts the
faders back to the values on the MIXER screen.

**AUS** and **AUF** are the only effects the grid can draw **dimmed**, in the colour of an empty cell.
That means the pair did not come out: the fade will not play, and §23 lists the reasons. A pair that
works stays lit even when its two halves are in different phrases of the same chain.

---

## 10. INSTRUMENT Screen

The INSTRUMENT screen configures how a sample or SF2 preset is played, or what an outside MIDI device is sent.

Navigate here with **R+RIGHT** from PHRASE. Use **B+LEFT/RIGHT** to switch between instruments without leaving the screen, and **B+UP/DOWN** to jump 16 at a time.

### WAV instrument parameters

| Parameter | Range | Description |
|---|---|---|
| TYPE | — | The instrument kind, with two buttons to the right of its value. **LOAD** opens the file browser; **EDIT >** opens the SAMPLE EDITOR. Press **A** on either. ⚠️ **EDIT >** is not drawn on a SoundFont — there is no single waveform to edit — and an EXTERNAL instrument has neither button. |
| NAME | — | Instrument name. Press A to edit it on the keyboard overlay. |
| ROOT | C-0 – G-9 | The pitch of the sample as recorded. |
| DETUNE | 00–FF | Fine tuning. `80` = center (no detune). |
| VOL | 00–FF | Base volume. `FF` = full. |
| TSP | ON / OFF | Between VOL and PAN. `OFF` takes this instrument out of **every** note transposition — the scale on its track, the chain transpose column and the project TRANSPOSE setting. Turn it off for a drum kit whose slots you have pitched by hand. |
| PAN | 00–FF | Stereo pan. `00` = full left, `80` = center, `FF` = full right. |
| START | 00–FF | Sample start point (fraction of sample length). |
| END | 00–FF | Sample end point. |
| LOOP | OFF / FWD / PNG | Loop mode: off, forward, ping-pong. |
| LOOP ST | 00–FF | Loop start point (fraction of sample length). |
| LOOP END | 00–FF | Loop end point. `FF` = sample end. Loop region is [LOOP ST, LOOP END] — see below. |
| REVERSE | OFF / ON | Reverse playback. |
| SLICE | OFF / CUT / TRU | Slice playback mode (see below). |
| FILTER | LP / HP / BP / OFF | Resonant SVF filter type. |
| CUT | 00–FF | Filter cutoff frequency. `FF` = open. |
| RES | 00–FF | Filter resonance. `00` = none. |
| DRIVE | 00–FF | Soft-clipping overdrive. `00` = off. |
| CRUSH | 00–FF | Bit-depth crusher. `00` = off. |
| EQ | — | Press A to open the EQ EDITOR for this instrument. A + LEFT/RIGHT picks the EQ slot. |

> [!TIP]
> **ROOT** is the most important tuning parameter. Set it to the actual pitch of your sample (e.g., `A-4` for a 440 Hz sine). If notes sound in the wrong octave, ROOT is usually the reason.

> [!TIP]
> **DRIVE** and **CRUSH** are subtle at low values (`10`–`30`) and very aggressive near `FF`. Both are per-instrument — start low and increase by ear.

### SF2 instrument parameters

When the loaded file is a SoundFont, additional override fields appear for the preset's internal envelope and filter. Setting these to `--` uses the SoundFont's built-in values.

| Parameter | Description |
|---|---|
| ATK | Envelope attack time override |
| DEC | Envelope decay time override |
| SUS | Envelope sustain level override |
| REL | Envelope release time override |
| CUT | Filter cutoff override |
| RES | Filter resonance override |

### EXTERNAL instrument parameters

An EXTERNAL instrument makes no sound of its own: its notes are sent to the device on the MIDI screen's
OUTPUT row ([section 22](#22-midi-screen)). Choose it with A + D-pad on TYPE.

| Parameter | Range | Description |
|---|---|---|
| CHAN | 1–16 | The MIDI channel this instrument sends on. |
| BANK | `----` / 0000–3FFF | Bank select, sent just before PROG. `----` sends none. |
| PROG | `--` / 00–7F | Program change — the patch on the device. `--` sends none. BANK and PROG go out only while PROG CHG is ON on the MIDI screen. |
| LEN | 00–FF | How long each note is held, in ticks. `00` holds it until the next note on the track. |
| VOL | 00–FF | Scales the velocity of every note. |
| PAN | 00–FF | Sent as controller 10. |
| TSP | ON / OFF | As on a WAV instrument. |
| TIC | 00–FF | How fast this instrument's table runs, in ticks per table row. |
| CC A – CC D | `--` / 00–7F | Four controller slots, each a controller number and the **VAL** to send to it. A filled slot is sent with every note; `CCA`–`CCD` move it from a phrase (section 23). |
| BEND | 01–48 | How many semitones the device bends at full wheel. The pitch commands are scaled to it, and the device is told it before the first bend. A device that does not take that message needs the same number set on it. |

### Volume chain

Volume is applied in this order:

```
Instrument VOL × Phrase V column × Track volume (Mixer) × Master volume (Mixer)
```

> [!NOTE]
> If a note is unexpectedly silent, check all four stages of the volume chain: instrument VOL, phrase V column, track volume in MIXER, and master volume. Any one of them being `00` will silence the output.

**Where the reverb and delay sends sit in that chain.** A send is tapped after the instrument's own
volume — instrument VOL, the phrase `V` column and any VOL modulation — but *before* the track fader.
So turning a track down in the MIXER thins the dry signal while leaving its reverb and delay tails
where they were, which is the usual way to push a part back into the space rather than out of it.

The **master** fader is the exception, and works the way a master should: the send returns are summed
into the mix before it, so master volume takes the reverb and delay down with everything else. Pulling
the master to `00` really does end in silence, tails included.

The last two stages can also be written from a phrase: `VTR` replaces the track fader and `VMV` the
master one for as long as the song is playing (§23).

### Slice playback

When slice markers exist on the sample (set via the SAMPLE EDITOR), the SLICE parameter controls how notes select slices:

| Mode | Behaviour |
|---|---|
| OFF | Normal pitch playback — markers are ignored. |
| CUT | Note pitch selects a slice (C-4 relative to ROOT = slice 0). Plays from slice start to the next marker, then stops. |
| TRU | Same slice selection; plays from slice start to end of sample. |

### Loop region & release tail

When **LOOP** is FWD or PNG, playback flows **START → LOOP END** once, then repeats the region **[LOOP ST, LOOP END]**. The sample's **END** no longer bounds the loop — it bounds the *release tail*.

If the instrument also has an **ADSR** volume envelope (MODULATION screen), releasing the note — an **OFF** in the note column — leaves the loop and plays **LOOP END → END** once as the release tail, under the ADSR release stage. The sample therefore splits into three regions:

| Region | Role |
|---|---|
| START → LOOP ST | Intro — played once. |
| LOOP ST → LOOP END | Sustain loop — repeats while the note is held. |
| LOOP END → END | Release tail — played once on note-off (ADSR only). |

Without an ADSR envelope the loop repeats indefinitely until the voice is killed or stolen, and the release tail is never used.

> [!NOTE]
> Set **LOOP END** below **END** to reserve a release tail. Leaving **LOOP END = FF** makes the loop run to the sample end (the classic behaviour) with no separate tail.

### Navigating instruments

A project has **128 instrument slots**, `00`–`7F`, and in a new project every one of them is empty —
PocketTracker bundles no samples. An empty slot plays silence and is named `INST00` … `INST7F` until
you load something into it, at which point it takes the file's name unless you have typed one of your
own.

- **B + LEFT/RIGHT** — switch between instruments 00–7F
- **R+UP** from INSTRUMENT → MODULATION screen
- **A** on the TYPE row's **LOAD** button → opens the file browser
- **A** on the TYPE row's **EDIT >** button → opens the SAMPLE EDITOR

### File browser controls

| Input | Action |
|---|---|
| D-pad UP/DOWN | Move through files / folders |
| A | Load file or enter folder |
| A on `..` | Go up one directory level |
| R + LEFT | Go up one directory level |
| B | Close the browser |
| START | Preview highlighted audio (WAV / MP3 / FLAC / OGG / OPUS / M4A) or video file |

The browser can also manage files — see [section 25](#25-file-management).

A load that takes more than a moment puts a **LOADING** line across the top of the screen with the
file's name and how far along it is. **B** stops it: nothing is loaded, and the slot keeps what it
had. Cancelling a *project* load leaves you on an empty project. Quick loads show nothing at all.

Compressed audio (MP3 / FLAC / OGG / Opus / M4A) loads as a sample too — it decodes in place, with no
WAV written. Video files are instead **converted** to a WAV in the Samples folder. See §25 →
*Audio from video files*.

---

## 11. SAMPLE EDITOR Screen

The SAMPLE EDITOR is a full-screen waveform editor for the currently loaded WAV. Open it from the INSTRUMENT screen: on the **TYPE** row, move the cursor right past **LOAD** onto **EDIT >**, and press **A**.

Press **B** to close. If you have edited the waveform, B raises **ARE YOU SURE?** first — A discards the edit and leaves, B stays in the editor. Use **SAVE / OVERWRITE** inside the editor to write changes to disk. B is the only way out: R+DPAD cannot leave the editor, so an unsaved edit cannot be lost by walking off the screen.

### Waveform view

The waveform fills the top portion of the screen. A playback cursor shows the current read position during preview.

| Input | Action |
|---|---|
| R + UP/DOWN | Zoom in / out, from any row |
| A + LEFT/RIGHT | Zoom in / out (cursor on the ZOOM cell) |
| START | Preview current sample (respects SOURCE mode) |

Zoomed in, the view centres on the marker the cursor is on, and follows the playback cursor when the audio would leave the view.

### Selection

Move the selection start and end markers to define a region for operations.

| Input | Action |
|---|---|
| A + LEFT/RIGHT (on START or END) | Move that marker by a fine step |
| A + UP/DOWN | Move it by a coarse step |
| A + B | Put it back at the start / end of the sample |

A moved marker lands on the nearest **zero crossing** — the quietest place to cut, so a loop or a crop does not click. LEFT and RIGHT search their own channel, MONO the downmix, and STEREO looks for a frame where **both** channels are quiet.

### Non-destructive parameters

These change playback behaviour without modifying the waveform data:

| Parameter | Options | Description |
|---|---|---|
| SOURCE | LEFT / RIGHT / STEREO / MONO | Which channel(s) of a stereo WAV to use. Non-destructive — never alters the file. SAVE/OVERWRITE applies SOURCE at write time. Opens on **STEREO** whenever the file has a right channel; a mono file reads MONO and the cell cannot be moved. |
| RATE | HIGH / NORM / LOFI | Sample rate mode. NORM = original. LOFI = 8-bit lo-fi downsampling. |
| BIT | 32 / 24 / 16 / 8 | Bits per sample. Opens at the depth the file came in at, and offers only that depth and lower — a 16-bit file shows 16 / 8, a 24-bit one 24 / 16 / 8. Lower depths round the sound to coarser steps for grit. **SAVE, OVERWRITE and CHOP write the file at the depth shown.** It combines with RATE, and either can be set back while the editor is open. Not the instrument's CRUSH. |

### Destructive operations

These modify the waveform in memory (UNDO is available after each operation).

| Operation | Description |
|---|---|
| CROP | Trim sample to current selection. |
| COPY | Copy selection to clipboard. |
| CUT | Copy selection to clipboard and remove it — the sample gets shorter. |
| DUPL | Copy the selection and add it on to the end of the sample. |
| PASTE | Insert clipboard at selection start. |
| DEL | Remove the selection without copying it. |
| NORMALIZE | Scale amplitude so peak = 0 dBFS. |
| FADE IN | Apply a linear fade-in over the selection. |
| FADE OUT | Apply a linear fade-out over the selection. |
| SILENCE | Zero out the selection. |
| REVERSE | Reverse the selection. |
| UNDO | Revert to state before the last destructive operation. |

> [!WARNING]
> **UNDO** reverts only the **last single operation** — it is not a full history. If you apply NORMALIZE then FADE OUT, pressing UNDO reverts only the FADE OUT.

> [!WARNING]
> **OVERWRITE** writes to disk immediately and **cannot be undone**. Once you overwrite, the previous file content is permanently gone. Use **SAVE** (which creates a new numbered file) while experimenting, and only OVERWRITE when you are certain of the result.

### SYNC mode

SYNC applies time or pitch transformations to match the sample to the current project BPM.

The header shows the sample's own tempo beside its rate and length — the BPM it plays at if it holds
exactly the bar count on the DURATION row. When that number matches the project's TEMPO the sample is
already on the grid. `---BPM` means there is no sample, or that DURATION is set to a length this
sample cannot be.

| Sub-mode | Description |
|---|---|
| RPITCH | Pitch-shifts the selection to align its length to a target beat count, without changing duration. |
| TSTRETCH | Time-stretches the selection to a target beat duration without changing pitch. Uses SOLA (Synchronized Overlap-Add), Akai-cyclic mode — the same algorithm as the Akai S950/S1000. |

With SYNC on the EFFECT row, **START** plays the sample as APPLY would leave it.

**A** on TSTRETCH opens its settings. They stay as set after **B**, so APPLY on the EFFECT row uses
them too. **A+B** on TSTRETCH puts them all back.

| Cell | What it does |
|---|---|
| ORIG BPM | The sample's own tempo — the number in the header. |
| DURATION | The editor's DURATION cell. |
| NEW BPM | The tempo to fit to. Starts as the project's TEMPO; **A+B** puts it back. |
| PITCH | The editor's PITCH cell. The stretch moves the pitch by it and still lands on DURATION. |
| GRAIN | The length of each piece the sample is cut into, in milliseconds. `40` to begin with — shorter is grittier, longer is smoother. |
| PREVIEW | Plays the stretched sample without changing it. **START** does the same. |
| APPLY | Stretches the sample and closes the settings. |

### Offline FX

Applied to the whole sample (or selection) offline — rendered immediately, with UNDO available.

| FX | Description |
|---|---|
| EQ | Tap A on the slot cell to open the EQ EDITOR and dial it in; then APPLY bakes the EQ into the sample. `--` is no EQ. |
| DUST | Lo-fi effect chain: shelf EQ → low-pass → tube saturation → FET compression → wow/drift → bitcrush → soft-clip. |
| DRIVE | Soft-clipping overdrive. |
| OTT | 3-band bidirectional compressor. |

> [!TIP]
> The DUST offline FX is a great one-click "make it lo-fi" button for drum samples. Apply it to a clean break, then SAVE to a new file — you preserve the original and get the processed version as a separate instrument.

### Transient detection and slices

The SLICE row controls how slice markers are managed:

| Mode | Behaviour |
|---|---|
| OFF | Show existing WAV cue markers (read-only). No detection. |
| TRANSIENT | Run spectral-flux transient detection. SENS (`00`–`FF`) controls threshold. |
| DIVIDE | Divide the sample into equal slices. |
| MANUAL | Place the boundaries yourself. Opens on the sample's existing markers, or empty if it has none. No SENS/BY parameter. |

Slice markers are stored in the WAV `cue ` chunk — compatible with M8, Blackbox, Reaper, Logic, and Adobe Audition.

The row below shows which slice you are on and where it starts. Stepping it selects that slice, so you
can dial through them and hear each one with START.

### Moving and making slice boundaries

The **position** cell on that row is editable under every mode but OFF, so a detected transient or an
equal division can be nudged. **MANUAL** is the mode with no computed set of its own, and the only one
where a plain A makes a new boundary.

| Input | Action |
|---|---|
| A + LEFT/RIGHT | Move the boundary by a fine step |
| A + UP/DOWN | Move it by a coarse step |
| A + B | MANUAL: delete it. TRANSIENT / DIVIDE: put it back where the mode had placed it |
| A *(while the sample plays)* | MANUAL: cut a boundary at the playhead |

Both steps scale with the zoom, as the selection edges do, and a boundary lands on a zero crossing the same way.

Under MANUAL the slice counter reaches one past the last slice: that slot is the next boundary, sitting
on the one to its left, and moving it off is what creates it. A boundary may be dragged past its
neighbours — its number follows its position — and deleting one renumbers the rest.

**Chopping by ear:** with the cursor on that row, press START and tap A on every hit.

> [!NOTE]
> Anything that changes the sample's **length** — CROP, CUT, DUPL, PASTE, DEL, UNDO, a resizing SYNC —
> clears every slice boundary, including the ones the file arrived with.

**CHOP** — exports each slice as a separate WAV file to `Samples/Chops/{name}/`.

> [!TIP]
> After using CHOP, you need to manually load the individual slice files onto new instrument slots. There is no automatic batch-load — but using numbered filenames (which CHOP generates) makes the process fast.

### Save

| Action | Description |
|---|---|
| SAVE | Write to a new file (auto-incremented name). |
| OVERWRITE | Replace the existing file on disk. Applies SOURCE at write time (LEFT/RIGHT = mono export from that channel; STEREO = 2-channel WAV; MONO = averaged mono). |

---

## 12. TABLE Screen

A table is a 16-row micro-sequencer attached to an instrument. When a note plays, the table runs in parallel at a configurable tick rate, applying per-row transpose, volume, and effects.

Tables are great for: drum rolls, note slides, automatic arpeggios, per-note automation.

```
     N    VOL  FX1      FX2      FX3
00   00   --   ---  00  ---  00  ---  00
01   03   --   ---  00  ---  00  ---  00
02   07   --   ---  00  ---  00  ---  00
```

| Column | Range | Description |
|---|---|---|
| N | 00–FF | Transpose in semitones. `00` = no shift. Values above `7F` are negative (e.g., `FC` = −4 st). |
| VOL | 00–FF / -- | Volume multiplier for this row. `--` = no change. |
| FX1–FX3 | same as phrase | Effects applied on this table tick. |

### TIC rate

The header shows **XX TIC** — how many phrase ticks pass per table row. Use the **TIC** phrase effect to change this value.

- Default: `06` (6 ticks per row — two rows per phrase step)
- Lower values = table advances faster
- Special values: `00` = trigger mode, `FC` = octave map, `FE` = note map, `FF` = 200Hz mode

**TIC `00` — trigger mode.** The table advances one row **per note** instead of with time: each note
the track plays reads the next row down, so a sixteen-row table is a sixteen-note sequence. `HOP`
loops a section of it as usual, and PLAY, STOP and a render each start again from row `00`.

> [!TIP]
> Use **HOP** in the last row of a table section to loop just part of the table. For example: rows 00–03 with `HOP 00` in row 03 will loop those 4 rows indefinitely, ignoring rows 04–0F.

> [!NOTE]
> By default, instrument N uses table N. To override this per-note, place a **TBL XX** effect in the phrase FX column. The table switches immediately and stays active for subsequent notes on that track.

### Three playheads

Each FX column runs at its own speed and loops independently. There are three playheads, marked by a
`>` before each FX column. The FX1 playhead carries the N and VOL columns too, so it is also shown
beside the row number.

- **`HOP` steers only the column it is written in.** `HOP 00` in FX2 loops FX2 while N, VOL and FX1
  keep walking all sixteen rows.
- **`TIC` sets only that column's speed.** Write it in a column's last row to set that column's rate
  for the whole table, or anywhere else to change it as the playhead passes.
- **`HOP FF` stops only its own column.** The table ends when all three have stopped.

```
     N    VOL  FX1      FX2      FX3
00   00   --   CUT 40   ---  00   ---  00
01   00   --   CUT 60   HOP 00   ---  00   ← FX2 loops rows 00-01 for ever
…
0F   00   --   ---  00  TIC 03   ---  00   ← …twice as fast as everything else
```

Two columns at different rates give you cross-rhythms out of a single table — a filter moving in
threes under a volume moving in fours.

> [!NOTE]
> `THO` written in a **phrase** moves all three playheads, since it belongs to no column. `THO` inside
> the table moves the column it is typed in.

### Fades in a table

`AUS` and `AUF` work on a table row as they do on a phrase step (§23), with **rows** as the span:

```
     N    VOL  FX1      FX2      FX3
02   00   --   CUT 20   AUS 80   ---  00   ← start at 20, linear
0A   00   --   ---  00  AUF F0   ---  00   ← arrive at F0 eight rows later
```

A table `AUS` can move **VOL**, **PAN**, **CUT**, **RES**, **LPF**, **HPF**, **BPF**, **DRV**, **FIN**,
**TIM**, **EQN** and **EQM**; anything else to its left is
passed over. The fade follows the playhead of the column holding the value it is moving — `CUT` in
FX1 above, so that fade runs at FX1's speed whichever column the `AUS` sits in. **HOP steers it** —
back to the `AUS` row restarts it, into the middle picks it up there, past the `AUF` ends it. A `TIC`
change stretches it along with the rest of that column.

⚠️ A span never wraps past row `0F`: write the `AUF` on a later row than the `AUS`.

### Table–instrument link

By default, instrument N uses table N. Override per-note with the **TBL** phrase effect.

### Controls

| Input | Action |
|---|---|
| D-pad | Move cursor |
| A + LEFT/RIGHT | Edit value |
| A + B | Delete value |
| B + LEFT/RIGHT | Previous / next table |
| B + UP/DOWN | Jump 16 tables |
| L + B / copy / paste | Selection, copy, paste (same as phrase) |

---

## 13. GROOVE Screen

Groove controls the timing of each phrase step individually — this is how you create swing, shuffle, triplets, and other rhythmic feels.

Navigate here: **R+UP** from PHRASE or CHAIN (column 2).

A groove is a list of up to 16 tick values. The track cycles through the list: step 1 takes groove row 0 ticks, step 2 takes groove row 1 ticks, and so on. The list loops when exhausted.

```
GROOVE 00                     LEN: 2

     TIC        STRAIGHT
00   0C         SAVE  LOAD
01   0C         QNT   1/16
02   --         SWG   50.0%
03   --         PPQ   48
```

A new groove holds **two steps of 12 ticks**, which is the pair swing works on. It plays exactly the same as no groove at all, so a fresh groove changes nothing until you edit it. Clearing both rows with A+B gives an empty groove, which also plays even.

`00` is a real value and means **skip this row**: the phrase row is not played and takes no time. That is what makes triplets fit — see below.

### The panel

| Row | What it does |
|---|---|
| Name | The groove this slot was taken from. A+LEFT/RIGHT steps through the built-in grooves and loads the one you land on. **SAVE** and **LOAD** write and read groove files — see below. A `*` means the ticks no longer match the name. |
| QNT | The quantize pointer — see below. |
| SWG | Read-only. How long the first half of the group is, as a share of the whole. `50.0%` is even, `66.7%` is a triplet feel. It follows the **TIC** cursor, not the panel, so changing QNT never moves the number. |
| PPQ | How finely this groove's ticks count: **24**, **48** or **96** to the quarter note, which makes an even step `06`, `0C` or `18`. Changing it rewrites the ticks so the groove sounds the same — going down rounds them to the nearest tick, and a change that would push a step past `FF` is refused. It is this groove's own: the ticks that `LAT`, `KIL`, `RPT` and the other effects count in stay twelve to the step. |

### Swing example

```
     TIC
00   0E    ← 14 ticks (long)
01   0A    ← 10 ticks (short)
02   --
```

### Triplet example

Three triplets fill one beat, but a phrase always counts **four** rows to a beat. The fourth row is `00` — skipped, costing no time — so the three notes sit in the four-row space the grid already draws and the phrase stays the same length as every other track's:

```
     TIC
00   10
01   10
02   10
03   00    ← skipped: 16+16+16 = 48 ticks over 4 rows, same as 4 × 12
04   --
```

> [!NOTE]
> Sixteenth-note triplets cannot be written this way, and there is no preset for them. Three of them fill an *eighth*, which is only two rows — so they would need three played rows inside a two-row space, and a `00` can only ever add a row, never remove one. They are still possible by typing ticks by hand on a phrase whose length you have chosen to suit them.

### QNT — keeping the bar in place

Set it on the panel with A+LEFT/RIGHT, or with **B+UP/DOWN** from anywhere on the screen. It is an editing aid only: nothing is saved with the song, and it goes back to OFF when the app starts or a project loads.

| QNT | A+D-pad on a tick row |
|---|---|
| OFF | Moves that one step on its own. A+LEFT/RIGHT by 1, A+UP/DOWN by 16 |
| 1/16 · 1/8 · 1/4 · 1/2 | Moves the step by 1 **and its partner the other way by 1**, so the pair still adds up and the bar line does not shift |

Armed, both A axes do the same move of 1, because one tick is exactly one step on the classic swing ladder. Any edit that would push either side outside `00`–`FF` is refused outright rather than half-applied. OFF is what you want for lengthening a single step, or for typing a `00`.

### Built-in grooves, and groove files

The name row cycles a built-in list: **STRAIGHT**, the six `16TH` and six `8TH` swing settings (54 / 58 / 62 / 66 / 71 / 75, the same numbers drum machines have used since the MPC60 — each one tick apart), then **TRIPLET 8**, **TRIPLET 4**, **HALFTIME** and **DOUBLETIME**. Landing on one replaces every tick in the slot, so save a groove you have built before stepping off it.

**SAVE** names the slot and writes it to `PocketTracker/Grooves` as a `.ptg` file; **LOAD** reads one back into the slot you are looking at, with the PPQ it was written in. The built-ins are written into that folder the first time the app finds it empty, so they are there to edit, rename and copy between devices. Deleting the ones you do not use is permanent — the app does not put them back, and the name row still offers them all.

### Assigning grooves

Each track uses groove `00` by default. Use the **GRV XX** phrase effect to switch a track to groove `XX`.

> [!TIP]
> To reset a track back to even timing after a groove section, place `GRV 00` in an FX column. Groove `00` is empty by default, which plays perfectly even — but it is a real, editable groove: if you put tick values into groove `00`, every track that hasn't been assigned another groove will swing with it.

> [!WARNING]
> For the grooved track to stay in sync, each complete cycle of your groove list should **average 12 ticks per entry** (at PPQ 48 — 6 at 24, 24 at 96). A 2-entry swing sums to 24 (14+10 ✓). A 4-entry groove should sum to 48. If the average is not 12, the track drifts against un-grooved tracks within each phrase; in SONG mode all tracks re-align at every chain row, so an off-average groove produces a gap (or a cut) at the end of each phrase rather than unbounded drift.

### Controls

| Input | Action |
|---|---|
| D-pad UP/DOWN | Move between rows |
| D-pad RIGHT / LEFT | Move into the panel and back |
| A | On a `--` row, add an even step. On SAVE or LOAD, press the button |
| A + LEFT/RIGHT | Edit tick value. On the name row, step through the built-in grooves. On QNT or PPQ, change it |
| A + UP/DOWN | Edit tick value (large step) |
| A + B | Clear row. On the name row, back to STRAIGHT. On PPQ, back to 48 |
| B + UP/DOWN | Set QNT from anywhere on the screen |
| B + LEFT/RIGHT | Previous / next groove |

---

## 14. SCALE Screen

A scale is a set of notes. While a track is using one, every note it plays lands on the nearest note in that set — including notes you wrote before you chose the scale.

Navigate here: **R+UP** from GROOVE (column 2).

A project holds **16 scales**, numbered `00`–`0F`. Every track starts on scale `00`, which has all twelve notes switched on and so constrains nothing.

```
SCALE 00                 LEN: 7
MAJOR              SAVE  LOAD
KEY        C

       EN
0  C   >ON
1  C#   --
2  D   >ON
3  D#   --
4  E    ON
5  F    ON
6  F# >--
7  G    ON
8  G#   --
9  A    ON
A  A#   --
B  B    ON
```

| Field | Meaning |
|---|---|
| Name | The scale this slot was taken from. A+LEFT/RIGHT steps through the 38 built-in scales and loads the one you land on. **SAVE** and **LOAD** write and read scale files — see below. |
| KEY | The root the scale is built from. It belongs to the project rather than to the individual scale, so changing it re-labels every row and moves all 16 scales to the new key. |
| LEN | How many notes this scale contains. 7 is a mode, 5 a pentatonic, 12 no constraint at all. |
| Rows 0–B | The twelve intervals above the key, each `ON` or `--`. The note name beside each row is what that interval sounds like in the current key. |

Row 0 is the root and cannot be switched off, and neither can the last note still on.

The `>` marker shows a note that is sounding right now. Play a chromatic run under a five-note scale and you can watch it skip the rows that are off.

> [!NOTE]
> A marker on a row that is switched off is not a mistake — it means the note you are hearing is not in the scale on screen: that track is on a different scale, or the instrument is sliced, or its TSP is off.

### The built-in scales, and scale files

The name row cycles 38 built-in scales — the modes, the pentatonics, the bebop and diminished scales, and a set of Japanese and Indian ones. Landing on a name loads that scale's twelve notes into the slot.

Switching a note on or off afterwards leaves the name alone and puts a `*` in front of it, so `*MAJOR` is a major scale you have changed.

**SAVE** names the slot and writes it to `PocketTracker/Scales` as a `.pts` file; **LOAD** reads one back into the slot you are looking at. The 38 built-ins are written into that folder the first time the app finds it empty, so they are there to edit, rename and copy between devices. Deleting the ones you do not use is permanent — the app does not put them back, and the name row still offers all 38.

> [!NOTE]
> Cycling the name replaces all twelve notes. Save a scale you have built before stepping off it.

### What a scale changes

- **Typing.** A+LEFT/RIGHT on a note cell steps to the next note of the scale instead of the next semitone, and A on an empty cell inserts a note the scale contains.
- **Playing.** Every note the track plays lands on a note of the scale — including notes written before the scale existed, and notes moved by a chain transpose.
- **PIT and ARP.** The pitch offset and the arpeggio land in the scale too. Because each result goes to the *nearest* note in the scale, a small `PIT` under a narrow scale can leave a note exactly where it was rather than moving it.

Two things are left alone. **Sliced instruments are never moved** — there the note picks which slice of the sample to play rather than a pitch, so moving it would play a different slice. And any instrument whose **TSP** is `OFF` (INSTRUMENT screen, between VOL and PAN) is left exactly as written, which is how you keep a hand-pitched drum kit out of the scale.

### Choosing a scale for a track

Every track uses scale `00` until a phrase says otherwise. **SCA** moves one track, **SCG** moves all eight, and both carry a key as well as a scale number so a section can change key and scale on the same step. Both last until the next scale command or until playback stops.

While you are typing, the note cell follows the last `SCA` or `SCG` written **at or above** the cursor in the same phrase.

> [!NOTE]
> That look-up reads the phrase on screen and nothing else. A scale command in an earlier phrase of the same chain, or an `SCG` typed on another track, still applies when the song plays — but the note cell you are typing into will not know about it and will offer scale `00`.

### Controls

| Input | Action |
|---|---|
| D-pad UP/DOWN | Move between rows |
| D-pad LEFT/RIGHT | On the name row, move between the name, SAVE and LOAD |
| A + LEFT/RIGHT | Step through the built-in scales / change KEY / switch a note ON or off |
| A | On SAVE or LOAD, run it. Nothing on any other cell |
| A + B | On the name, put the slot back to Chromatic — all twelve notes on |
| A + UP/DOWN | Nothing — none of these cells has a large step |
| B + LEFT/RIGHT | Previous / next scale |

---

## 15. MODULATION Screen

The MODULATION screen (MODS) adds up to **4 modulation slots** per instrument. Each slot runs an envelope or LFO targeting a destination parameter — great for volume shapes, pitch vibrato, filter sweeps, and more.

Navigate here: **R+UP** from INSTRUMENT (column 3).

### Modulation types

| Type | Description |
|---|---|
| `---` | Off |
| AHD | One-shot envelope: Attack → Hold → Decay |
| ADSR | Envelope: Attack → Decay → Sustain → Release |
| DRUM | Percussive envelope: sharp peak → body hold → tail decay |
| LFO | Cyclic oscillator |
| TRIG | Envelope triggered by note, behaves like ADSR |

### Modulation destinations

| Dest | Affects |
|---|---|
| VOL | Amplitude |
| PAN | Stereo position |
| PITCH | Pitch in semitones |
| FINE | Fine pitch (same range as PITCH) |
| CUT | Filter cutoff |
| RES | Filter resonance |
| STA | Sample start point |
| MOD A | Depth of the next mod slot |
| MOD R | Speed of the next mod slot |
| MOD B | Both depth and speed of the next mod slot |

### Layout

The screen shows two mod slots side by side (MOD1+MOD2, then MOD3+MOD4).

**AHD parameters:** TYPE, DEST, AMT, ATK, HOLD, DEC

**ADSR / TRIG parameters:** TYPE, DEST, AMT, ATK, DEC, SUS, REL

**DRUM parameters:** TYPE, DEST, AMT, ATK (peak), HOLD (body), DEC

**LFO parameters:** TYPE, DEST, AMT, OSC, TRIG (trigger mode), FREQ

**LFO trigger modes:**
- FREE — runs on its own clock and never restarts
- RETG — starts the wave over on each new note
- HOLD — takes one value from the clock when the note starts and keeps it for the whole note
- ONCE — starts over on each new note, plays one cycle and stops there

**LFO shapes:** TRI, SIN, RMP+, RMP−, EXP+, EXP−, SQU+, SQU−, RND (jumps between random values), DRK (wanders)

### Mod-to-mod routing

When DEST is **MOD A**, **MOD R**, or **MOD B**, the slot modulates the next slot (circular: slot 4 → slot 1).

Example: MOD1 (LFO) with DEST=MOD A targeting MOD2 (AHD) — the LFO rhythmically swells the envelope depth.

> [!TIP]
> Mod-to-mod routing is **circular** — slot 4 targets slot 1. Plan your slot order before setting up complex chains: the modulator should always be a lower-numbered slot than its target, except for the wraparound case.

> [!TIP]
> **LFO RETG** mode resets the phase on every new note, giving a predictable and consistent modulation shape on each hit. Use **FREE** only when you want the LFO to drift independently of your notes — useful for slow pad movement but unpredictable on drums.

### Controls

| Input | Action |
|---|---|
| D-pad UP/DOWN | Move between parameters |
| D-pad LEFT/RIGHT | Switch between paired slots (MOD1↔MOD2 or MOD3↔MOD4) |
| A + LEFT/RIGHT | Edit value |
| A + UP/DOWN | Edit value (large step) |
| A + B | Reset to default |
| B + LEFT/RIGHT | Previous / next instrument |
| B + UP/DOWN | Jump 16 instruments |

---

## 16. MIXER Screen

The MIXER screen shows all 8 tracks, the two effect returns and the master strip, each with a real-time dBFS peak meter. This is where you balance levels, set how loud the reverb and delay come back, and shape the whole mix.

Navigate here: **R+DOWN** from any Row 2 screen.

```
  T1   T2   T3   T4   T5   T6   T7   T8   MASTER
  ██   ██   ██   ██   ██   ██   ██   ██    ██
  FF   FF   FF   FF   FF   FF   FF   FF

  REV  DEL                          MIX  FF
  ██   ██                           EQ   --
  80   80                           OTT  00
                                    LIM  00
```

Each track strip shows a peak meter and a volume value (`00`–`FF`, `FF` = full level).

Under the tracks:
- **REV** and **DEL** — how loud the reverb and delay returns come back into the mix (`00`–`FF`)
- **MIX** — the master volume
- **EQ** — the master EQ slot; press A to open the EQ EDITOR
- **OTT** / **DUST** — depth of the master bus effect chosen on the EFFECTS screen
- **LIM** — how hard the mix is pushed into the final limiter (`00` = no push)

The master volume is applied to everything — the eight tracks **and** the reverb and delay
returns — so pulling MIX down takes the tails with it.

Both kinds of fader can also be moved from a phrase while the song plays: `VTR` writes the fader of the
track it is on, `VMV` writes the master (§23), and `AUS`/`AUF` fade either of them smoothly. The numbers
on this screen keep showing what you typed — they are where playback *starts*, and stopping puts the
faders back there.

### Volume scale

| Value | Level |
|---|---|
| `00` | Silent |
| `80` | About half (−6 dB) |
| `FF` | Full level (0 dB) — where every fader starts |

### Meter zones

| Color | Range |
|---|---|
| Red | ≥ 0 dBFS (clipping) |
| Yellow | −6 dBFS to 0 dBFS |
| Green | below −6 dBFS |

The master column also has stereo send peak meters showing REV and DEL bus levels.

> [!WARNING]
> Red meters mean the master limiter is working hard. The output won't clip, but heavy limiting can colour the sound. Lower individual track volumes to give the limiter more headroom.

> [!TIP]
> Every fader starts at `FF`, which is full level — a fader can only turn a track down, never boost it. Balance by pulling the louder tracks down rather than looking for more on the quiet ones.

### Controls

| Input | Action |
|---|---|
| D-pad LEFT/RIGHT | Select track / column |
| D-pad UP/DOWN | Move between rows (track faders, REV/DEL, MIX/EQ/OTT/LIM) |
| A + LEFT/RIGHT | Increase / decrease value by 1 |
| A + UP/DOWN | Increase / decrease value by 16 |
| A (on the master EQ cell) | Open EQ EDITOR. A + LEFT/RIGHT picks the EQ slot. |
| A (on REV or DEL) | Open the reverb's or the delay's settings. B closes them. |

---

## 17. EFFECTS Screen

The EFFECTS screen configures the global stereo send buses (reverb and delay) and selects the master bus effect.

Navigate here: **R+DOWN** from MIXER, or **R+DOWN** twice from any Row 2 screen.

### Reverb section

| Parameter | Description |
|---|---|
| *preset name* | The first line of the section. **A + D-pad** on the name walks the built-in presets: **NORMAL** (the plain reverb), **ROOM** (tight, bright, close), **HALL** (a gap, then a long dark tail), **CAVE** (longest, darkest, widest). Landing on one sets every cell of the section except EQ. Turn a cell afterwards and a `*` appears in front of the name; `----` is a reverb set by hand that no built-in matches. **A + B** goes back to NORMAL. |
| SAVE / LOAD | To the right of the name. **SAVE** names the reverb and writes every cell of the section except EQ to `PocketTracker/Reverbs` as a `.ptr` file; **LOAD** reads one back, into this or any other project. |
| ALGO | Which reverb the cells below drive: **OLD** (the original), **HALL** (a large space), **ROOM** (a small one), **PLATE** and **FOIL** (metal plates — they have no room, so they ignore SIZE and MOD). Turning it changes no other cell. |
| PRE | Pre-delay (`00`–`FF`) — a gap of up to 150 ms before the tail starts, so the sound stays in front of it. `00` starts it immediately. |
| SIZE | Size of the room (`00`–`FF`) — how far apart its walls are. A bigger room also makes the movement from MOD slower. It does not change how long the tail rings or how loud it is. |
| DCAY | Length of the reverb tail (`00`–`FF`), from about half a second to about twenty-five, whatever the room. `FF` is a tail that never ends. The level stays where it is as you turn it. |
| WIDE | Stereo width of the return (`00`–`FF`). `00` is mono, `80` leaves the image as the reverb makes it, `FF` pushes it to the sides. The level does not change with it. |
| DAMP | Brightness of the tail (`00`–`FF`). `00` is dark, `FF` keeps the highs. |
| MOD | Movement in the tail (`00`–`FF`). Higher makes the tail drift in pitch; `00` holds it still, which is bright and metallic. |
| EQ | Press A to open the EQ EDITOR for the reverb return. |

The reverb return volume is set on the MIXER screen (REV row in master column).

### Delay section

| Parameter | Description |
|---|---|
| *preset name* | The first line of the section. **A + D-pad** on the name walks the built-in presets: **NORMAL** (the plain delay), **PING** (bouncing), **TAPE** (dark, drifting repeats). A built-in sets PONG, TONE and WOBL together and leaves the rest alone. Turn one of the three afterwards and a `*` appears in front of the name; `----` is a delay set by hand that no built-in matches. **A + B** goes back to NORMAL. |
| SAVE / LOAD | To the right of the name. **SAVE** names the delay and writes every cell of the section except EQ — TIME and its sync, FDBK and REV included — to `PocketTracker/Delays` as a `.ptd` file; **LOAD** reads one back, into this or any other project. |
| PONG | Repeats alternate left and right instead of echoing on their own side (`ON` / `OFF`). |
| TIME | Delay time. **SYNC off:** free time `00`–`FF` spans 0 to about 2 seconds. **SYNC on:** `00`–`0B` selects a BPM-locked subdivision (1/1 … 1/16.). Press **A** on this row to switch between the two. Changing it while the delay is sounding slides the repeats into the new time and bends their pitch on the way, the way a tape delay does; `TIM` (§23) writes the same time from a phrase or a table. |
| TONE | How bright the repeats stay (`00`–`FF`). Lower darkens each repeat more than the one before it; `FF` leaves them untouched. |
| FDBK | Feedback amount (`00`–`FF`). Higher = more repeats. From about `E0` the repeats stop fading and the delay begins to sing: around `F0` they hang almost forever, and above it they bloom into a steady tone that keeps going after the input stops. Turn WOBL up to make that tone drift. |
| WOBL | How far the tape speed drifts (`00`–`FF`), bending the pitch of the repeats. `00` holds them steady. |
| REV | Amount of delay output sent into the reverb bus (`00`–`FF`). Delay is processed before reverb, so this cross-routing is zero-latency. |
| EQ | Press A to open the EQ EDITOR for the delay return. |

> [!NOTE]
> **PONG places the repeats itself**, so it ignores where the instrument is panned — the bounce is
> always left, right, left. With PONG off, an echo stays on the side its instrument sits on.

The delay return volume is set on the MIXER screen (DEL row in master column).

> [!TIP]
> Setting **Delay REV** above `00` feeds the delay output into the reverb — this creates a "delay into reverb" effect popular in ambient, dub, and post-rock music. Start around `40` and adjust to taste.

> [!WARNING]
> **FDBK** values near `FF` make the delay self-oscillate: the tone holds at a steady level of its own and does not stop when you stop playing. Pull FDBK back below `E0` to end it. Start around `60`–`80` and increase carefully while listening to the master meter.

### Master bus

| Parameter | Description |
|---|---|
| FX | Select master bus effect: OTT (3-band compressor) or DUST (lo-fi chain). |
| DEPTH | Wet/dry depth of the selected effect (`00` = bypass, `FF` = full). |

Per-instrument effects (filter, drive, crush) are set on the INSTRUMENT screen.

---

## 18. EQ EDITOR

The EQ EDITOR is a full-screen overlay that opens when you press **A** on an EQ cell in the INSTRUMENT, INST.POOL, MIXER, EFFECTS, or SAMPLE EDITOR (EQ-effect slot) screens.

It applies a 3-band parametric equalizer (biquad filter, per the Audio EQ Cookbook). A real-time spectrum analyzer (KissFFT, ~20 fps) shows the signal relevant to the current EQ context — instrument output when opened from INSTRUMENT, delay bus from EFFECTS delay, reverb bus from EFFECTS reverb, or master bus from MIXER/master — with the computed frequency response curve overlaid.

### Layout

- **Top row** — EQ slot, calling context, hint
- **Center** — real-time spectrum + frequency response curve
- **Bottom third** — 3-column band editor (one column per band)

Each band has 4 parameters: TYPE, FREQ, GAIN, Q.

### Parameters

| Param | Range | Unit | Notes |
|---|---|---|---|
| TYPE | — | — | Band shape (see table below). |
| FREQ | `00`–`FF` | 20 Hz – 20 kHz (log) | A single A+LEFT/RIGHT step always changes the displayed Hz. |
| GAIN | `00`–`F0` | **−12.0 … +12.0 dB** | Small step **0.1 dB**, large step **1.0 dB**. `0.0 dB` is the default. |
| Q | `00`–`FF` | 0.1 – 10.0 (log) | Bandwidth; higher = narrower. |

### Band types

| Type | Description |
|---|---|
| OFF | Bypass this band |
| LOSHELF | Lift or cut everything below FREQ |
| LOWCUT | Remove everything below FREQ (high-pass) |
| BELL | Lift or cut around FREQ, as wide as Q |
| HISHELF | Lift or cut everything above FREQ |
| HICUT | Remove everything above FREQ (low-pass) |

### Controls

| Input | Action |
|---|---|
| D-pad LEFT/RIGHT | Switch between bands (1–3) |
| D-pad UP/DOWN | Move between parameters (TYPE, FREQ, GAIN, Q) |
| A + LEFT/RIGHT | Edit value (small step — GAIN: ±0.1 dB) |
| A + UP/DOWN | Edit value (large step — GAIN: ±1.0 dB) |
| A + B | Reset parameter to default (FREQ mid · GAIN 0 dB · Q mid) |
| B + LEFT/RIGHT | Switch EQ preset slot (the slot shown in the top row) |
| B | Close EQ EDITOR and apply changes |


---

## 19. PROJECT Screen

The PROJECT screen contains global settings and file operations.

Navigate here: **R+UP** from SONG or CHAIN.

### Settings

| Parameter | Description |
|---|---|
| NAME | Project name. Tap A to edit it on the keyboard overlay; hold A + LEFT/RIGHT cycles the character under the cursor in place. |
| TEMPO | BPM. |
| TEMPO — TAP | Press RIGHT from the tempo value to reach **TAP**, then press A in time with the tempo you want and the number follows your taps. The first tap starts the count and each one after it refines the reading, so tap at least twice. Leave it alone for three seconds and the next press starts a fresh count. |
| TRANSPOSE | Global semitone offset applied to all tracks. |

### File operations

| Row | Action |
|---|---|
| SAVE | Save project to `.ptp` file (press A to confirm). |
| LOAD | Open file browser to load a project. |
| EXPORT — MIX | Open the RENDER panel, set to a stereo WAV (offline, faster than real-time). |
| EXPORT — STEMS | Open the RENDER panel, set to one stereo WAV stem per active track, plus reverb and delay send returns. |
| CLEAN SEQ | Remove unused chains and phrases (with confirmation dialog). |
| CLEAN INST | Remove unused instruments (with confirmation dialog). |
| SETTINGS | Open the SETTINGS screen (press A). |
| MIDI | Open the MIDI screen (press A) — see [section 22](#22-midi-screen). |

WAV exports are saved to `<home>/Renders/` — `<home>` being PocketTracker's home folder (section 2) — with auto-incremented filenames (`ProjectName_0001.wav`). Stems are written to a per-project subfolder — `Renders/ProjectName/ProjectName_1.wav`, `_2.wav`, … — plus `_reverb.wav` / `_delay.wav` when those sends are in use.

### The RENDER panel

Either EXPORT button opens the same panel; which one you pressed is what decides whether you get a
stereo mix or a set of stems.

| Row | What it does |
|---|---|
| SONG START | The first song row of the export. |
| SONG END | The last song row, or **AUTO** — run to the end of the part SONG START is in. A+LEFT below SONG START's number returns to AUTO. |
| REPEAT | How many times the chosen rows are played into the file, `x2`–`x16`, or **OFF** for once. A+LEFT below `x2` returns to OFF. |
| RENDER | Press **A** to write the file. The percentage appears on this row while it runs. |

| Control | Action |
|---|---|
| D-pad UP/DOWN | Move between rows |
| A + LEFT/RIGHT | Change the value by one |
| A + UP/DOWN | Change SONG START / SONG END by 16 rows |
| R + UP/DOWN | Move the whole range to the previous or next part of the song |
| B | Close the panel |

A **part** is a run of song rows with a fully empty row above and below it — the same blocks playback
loops (section 6). Since each part loops on its own, a project can hold several unrelated sketches;
this panel is how you export one of them without the others.

> [!TIP]
> REPEAT plays the rows through again in a single pass rather than joining several files, so the
> reverb tail, the delay repeats and any tables carry across each repeat with no seam.

> [!WARNING]
> **CLEAN SEQ** and **CLEAN INST** are **permanent** — there is no undo. Save your project before running them, in case you remove something you still needed.

> [!TIP]
> **EXPORT → MIX** renders faster than real-time. A 3-minute song typically exports in a few seconds. The status line shows the output filename when done.

---

## 20. SETTINGS Screen

The SETTINGS screen is opened from the PROJECT screen (cursor on SETTINGS row, press A). Press **B** to return to PROJECT.

All value rows are edited with **A + D-pad**. A single **A** press is reserved for the two action rows: THEME (opens the editor) and TEMPLATE (SAVE / CLEAR).

| Setting | Options | Description |
|---|---|---|
| LAYOUT | PORTRAIT (+ SKIN) | On a touchscreen device the app lays itself out as the portrait device skin, and the row's real control is the **SKIN** column beside it: **NORM** (beige casing, dark labels), **DARK** (slate casing, white labels) or **TRNS** (no casing at all — see-through keys and labels drawn in your theme's colours, with the tracker across the full width of the screen). PocketTracker picks portrait, landscape or fullscreen for you from the screen shape and from whether it finds physical buttons; a mode column appears only on a device that has both a touchscreen and a controller (see below). |
| SCALING | INT / BILINEAR | Screen scaling algorithm. INT = crisp pixel-perfect integer scaling. BILINEAR = smooth subpixel scaling. |
| AUDIO OUT | SYSTEM / an ASIO driver | **Windows only.** Where the sound goes. **SYSTEM** plays through Windows' own output. Picking an installed ASIO driver (your audio interface's, or ASIO4ALL) plays straight to it, with much less delay between a press and the sound. The switch happens at once; the buffer size is set in the driver's own control panel. A driver usually takes the interface for itself, so other programs may go quiet on it while PocketTracker plays. If the driver cannot be opened — another program holds it, or the interface is unplugged — the app keeps playing through the previous output and says why. Unplugged while playing, it moves to **SYSTEM** (AUDIO OUT LOST) and goes back to the interface when it is plugged in again. |
| BTN SOUND | ON / OFF (+ VOL) | Play a click sound on button press. The **VOL** sub-column to its right sets click volume (`00`–`FF`). |
| BTN VIBRO | ON / OFF (+ POW) | Haptic feedback on button press (where supported). The **POW** sub-column to its right sets vibration intensity (`00`–`FF`). |
| METRONOME | ON / OFF (+ VOL) | A click on every beat — one per four phrase steps — for as long as the song is playing, with an accent on the first beat of each bar. The **VOL** sub-column sets how loud it is (`00`–`FF`). You hear it while you work; it is never written into an exported WAV. |
| KB INSERT | BEFORE / AFTER | Where the QWERTY keyboard inserts characters in name fields. |
| CURSOR | REMEMBER / REFRESH | Whether cursor position is preserved when switching between screens. |
| NAV | POOL / SONG | What B + D-pad walks. **SONG** (the default) walks the arrangement: the cursor is a song cell, and the chain and phrase on screen are the ones that cell holds. **POOL** steps through the 00–FF chain and phrase pools instead, which is what earlier versions did — see §5.4. |
| FOLDER | REMEMBER / REFRESH | With REMEMBER, a sample load reopens at the folder you last loaded a sample from, for as long as the app is running. With REFRESH it always starts at the default (or at whatever `config.json` names — see section 27). |
| NOTE PREV | ON / OFF | On the PHRASE screen, play the note under the cursor for as long as you hold **A** — when you insert it, change it with A + D-pad, or just hold A on it. Not in selection mode, and not while playing. |
| VISUALIZER | SCOPE / FLAT / OCTA / OCTA.F / SPECT / SPCT.P | Visualizer mode for the top bar (see §3 for descriptions). |
| HELP | OFF / SHORT / FULL | What a tap of **SELECT** shows: nothing, three lines in the visualizer strip, or a full help screen (see §5.2, *Help on SELECT*). |
| THEME | theme name > | Shows the current theme name. Press A to open the THEME EDITOR. |
| TEMPLATE | SAVE / CLEAR | SAVE stores the current project as a template for new projects. CLEAR removes the saved template. |
| ABXY | AUTO / XBOX / NINTENDO | Which face button your controller has **printed** A. Appears only while a controller is attached. **AUTO** trusts the controller and is right for a handheld's built-in pad and for a real Switch pad. Use **NINTENDO** if A is the right-hand button but the app reads it as B - common with 8BitDo pads in XInput mode, which report themselves as Xbox controllers. **XBOX** = A is the bottom button. Keyboard keys are never affected. |
| RESUME | ASK / AUTO | What happens to unsaved work after the app is killed in the background. **ASK** shows a "RECOVER WORK?" prompt on the next launch; **AUTO** silently restores the autosave (use on ROMs that kill the app when backgrounded, e.g. Miyoo Flip / Ayaneo). |

Layout and scaling mode are persisted across app restarts. The auto-detected layout on startup depends on whether physical gamepad buttons are detected.

**Phone held upright with a clip-on controller:** when a phone is in portrait and a physical
controller is attached, PocketTracker moves the tracker into the upper half of the screen instead
of centring it, so a grip like the GameSir Pocket Taco or the 8BitDo FlipPad does not cover it.
Unclip the controller or turn the phone and it centres again.

**Keeping the on-screen buttons with a controller attached:** attaching a controller normally turns
the on-screen buttons off. On a device that has both, the LAYOUT row offers **FULL** (no on-screen
buttons) and **PORTRAIT** (keep them), so you can use the touchscreen and the controller together.
BTN SOUND and BTN VIBRO appear only while the on-screen buttons are actually shown.

**Not every row is on every device.** LAYOUT, BTN SOUND and BTN VIBRO configure a touchscreen and its
virtual buttons, so they appear on Android and not on the Windows, Linux or handheld builds — where
there are no on-screen buttons to sound, shake or lay out. The rest are the same everywhere. A row
that would configure nothing is not shown rather than shown and inert.

> [!TIP]
> **NOTE PREV** is especially useful when building melodies — you can hear each note as you place it without needing to start playback.

---

## 21. THEME EDITOR

The THEME EDITOR lets you customize the entire color scheme of the app, or switch between built-in themes. Open it from SETTINGS → THEME row → press A.

Press **B** to close and return to SETTINGS. All color changes apply immediately so you can see them live.

### Row 0 — THEME (built-in selection + SAVE/LOAD)

The top row lets you cycle through built-in themes and save or load custom themes.

| Cursor position (channel) | Action |
|---|---|
| 0 — theme name | A+LEFT/RIGHT to cycle built-in themes: CLASSIC, AMBER, BLUE, MONO |
| 1 — SAVE | Press A to save the current theme to a `.ptt` file |
| 2 — LOAD | Press A to load a theme from a `.ptt` file |

Move between positions with D-pad LEFT/RIGHT.

### Rows 1–19 — Color parameters

Each row edits one color in the theme. The color preview swatch is shown on the right. Cursor moves between **R**, **G**, **B** channels with D-pad LEFT/RIGHT.

| Label | What it colors |
|---|---|
| BACKGROUND | Module fill and default row background; also the text inside the cursor's block |
| ROW 4TH | Beat-accent rows (every 4th step); also the text inside a selected cell |
| ROW CURSOR | The palette's accent. The block behind the cell the cursor is on (or the whole row on list screens such as SETTINGS), every row number and column heading that marks where the cursor is, the EQ EDITOR's response curve, and the frame around a selected mixer meter |
| ROW SELECT | The selected cells during copy/paste |
| TXT TITLE | Screen header text (e.g., "PHRASE", "INSTRUMENT") |
| TXT PARAM | Inactive parameter labels |
| TXT VALUE | Inactive parameter values |
| TXT EMPTY | Empty / placeholder cells |
| TXT PLAY | The `>` playback marker |
| VIZ BG | Visualizer background |
| VIZ LINE | Visualizer center line |
| VIZ WAVE | Waveform / bar fill color |
| MTR BG | Meter background |
| MTR LOW | Meter green zone (below −6 dBFS) |
| MTR MID | Meter yellow zone (−6 to 0 dBFS) |
| MTR HIGH | Meter red zone (≥ 0 dBFS) |
| EQ FILL | Shading under the EQ EDITOR's spectrum curve |
| EQ BORDER | The EQ EDITOR's spectrum outline and its 0 dB line |
| EQ TXT | Frequency labels on the EQ EDITOR's spectrum |

ROW CURSOR and ROW SELECT are the two blocks text is read *against*, so pick them bright enough for BACKGROUND and ROW 4TH to show up on them. A theme file saved by an older version still loads, and keeps every color it named; the three rows that are no longer listed are simply not drawn any more.

### Controls

| Input | Action |
|---|---|
| D-pad UP/DOWN | Move between color rows |
| D-pad LEFT/RIGHT | Move between R / G / B channels (on color rows), or between theme name / SAVE / LOAD (on row 0) |
| A + LEFT/RIGHT | +1 / −1 to the selected channel |
| A + UP/DOWN | +16 / −16 to the selected channel |
| B | Close theme editor |

### Built-in themes

| Name | Character |
|---|---|
| CLASSIC | Dark background, green wave, cyan headers, yellow cursor — the default look |
| AMBER | Warm amber/orange tones, reminiscent of an old CRT monitor |
| BLUE | Cool blue tones throughout, from deep navy rows to a pale sky-blue header |
| MONO | Grayscale — pure black/white/grey, no color |

---

## 22. MIDI Screen

PocketTracker can drive outside MIDI gear — notes, controllers, patch changes and a clock — and can
itself be played from a MIDI keyboard and steered from a controller's knobs. The MIDI screen is where
the two connections are chosen.

Open it from the PROJECT screen (cursor on the **MIDI >** row, press A). Press **B** to return.
**START** plays the song from here as well, so the timing rows can be set by ear.

| Row | Options | Description |
|---|---|---|
| OUTPUT | OFF / AUTO / a device | The device EXTERNAL instruments and the clock are sent to. **AUTO** takes the first device it finds, and takes it again when it is plugged back in. While nothing is open the row also says how many ports the system has. |
| INPUT | OFF / AUTO / a device | The keyboard or controller you play from. AUTO works the same way. |
| OFFSET | AUTO / −99 to +99 ms | Sends everything earlier (minus) or later (plus), so an outside synth lines up with the app's own sound. **AUTO** works the number out from this device's sound delay and shows it. A + LEFT/RIGHT steps 1 ms, A + UP/DOWN steps 10; A + B goes back to AUTO. |
| SYNC | ON / OFF | Sends a MIDI clock — 24 pulses per quarter note, with start and stop — so other gear follows the tempo. |
| CTL CH | ALL / 01–16 | The channel mapped knobs are listened for on — see *Mapping knobs* below. |
| PROG CHG | ON / OFF | ON sends each EXTERNAL instrument's BANK and PROG ahead of its notes, so the device is on the right patch. |
| KEYS | MONO / POLY 2–8 | How many keys of a keyboard can sound at once — see *Playing from a keyboard* below. |
| VELOCITY | ON / OFF | ON: a harder key plays louder. OFF: every key plays at full strength. |
| MAPPING | — | Press A to open the list of mapped knobs. |
| PANIC | — | Press A to send all-notes-off, for a note left hanging on an outside synth. |
| TEST | — | Press A to send one short C-4 on channel 1. The line under the rows says whether it went out. |

PROG CHG and the mapped knobs are saved with the project. The other rows describe your setup and stay
as they are from one project to the next.

### Sending to a MIDI device

Set an instrument's TYPE to **EXTERNAL** ([section 10](#10-instrument-screen)) and its notes go out of
the OUTPUT port instead of being played by the app. Each track holds one note at a time: a note ends at
the next note on its track, after the instrument's LEN, at a `KIL` or an `OFF`, or when playback stops.

| In the phrase | What is sent |
|---|---|
| A note | Note on, on the instrument's channel. Chain and project transpose, `PIT` and `ARP` move the note number |
| The V column, the instrument's VOL, `VOL` beside the note | The note's velocity |
| `VOL` on a later step | Controller 7 (volume) |
| `PAN`, the instrument's PAN | Controller 10 (pan) |
| `CUT` · `RES` | Controllers 74 (cutoff) and 71 (resonance) |
| `REV` · `DEL` | Controllers 91 and 93 |
| `PSL` · `PBN` · `PVB` · `PVX` · `FIN` | Pitch bend, moving as the command moves the note, scaled to the instrument's BEND |
| `MPG` · `MPB` · `CCA`–`CCD` | A program change, a pitch bend, and the instrument's four controller slots — see [section 23](#23-effects-reference) |

Commands that shape the app's own sound — the filter switches, drive, crush, slices — send nothing.

> [!NOTE]
> A pitch bend moves every note on its channel. Give each track that bends its own channel.

### Playing from a keyboard

With a keyboard on INPUT, its keys play the instrument you are working on: on the PHRASE screen, the
instrument of the note under the cursor; anywhere else, the one you last typed or picked. They sound on
the track the SONG cursor is on.

**KEYS** sets how many can sound together. **MONO** is one note at a time, on that track. **POLY 2–8**
lets a chord spread over that many tracks, counted rightwards from the cursor's track; each key takes
the lowest one that is free, and when all are busy the oldest key gives way.

Keys are played, not recorded: nothing is written into the phrase.

### Mapping knobs

A knob or fader on a controller can move a value in the project. The quick way is to learn it: put the
cursor on the value — on MIXER, EFFECTS or INSTRUMENT — hold **R** and turn the knob. The status line
names what the knob moves from now on.

| Group | What can be mapped |
|---|---|
| TRK | A track's fader |
| MIX | The master volume, the limiter, the OTT and DUST depth |
| REV | DCAY, DAMP, WET, SIZE, PRE, WIDE, MOD |
| DLY | TIME, FDBK, WET, TONE, WOBL, the send into the reverb |
| INS | An instrument's VOL, PAN, DETUNE, FREQ, RES, DRIVE, CRUSH, DWNSMPL, REV and DEL |

**MAPPING** on the MIDI screen opens the list of them, one line per knob:

| Column | Description |
|---|---|
| CC | The controller number the knob sends, `00`–`7F`. |
| VAL | The control's value right now. It is only shown; the cursor passes over it. |
| MIN · MAX | The values the control takes with the knob fully down and fully up. Put MIN above MAX and the knob works backwards. |
| DEST | What the knob moves, in up to three cells: the group, the track (`01`–`08`) or instrument (`00`–`7F`) where there is one to choose, and the control. A + LEFT/RIGHT steps through them; A + UP/DOWN on the group or the control shows every control at once — keep holding A, move, and release on the one you want. |

| Input | Action |
|---|---|
| A on the last line | Add a knob |
| A + D-pad | Change the cell |
| A + B | Remove the line — on MIN or MAX, put that end back instead |
| B | Back to the MIDI screen |

One knob can move several controls at once: give each its own line with the same CC. A project holds
up to 128 lines.

A knob that is mapped is used up by its mapping; one that is not is left alone. **CTL CH** is **ALL**
to begin with, which listens for mapped knobs on every channel — narrow it to one channel when two
devices send the same controller numbers.

> [!NOTE]
> A knob on an instrument's VOL, PAN or DETUNE is heard from the next note. The other controls follow
> the knob while a note is sounding.

---

## 23. Effects Reference

Effects are placed in the **FX1**, **FX2**, and **FX3** columns of a phrase step, or in the FX columns of a table row. Each has a 3-letter code and a 2-digit hex value.

Effects persist until cancelled (new note on same track, new effect in same column, or KIL), unless stated otherwise.

---

### ARP `XX` — Arpeggio

Rapid cycling through multiple pitches to simulate chords.

`XX` encodes two interval offsets: high nibble = first interval (semitones), low nibble = second interval.

| Value | Pattern | Sound |
|---|---|---|
| `37` | root, +3, +7 | Minor chord |
| `47` | root, +4, +7 | Major chord |
| `4B` | root, +4, +11 | Major 7th |
| `3A` | root, +3, +10 | Minor 7th |
| `CC` | root, +12, +12 | Octave doubling |
| `00` | (cancel) | Stop arpeggio |

Persists across steps. Configure with **ARC**.

> [!WARNING]
> ARP **persists** across steps that have no note. It is cancelled by: placing a new note on the same track, placing any effect in the same FX column, `ARP 00`, or **KIL**.

> [!TIP]
> Place **ARC** once at step 00 to configure the arpeggio mode and speed for the whole phrase. It only needs to be set once — subsequent steps just use the same ARC config.

---

### ARC `XX` — Arpeggio Config

- High nibble = mode: `0`=UP, `1`=DOWN, `2`=PINGPONG, `3`=RANDOM
- Low nibble = speed in ticks (`4` = default)

---

### CHA `XY` — Chance

Rolls the dice each time the step plays — once for each side of the `CHA` cell:

- `X` = the chance of its nearest neighbour on the **left**: the nearest filled FX column, or the
  note when every column to its left is empty
- `Y` = the chance of its nearest neighbour on the **right**: the nearest filled FX column after it

Empty columns are skipped, and only that one neighbour is gated on each side. `0` = never, `F` =
always, `8` ≈ half. Write `F` for a side you do not want gated.

```
    00    C-4 00  CHA 4F  PIT 05             ← the note about 1 time in 4; PIT whenever it plays
    04    C-4 00  LPF 40  CHA 8F             ← the note always; its LPF about half the time
    08    C-4 00  LPF 40  CHA F8  AUS 80     ← note and LPF always; the filter sweep about half the time
    0C    C-4 00  ---     CHA 8F             ← FX1 empty: the note itself about half the time
```

`AUS` looks past a `CHA` for the effect it fades, so a `CHA` between them decides whether the fade
happens at all — on that step and for the whole of the fade.

It works on a **table row** too, rolled each time the row plays; there, with nothing filled to its
left, `X` gates the row's N and V columns.

---

### NTH `XY` — Nth Pass

The row plays on pass `X` of every `Y` passes of its phrase. On the other passes it is an empty row:
the note and every effect on it are skipped, and the row still takes its time.

- `Y` = `0`: the row plays on pass `X` and never again
- `NTH 00` holds nothing back

```
    00    C-4 00  ---                ← every pass
    04    E-4 00  NTH 12             ← passes 1, 3, 5 …
    08    G-4 00  NTH 22             ← passes 2, 4, 6 …
    0A    A-4 00  NTH 30             ← the third pass only
    0C    --- --  HOP 00  NTH 44     ← every fourth pass the phrase ends here
```

A pass is one time the track starts the phrase, counted on each track from the moment playback
starts — so starting from the middle of a song counts from 1 again. `NTH` does nothing in a table.

---

### LAT `XX` — Latency

Delays the step trigger by `XX` ticks. All events on that row fire later than normal.

---

### GRV `XX` — Groove Assign

Switches the current track to use groove `XX` from this step onward.

---

### HOP `XY` — Hop / Jump

- In a **phrase**: the row is **not played** — no note, no effects, no time. The phrase ends here and the **next** phrase starts at row `Y` (`X` is ignored). A note typed on the same row will not sound; put it on the row above, which costs a row and no time.
- In a **table**: jumps **its own FX column's** playhead to table row `Y`, `X` times before falling through (`X` = 0: forever).
- `HOP FF` in a **phrase**: **stops the track** — in SONG mode until the next song row; in PHRASE/CHAIN playback the track stays silent until you stop.
- `HOP FF` in a **table**: stops **that FX column** only. The table ends when all three have stopped.

`HOP 00` at the end of a section = infinite loop of that section.

A `HOP` row costs no time in either place, so a four-row loop lasts exactly four rows.

> [!NOTE]
> In **PHRASE** playback there is no next phrase — the same one repeats — so a `HOP` there loops back into the phrase you are previewing rather than moving on. Play the chain or the song to hear what it will really do. A phrase whose first row is a `HOP` has nothing to play at all, and falls silent.

---

### KIL `XX` — Kill

Stops the sample on this track and cancels all persistent effects (ARP, RPT, pitch effects).

`XX` delays the stop by that many ticks:

- `KIL 00` = stop on this row.
- `KIL 06` = stop half a step later (6 of 12 ticks).
- `KIL 0C` = stop one full step later (the start of the next row).

KIL cuts the note whatever envelope the instrument has. An **OFF** in the note column lets it go through its release instead.

---

### OFF `XX` — Offset

Jumps the sample playback start point to offset `XX` (fraction of total length).

---

### PIT `XX` — Pitch Offset

Instantly shifts the pitch of the note by a signed number of semitones.

- `00`–`7F` = +0 to +127 semitones up
- `80`–`FF` = −128 to −1 semitones down (e.g., `FF` = −1 st, `F4` = −12 st)

Unlike PSL/PBN, PIT snaps the pitch immediately at note trigger. It does **not** affect which slice is selected when SLICE mode is active — use SLI for that.

Useful for: playing the same phrase at multiple pitch offsets without chain transpose, or layering detuned copies.

---

### PSL `XX` — Pitch Slide (Portamento)

Slides pitch from the previous note to the current note over `XX` ticks. `PSL 00` = instant.

---

### PBN `XX` — Pitch Bend

Continuous pitch bend. Persists until cancelled.

- `00`–`7F` = bend UP (higher = faster)
- `80`–`FF` = bend DOWN (`80` from the top = fastest downward)
- `PBN 00` = cancel

> [!WARNING]
> PBN **persists indefinitely** — the pitch will keep bending until `PBN 00` or a new note on the same track. An uncancelled bend will pitch the track up or down until it sounds completely wrong.

---

### PVB `XY` — Vibrato

- `X` = speed (`0`–`F`)
- `Y` = depth (`0`–`F`, up to ~1.9 semitones)

Persists until `PVB 00`, new note, or KIL.

---

### PVX `XY` — Extreme Vibrato

Same as PVB but 4× deeper and 2× faster.

---

### RPT `XY` — Repeat (Retrigger)

- **Y = 0 (simple mode):** retrigger every `X` ticks.
- **Y ≠ 0 (volume ramp mode):** retrigger every `Y` ticks.
  - `X` 1–7: decrease volume each retrig (fade-out)
  - `X` 8–F: increase volume each retrig (fade-in)

Persists across steps. Cancel with new note, new FX in same column, or KIL.

> [!WARNING]
> RPT **persists** across steps that have no note. A new note, any effect in the same FX column, or **KIL** will cancel it. Steps with a note trigger a fresh sample play and end the retrigger sequence.

---

### RND `XY` — Randomize

Plays the last effect written higher up in the same FX column again, with a random amount from `00`
to `XY` added to its value. `00` adds nothing; the value never goes past `FF`.

```
    00    C-4 00  VOL 80
    04    C-4 00  RND 10               ← VOL 80 to VOL 90
```

It works on a **table row** too, re-playing the nearest effect above it in its column — with `TIC 00`,
a new roll on every note.

---

### RNL `XY` — Randomize Left

Adds a random amount from `00` to `XY` to the effect in the column to its left.

In the first FX column there is no effect to its left, so it randomizes the note and the instrument
instead: the note goes up by `0` to `X` semitones, and the instrument number goes up by `0` to `Y`.
`C-4 04 RNL 53` plays anything from C-4 to F-4, on instrument 04 to 07.

It works on a **table row** too, rolled each time the row plays — in FX2 or FX3; in a table's FX1 it does
nothing.

---

### SLI `XX` — Slice Index

Directly sets the slice to play, bypassing note-based selection.

- `XX` = slice index `00`–`FF`
- Works regardless of the instrument's SLICE mode — even with SLICE=OFF
- Overrides the slice that the note pitch would normally select

This is useful when you want precise control over which slice plays without having to map it through note pitch. For example: `SLI 03` always plays slice 3, whatever note is in the N column.

Combine with PIT to pitch-shift a specific slice without changing the slice selection.

---

### TBL `XX` — Table Set

Overrides the instrument's default table, using table `XX` for this note.

---

### THO `XX` — Table Hop

Jumps the table playhead to row `0X`. `THO 00` = loop current section.

In a **table** it moves its own FX column's playhead; in a **phrase** it moves all three.

---

### TIC `XX` — Tick Rate

Sets the tick rate of the FX column it is written in — each of the three has its own. In a table's
**last row** it sets that column's rate from the start; anywhere else it takes effect as that
column's playhead passes.

- `TIC 06` = default (6 ticks per row, two rows per phrase step)
- `TIC 03` = twice as fast
- `TIC 0C` = half speed (one row per phrase step)
- `TIC 00` = trigger mode — row is set by the note that triggered the instrument, no auto-advance
- `TIC FC` = octave map — table row = octave of the triggered note (0–9)
- `TIC FE` = note map — table row = pitch of the triggered note (C=0, C#=1 … B=11)
- `TIC FF` = 200 Hz mode — table advances approximately one row every 5 ms, independent of tempo

---

### VOL `XX` — Volume Automation

Sets the step volume to `XX` at the exact tick this command fires. Useful in table rows for volume animation.

---

### PAN `XX` — Pan

Overrides the stereo pan for **this note only**. `00` = hard left, `80` = center, `FF` = hard right. The
next note on the track (without a PAN) reverts to the pan set on the INSTRUMENT screen. On an empty step it
moves the currently-playing voice. On a **table row** it moves the note each time the row plays, so a
column of PAN values is an auto-pan.

---

### BCK `0X` — Playback Direction

Sets the sampler playback direction live (sampler instruments only):

- `BCK 00` = play **backward**. On a step with a note it starts from the sample's end.
- `BCK 01` = play **forward**.

Placed on an **empty step** it flips direction from the voice's **current position** (it does not restart),
so toggling `BCK 00` / `BCK 01` on successive rows lets you "scratch" a sample back and forth.

---

### REV `XX` — Reverb Send (per note)

Sends **this note only** to the reverb bus at level `XX` (`00`–`FF`), independent of the instrument's own
reverb send and without affecting later notes. Configure the reverb itself on the EFFECTS screen.

---

### DEL `XX` — Delay Send (per note)

Sends **this note only** to the delay bus at level `XX` (`00`–`FF`), independent of the instrument's own
delay send.

---

### EQN `XX` — EQ (per note)

Applies EQ preset slot `XX` (`00`–`7F`) to **this note only**. Edit the presets in the EQ EDITOR (§17).
A preset with all bands off = no EQ. Works in a **table row** too, like `CUT` and `RES`.

---

### EQM `XX` — EQ (mixer / master)

Switches the **master bus** EQ to preset slot `XX` (`00`–`7F`) during playback. It **persists** until the
next `EQM`, then resets to the master EQ configured on the MIXER screen when playback stops. Use it to
automate the master EQ across a song (e.g. a filter-sweep build-up). Works in a **table row** too.

---

### VTR `XX` — Track Fader

Sets the MIXER fader of **the track this effect sits on** to `XX` (`00`–`FF`). It moves the whole track,
every voice on it — not just the note on this step. The reverb and delay sends are tapped *above* the
fader, so a track faded out with `VTR` leaves its tails ringing.

It **replaces** the fader rather than scaling it, exactly as `VOL` replaces the instrument's volume, and
it **persists** until the next `VTR` on that track. The MIXER screen keeps showing the value you typed
there: the fader on screen is where the song *starts*, `VTR` is where the song has moved it to. Stopping
playback puts the fader back.

There is one `VTR`, and it always means the track it is written on — to move another track's fader, write
it in a phrase playing on that track.

---

### VMV `XX` — Master Fader

Sets the **master** fader to `XX` (`00`–`FF`) — the whole mix, including the reverb and delay returns.
Like `VTR` it replaces rather than scales, persists until the next `VMV`, and is restored when playback
stops.

It belongs to no track, so it works from any of them: a `VMV` on track 8 fades the same master fader as a
`VMV` on track 1.

---

### TIM `XX` — Delay Time

Sets the shared delay's **echo time** to `XX` (`00`–`FF` = 0 to 2 seconds) — the same range the DELAY
screen's `TIME` dial covers in free mode.

`XX` always means that free range, **even when the DELAY screen is set to SYNC**: the twelve tempo
divisions are a list rather than a scale, and a fade needs a scale to slide through. A `TIM` therefore
takes the delay off the tempo grid until the next one.

Like `VTR` and `VMV` it belongs to no track, works from any of them, persists until the next `TIM`, and
is restored when playback stops.

The delay's read head **glides** to a new time rather than jumping to it, and a moving head plays the
repeats back at a different speed — so the echoes bend in pitch on the way, the way a tape delay does.
A `TIM` under `AUS`/`AUF` is a long tape swoop; a single `TIM` is a shorter one.

It also works on a **table** row, where it fires once per tick — that is where the fastest and finest
bends are written.

---

### AUS `XX` — Automation Start · AUF `XX` — Automation Finish

`AUS` and `AUF` are a **pair**, and together they fade a parameter smoothly from one value to another
instead of stepping it once per row.

Write the parameter at its **starting value**, put `AUS` in the slot **to its right**, and put `AUF` on a
**later step** carrying the value to arrive at:

```
STEP  FX1      FX2      FX3
00    VOL 00   AUS 80            ← start at 00, linear
08             AUF FF            ← arrive at FF eight steps later
```

`AUS`'s value is the **curve**, not a level:

| Value | Shape |
|---|---|
| `00` | ease-in — slow to leave, fast to arrive |
| `80` | linear |
| `FF` | ease-out — fast to leave, slow to arrive |

Anything between blends towards the neighbouring shape, so `40` is a gentle ease-in and `C0` a gentle
ease-out.

**What can be ramped.** `AUS` automates the nearest automatable effect **to its left on the same step**,
skipping any that are not:

| Effect | What fades |
|---|---|
| `VOL` | the step volume |
| `PAN` | the stereo position |
| `REV` | the reverb send |
| `DEL` | the delay send |
| `VTR` | this track's fader |
| `VMV` | the master fader |
| `TIM` | the delay time — the repeats bend in pitch as it moves |
| `CUT` | the filter cutoff |
| `RES` | the filter resonance |
| `LPF` `HPF` `BPF` | the cutoff of the filter they switch on |
| `DRV` | the overdrive amount |
| `FIN` | the fine tune — end to end is a two-semitone glide |
| `EQN` | this track's EQ — **between two presets** (see below) |
| `EQM` | the master EQ — **between two presets** (see below) |

In `VOL 20  PSL 40  AUS 00`, the `AUS` ramps the `VOL` — `PSL` is not automatable, so it is passed over.

**Fading between two EQ presets.** `EQN` and `EQM` are different from every other row above: their
value is a **preset number**, not a level. So the pair does not slide the number — it slides the
**contents**. Write the starting preset, `AUS` beside it, and the destination preset on the `AUF`:

```
00    EQM 05   AUS 80            ← start on preset 05, linear
08             AUF 12            ← arrive at preset 12 eight steps later
```

Over those eight steps the **FREQ, GAIN and Q of all three bands** slide from what preset 05 holds to
what preset 12 holds. The frequency sweep is even across the keyboard, not bunched at the top.

⚠️ **Give both presets the same three band TYPES.** A type cannot be faded — there is no halfway
between a BELL and a HI SHELF — so the **starting** preset's types are kept for the whole fade. Match
them and you arrive exactly on the destination preset. Leave them mismatched and that band still sweeps
its frequency and gain, but under the start's type, and the fade ends on a setting that is not quite
either preset. Nothing clicks either way.

To land on the real destination preset, write it: `EQM 12` on the step after the `AUF`.

A band switched **OFF** in the starting preset stays off for the whole fade. To fade a band out, ramp
its **GAIN to 0.0 dB** instead.

⚠️ A preset number is `00`–`7F`. An `AUF` above `7F` on an EQ fade names no preset, so it is ignored and
drawn dimmed — and the `AUS` stays open for the next `AUF` you write.

⚠️ `EQM` fades the master bus and keeps going on its own. `EQN` follows the **note** — over a silent
track there is nothing to filter, and each new note picks the fade back up a moment after it starts. For
a long, obvious EQ sweep, use `EQM`.

**A fade may cross phrases.** The `AUF` can sit in a **later phrase of the same chain**, which is how a
fade longer than one phrase is written — up to the sixteen rows of the chain. It does **not** cross into
the next chain: pairing stops at the end of the chain the `AUS` was written in.

**A fade may also be written in a TABLE**, over rows rather than steps and with a smaller set of
parameters — see §12 → *Fades in a table*.

**When nothing happens.** A cell that is not part of a working pair is drawn **dimmed**, the same way an
empty cell is. That is the editor telling you the fade will not play. The reasons are:

- `AUS` with nothing automatable to its left, or with no `AUF` after it in the chain;
- `AUF` on the **same step** as its `AUS` — the pair needs a later step to have any duration;
- a second `AUF` after the pair has already closed;
- a second `AUS` before an `AUF`, which replaces the first one — the last `AUS` wins, pairs do not nest;
- on an `EQN`/`EQM` fade, an endpoint above `7F` — it is not a preset number, so it names nothing.

One ramp runs at a time on a track, so to fade two parameters at once, write them on two tracks.

---

### CUT `XX` — Filter Cutoff · RES `XX` — Filter Resonance

Move the **instrument's own filter** on **this note only**: `CUT` sets the cutoff frequency and `RES` the
resonance, both `00`–`FF`, the same two values as the FREQ and RES cells on the INSTRUMENT screen (§10).
The next note starts from the instrument's values again.

> ⚠️ **The note must have a filter for these two to move.** `CUT` and `RES` move the filter that is
> already there — they do not switch one on. Give the instrument a FILTER TYPE on the INSTRUMENT screen,
> or write `LPF`, `HPF` or `BPF` in an earlier FX slot (next section), and the FX column takes it from there.

Cutoff is exponential across the byte: `00` is 20 Hz, `FF` is 20 kHz, and each `+0x33` is roughly one
decade. On a low-pass, small numbers are dark and large ones are open.

Both can be **ramped** with `AUS`/`AUF`, which is what a filter sweep is:

```
    00    CUT 20   AUS 80            ← start closed, linear
    08             AUF E0            ← open over eight steps
```

Both also work in a **table**, once per tic, so a sweep written once follows every note that instrument
plays — the shortest way to give a sample a filter envelope without spending a modulation slot.

On an **EXTERNAL** instrument the same two cells send controller 74 (cutoff) and controller 71
(resonance) to the MIDI device.

---

### LPF `XX` · HPF `XX` · BPF `XX` — Switch a Filter On

Give **this note** a low-pass, high-pass or band-pass at cutoff `XX`, whatever the instrument's own
FILTER setting is. The value is the same `00`–`FF` cutoff `CUT` uses: `00` is 20 Hz, `FF` is 20 kHz.

```
    00    LPF 40                     ← this note plays through a low-pass at 40
    04    HPF 90                     ← and this one through a high-pass at 90
```

The filter lasts for the note, like `CUT` and `RES` — the next note starts from the instrument's own
setting again. `RES` written beside one of them sets its resonance, and `CUT` after it moves the cutoff
without changing the type, which is what a sweep over an already-chosen filter needs.

All three can be **ramped** with `AUS`/`AUF`, and all three work in a **table row**, once per tic — one
row there gives every note that instrument plays a filter.

---

### DRV `XX` — Overdrive

Overdrives **this note**, `00` clean through `FF` heavy — the same control the INSTRUMENT screen's
DRIVE cell holds, written per note. The next note starts from the instrument's own value again.

Ramps with `AUS`/`AUF`, and works on a table row, so a note can dirty up as it holds.

---

### CRU `XY` — Bit Crush + Downsample

Two effects in one cell, each a single digit `0`–`F`:

- **`X`** — bits crushed away. `0` is clean, `F` leaves about one bit.
- **`Y`** — how far the sample rate is dropped. `0` is clean, `F` is the coarsest.

```
    00    CRU 80                     ← crushed bits, full rate
    04    CRU 08                     ← full bit depth, badly downsampled
    08    CRU 88                     ← both
```

The same two controls the INSTRUMENT screen holds, written per note, and gone at the next note. It can
be used on a table row; it cannot be ramped, because the cell is two separate numbers rather than one
value to slide.

---

### FIN `XX` — Fine Tune

The cents between the semitones. `80` is in tune, `00` is a semitone flat, `FF` a semitone sharp, and
each step is about 0.8 cents — so anything `PIT` steps over is reachable, and two voices a few steps
apart beat against each other.

```
    00    C-4   FIN 84               ← a few cents sharp
    04    C-4   FIN 7C               ← and a few flat, for a chorus against it
```

It **retunes the note that is already playing**, so it can be written on a step of its own to bend a
held note, and an `AUS`/`AUF` ramp across the whole byte is a two-semitone glide. On the same step as
a note it tunes that note. Gone at the next note, like `CUT` and `DRV`, and it works on a table row.

---

### TSX `XX` — Transpose Multiplier

How far the chain's `TSP` column and the project's `TRANSPOSE` move this step. `01` is normal, `00`
leaves the note exactly where it is written, higher values move it further, and `FF` downwards move
it the opposite way.

| Value | Where a `TSP` of `+3` puts a C-4 |
|---|---|
| no cell | D#4 — three up, as always |
| `00` | C-4 — unmoved |
| `01` | D#4 |
| `02` | F#4 — six up |
| `0C` | C-7 — an octave for every step of `TSP` |
| `FF` | A-3 — three **down** |
| `FE` | F#3 — six down |

```
    00    C-4 01  TSX 00               ← this note never moves
    04    E-4 01                       ← this one follows the chain as usual
    08    G-4 01  TSX 02               ← and this one moves twice as far
```

So one phrase can be reused across chains transposed differently, with the notes you want held still
and the notes you want moved doing the moving.

It applies to the step it is written on and to a phrase only — a `TSX` on a **table row does
nothing**, because by the time a table runs its note has already been placed. To keep a whole
instrument still, set `TSP` to `OFF` on the INSTRUMENT screen instead (§10); that switch wins over any
`TSX`.

---

### INS `XX` — Instrument

The note on this step plays instrument `XX` instead of the one in its `I` column. `00`–`7F`.

Put `RNL` to its right, or an `RND` further down the same FX column, and each note picks an instrument
at random, counting up from the one `INS` names.

```
    00    C-4 00  INS 04  RNL 03       ← instrument 04, 05, 06 or 07, a new pick every pass
    04    C-4 00  INS 08               ← always instrument 08
```

It needs a note on the same step.

`INS` works on a **table row** too, where it hands the note on instead: the note passes through the
table as far as the row carrying `INS`, leaves there, and plays on that instrument — which brings its
own table, so one `INS` can lead to another. Everything to the left of the `INS` on that row still
shapes the note; anything to its right is not read. A row with no `INS` plays your own instrument,
with that row's transpose, volume and effects as usual.

With `TIC 00` the table reads one row per note, so a column of `INS` cells rotates through
instruments — a new one each time the note retriggers. `HOP` on the same FX column loops that
rotation. At any other tic rate the row read is always row 0.

An `INS` naming an empty instrument is silent, rather than falling back to the instrument you played.

---

### SCA `XY` — Track Scale · SCG `XY` — Global Scale

Put a track on one of the project's 16 scales. `SCA` moves the track the command is written on; `SCG`
moves all eight.

| Nibble | Meaning |
|---|---|
| `X` | The key, `0`–`B` — `0` is C, `1` is C#, up to `B` for B |
| `Y` | Which scale, `0`–`F` |

```
    00   C-4   SCA 71           ← this track plays scale 01 in the key of G
    04   D#4   SCG 03           ← every track plays scale 03 in the key of C
```

From that step onward every note the track plays lands on a note of that scale — see
[section 14](#14-scale-screen) for what a scale is and what it leaves alone. The command takes effect
on its own step, so a note written beside it is already in the new scale.

Both last until the next scale command and are forgotten when playback stops; nothing about them is
saved in the song. To put a track back on scale `00`, name it again — `SCA 00`, or `SCG 00` for every
track at once, including tracks an earlier `SCA` moved. Note that this also sets the key to C, because
every scale command carries one: only stopping playback returns a track to the project's own KEY.

> [!NOTE]
> On a step carrying both, `SCA` wins for its own track and `SCG` still moves the other seven.

---

### MPG `XX` — MIDI Program Change

Sends a program change `XX` (`00`–`7F`) on the channel of the EXTERNAL instrument playing this track —
a patch switch in the middle of a song.

Put it on an **empty step**, between notes: on a step that also has a note, that note has already
started on the old patch. With PROG CHG on, an instrument that has a PROG of its own states it again
with its next note, so leave the instrument's PROG at `--` when the phrase is choosing the patches.

---

### MPB `XX` — MIDI Pitch Bend

Sends a pitch bend to the EXTERNAL instrument's channel: `00` is fully down, `80` is centre, `FF` is
fully up — down or up by the instrument's BEND. Slides, bends and vibrato on the track move from there.

It is a position, not a movement — the bend stays where you put it until the next `MPB`. Stopping
playback returns it to centre.

---

### CCA · CCB · CCC · CCD `XX` — MIDI Controller Slots

Sends value `XX` (`00`–`FF`, scaled to MIDI's 0–127) to the controller named in the instrument's
**CC A**–**CC D** rows. The phrase names the slot and the instrument names the controller, so pointing
CC A at another controller re-points every `CCA` in the song with it. A slot with no controller set
sends nothing.

Beside a note, the command wins over the slot's own VAL for that note.

---

## 24. Modulation Reference

See §15 for how to edit mod slots. Envelope times are in **tics**, so they track project BPM.

### AHD Envelope

One-shot envelope triggered on each note. `AMT` controls how much the destination is affected.

```
     ┌──────┐
     │      │
  ATK│ HOLD │DEC
     │      └────
─────┘            ─ (returns to base)
```

- **ATK** — attack time in ticks (0 = instant)
- **HOLD** — hold duration at peak
- **DEC** — decay time to zero

### ADSR Envelope

Release is triggered by an **OFF** in the phrase's note column, or by letting go of a MIDI key.

- **ATK** — attack time
- **DEC** — decay to sustain level
- **SUS** (`00`–`FF`) — sustain level
- **REL** — release time after note off

### DRUM Envelope

Percussive shape: transient → body → tail. Identical stage machine to AHD; the name signals intent.

- **ATK** — transient attack time (typically `00`)
- **HOLD** — body duration ("thud")
- **DEC** — tail decay

### LFO

Cyclic modulation. Phase resets to 0 on each new note (RETRIG mode).

- **OSC** — shape: TRI, SIN, RMP+, RMP−, EXP+, EXP−, SQU+, SQU−, RANDOM, DRUNK
- **FREQ** (`00`–`FF`) — rate (~0.08 Hz at `00`, ~20 Hz at `FF`)

### TRIG Envelope

Behaves identically to ADSR — same ATK/DEC/SUS/REL parameters.

---

## 25. File Management

Throughout this section `<home>` is PocketTracker's home folder: on Android the folder you granted it
(section 2), and elsewhere the `PocketTracker` folder the app keeps beside itself.

### Managing files in the browser

You do not need a separate file manager. Any file browser — the one PROJECT → LOAD opens, or the one
the INSTRUMENT screen's **LOAD** button opens — can rename, delete, move and copy, using **SELECT** and **L** as
modifiers.

| Input | Action |
|---|---|
| SELECT + A | Rename the file or folder under the cursor. A keyboard opens with the current name. |
| SELECT + B | Delete it — or, inside a selection, every selected file. An `A=YES  B=NO` confirm appears first — nothing is deleted on the press itself. |
| SELECT + R | Create a folder here. A keyboard opens for the name. |

**Moving and copying several files** works like the tracker's own copy/paste:

1. **L + B** starts a selection at the cursor. Tap **L + B** again inside half a second to select
   everything in the folder.
2. **D-pad UP/DOWN** stretches the selection.
3. **B** copies the selected files, or **L + A** cuts them. Either way the selection ends and the
   status line reports how many files are on the clipboard.
4. Navigate to the destination folder and press **L + A** to paste. A cut **moves** the files; a copy
   **duplicates** them.

**L + R** cancels a selection without copying anything.

Two details worth knowing:

- **A paste never overwrites.** If the destination already holds a file of that name, the new one
  arrives as `kick_2.wav`, `kick_3.wav`, and so on.
- **A cut clipboard is spent once pasted** — the originals have moved. A copied one survives, so you
  can paste the same files into several folders in a row.

> [!TIP]
> On Android the destination can be any folder you have granted, including one on an SD card — so
> this is also how you move a project or a sample between two granted folders.

### Project files

- Format: `.ptp` (JSON with version field; old projects are migrated automatically on load)
- Location: `<home>/Projects/`
- Save: PROJECT screen → SAVE
- Load: PROJECT screen → LOAD

### Sample files

- Format: `.wav` (8/16/24/32-bit PCM or float; mono or stereo)
- Stereo WAV files are supported natively — SOURCE mode on the instrument or sample editor selects LEFT / RIGHT / STEREO / MONO non-destructively
- Sample rates: any — PocketTracker compensates the pitch of a file recorded at a different rate automatically
- Loaded via: INSTRUMENT screen → **TYPE** row → **LOAD** → **A** → file browser
- SF2 and SF3 files are loaded the same way
- **Compressed audio** (`.mp3`, `.flac`, `.ogg`, `.opus`, `.m4a`) loads directly as a sample — decoded into memory with **no WAV file written** and no slice markers. The instrument remembers the original file path, so it is re-decoded automatically each time the project is reopened. FLAC is lossless, so it is the best choice when you want a small file with no quality loss. (`.opus` and `.m4a` are common voice-recording formats — phone memos, messaging-app exports.)
- **Video files** (`.mp4`, `.mkv`, `.webm`, `.3gp`, `.mov`) can instead be **converted** to samples — the audio track is extracted and saved as a WAV. See *Audio from video files* below.

### Audio from video files

PocketTracker can pull the audio track out of a video (or audio-container) file and turn it into a
sample — handy for grabbing a sound straight from a clip without a separate converter app.

- **Supported containers:** `.mp4`, `.mkv`, `.webm`, `.3gp`, `.mov`. The audio track is decoded
  with the device's built-in codecs. (`.m4a` is **not** here — it loads in place as a sample instead;
  see *Sample files* above.)
- **How:** INSTRUMENT (or INST_POOL) screen → **SAMPLE** field → **A** → file browser → highlight a video
  file → **A**. A keyboard appears, pre-filled with `<filename>_audio`; edit the name if you like, then
  confirm.
- **What happens:** the first audio track is extracted, **saved as a WAV** in
  `<home>/Samples/` (stereo preserved, at the file's own sample rate) and loaded into
  the current instrument. The status line shows `CONVERTED: <NAME>.WAV`.
- Because a real WAV is written, the instrument gets a normal, reusable sample file and reopens without
  re-decoding — the key difference from compressed audio (MP3 / FLAC / OGG / M4A), which is decoded in
  memory on every load.
- **Preview first:** highlight a video file and press **START** to hear it before converting.
- **Length limits:** conversion extracts up to **60 seconds**; preview is capped at **30 seconds**.
  Longer files report *"Audio too long"*. A file with no audio track — or a codec the device can't
  decode — reports an error and nothing is saved.

### WAV exports

- Format: 16-bit stereo WAV, at the rate your device runs (48000 Hz on most hardware)
- Location: `<home>/Renders/`
- Filenames: `ProjectName_0001.wav`, `_0002.wav`, … (auto-incremented)
- Triggered from: PROJECT screen → EXPORT → MIX

### Theme files

- Format: `.ptt` (JSON color theme)
- Saved/loaded from: SETTINGS → THEME → open THEME EDITOR → SAVE / LOAD

### Resampled instruments

Created via Selection Resampling:

1. On the SONG screen, enter selection mode (**L+B**).
2. Select the rows and tracks you want to render.
3. **Double-tap A** — a confirmation dialog appears.
4. Choose YES — selected tracks render offline to a WAV file.
5. A new instrument is created in the first empty slot with the rendered audio.

Output: `<home>/Samples/Resampled/Resample_0001.wav`, …

### CHOP exports

When slice markers are set in the SAMPLE EDITOR, use CHOP to export each slice as a separate WAV:

Output: `<home>/Samples/Chops/{instrument_name}/`

> [!NOTE]
> CHOP exports do not automatically load into instrument slots. After chopping, open the INSTRUMENT screen and use the file browser to load the individual slice files onto new instruments.

### The log file

- Location: `<home>/pockettracker-log.txt`
- One session, rewritten each launch, capped at 512 KB

Plain text, and readable on the device itself. It records the whole start-up — which folders were
found, how many samples loaded, which controller was detected — which is exactly what a bug report
needs and what is hardest to describe from memory. If something is wrong, attach this file.

---

## 26. Workflow Tips

### Making your first phrase

1. Open **PHRASE** (R+RIGHT from SONG).
2. Cursor on row 00, column N. Press **A** — inserts default note (C-4, instrument 00).
3. Use **A+LEFT/RIGHT** to change pitch; **A+UP/DOWN** to change octave.
4. Move to the I column, use **A+LEFT/RIGHT** to select an instrument.
5. Press **START** to hear the phrase loop.

### Building a basic beat

1. Load a kick on instrument `00`, snare on `01`, hihat on `02`.
2. In PHRASE `00`: place kick at steps 00, 04, 08, 0C; snare at 04, 0C; hihat at every even step.
3. Create CHAIN `00` pointing to PHRASE `00`.
4. In SONG, put CHAIN `00` on track 0, row 00. Hit **START**.

### Transpose in chains

Rather than duplicating a phrase at a different pitch, set the TSP column in the CHAIN. `07` = +7 semitones (a perfect fifth). The same phrase plays higher with no copy.

### Swing with groove

1. Navigate to GROOVE (R+UP from PHRASE).
2. Create groove `01`: rows `0E`, `0A`, `--`.
3. In your phrase, add `GRV 01` in an FX column of step 00.
4. The track now swings.

### Modulation: Volume fade-in on a pad

1. Open INSTRUMENT for your pad, then MODS (R+UP).
2. MOD1: TYPE=AHD, DEST=VOLUME, ATK=`40`, HOLD=`20`, DEC=`60`.
3. Every note now has a volume envelope shaping its amplitude.

### Fading a track in over four bars

1. On the CHAIN screen, put four phrases on rows `00`–`03`.
2. Open the phrase on row `00`. On step `00` write `VTR 00` in FX1 and `AUS 80` in FX2 — the track
   fader starts silent, on a linear curve.
3. Open the phrase on row `03`. On step `0F` write `AUF FF` — the fader arrives at full over the whole
   four bars.
4. Both cells stay lit: the pair works across the chain. Delete the `AUF` and the `AUS` dims, because
   there is nothing to fade towards.

Swap `VTR` for `VMV` to fade the whole mix instead, or for `REV` to open a reverb send.

### Using the sample editor for sliced breaks

1. Load a drum loop WAV on an instrument.
2. On the TYPE row, move the cursor to **EDIT >** and press **A** to open the SAMPLE EDITOR.
3. Set SLICE mode to TRANSIENT, adjust SENS until markers land on drum hits.
4. Press SAVE / OVERWRITE to embed the cue chunk in the WAV file.
5. Back on INSTRUMENT screen, set SLICE = CUT.
6. Now each note in a phrase selects a different slice — C-4 = hit 0, C#4 = hit 1, etc.

### WAV export

1. Build your complete song.
2. Navigate to PROJECT screen.
3. Move cursor to EXPORT, select MIX and press **A**. The song renders offline — a status message shows the output filename when done.

### Customizing your theme

1. Navigate to SETTINGS (PROJECT → SETTINGS row → A).
2. Move to the THEME row and press **A** to open the THEME EDITOR.
3. On row 0, use A+LEFT/RIGHT on the theme name to cycle through built-in themes (CLASSIC, AMBER, BLUE, MONO).
4. Move down to any color row, then LEFT/RIGHT to select R/G/B, and A+LEFT/RIGHT to adjust.
5. When you are happy with the look, move back to row 0, move RIGHT to SAVE, and press A.

---

## 27. Configuration File (config.json)

Some things are easier to set in a text file than on a 640×480 screen. `config.json` lives in
PocketTracker's home folder, beside the `Projects` and `Samples` directories, and covers these:
**your controller's button layout**, **your keyboard and controller bindings**, **how fast a held
direction repeats**, and **which folder a load browse opens at**.

It is the opposite of `settings.json`, which the app writes whenever you change something on the
SETTINGS screen. **`config.json` is yours** — the app reads it once at startup and never writes to it
again.

**Finding it.** The app creates a starter copy filled in with everything at its current value — on
first launch, or on Android on the first launch after you have granted it a folder to live in. So the file already shows you the exact shape and spelling of every option, and as
seeded it changes nothing. Open it in any text editor, change what you want, and **restart the app**.

Beside it sits `config.example.json`: every setting at its default, kept up to date by the app. If
your `config.json` is from an older version, the newer settings are there — copy the lines you want
across. Edits to the example itself are lost.

Every key is optional. Delete a line to go back to the built-in default. A missing, empty or
malformed file costs you nothing — the defaults simply stand.

### Controller button layout

```json
"controller": { "abxy": "auto" }
```

| Value | Meaning |
|---|---|
| `auto` | **Default.** Trust the controller's own report. |
| `nintendo` | The button printed **A** is the **right** one in the ABXY cluster. |
| `xbox` | The button printed **A** is the **bottom** one. |

Most controllers report their buttons correctly and `auto` is right — a handheld's built-in pad and a
real Switch Pro controller both work with nothing configured.

The exception is a pad that misreports itself. Many third-party controllers, and **8BitDo pads in
XInput mode in particular**, tell the computer they are Xbox 360 controllers. Their buttons are
printed the Nintendo way round, but the app is told the Xbox layout, and the result is unmistakable:
**A and B do each other's jobs** (as do X and Y).

Set `"abxy": "nintendo"` and both pairs swap back together.

This can't be detected automatically — the controller is answering the question wrongly, and nothing
downstream can tell. That is why it's a setting.

> **On a handheld:** PortMaster already offers an x360/nintendo choice that does the same thing. Use
> one or the other. Setting **both** swaps twice and leaves you exactly where you started.

### Keyboard bindings

Relevant on the Windows and Linux desktop builds. The defaults are:

```json
"keyboard": {
  "DPAD_UP":    ["W", "Up"],
  "DPAD_DOWN":  ["S", "Down"],
  "DPAD_LEFT":  ["A", "Left"],
  "DPAD_RIGHT": ["D", "Right"],
  "A":      ["K", "Return"],
  "B":      ["J", "Escape"],
  "L":      ["U"],
  "R":      ["I"],
  "SELECT": ["Left Shift"],
  "START":  ["Space"]
}
```

Those ten names are the complete set. Each takes a list of keys of any length.

**A button you list replaces its defaults, and takes the keys it lists away from any other button.**
A button you leave out keeps its defaults. So `"SELECT": ["K"]` alone moves `K` from **A** to
**SELECT**, and **A** keeps `Return`. To free a button entirely, list it as `[]`.

**Key names** are SDL's, and their spelling is not guessable — some are spaced and some are not.
Copy them from here:

| | |
|---|---|
| Letters, digits | `"K"` `"Z"` `"1"` — always capitalised |
| Modifiers | `"Left Shift"` `"Right Shift"` `"Left Ctrl"` `"Right Ctrl"` `"Left Alt"` `"Left GUI"` |
| Editing | `"Return"` `"Escape"` `"Space"` `"Tab"` `"Backspace"` `"Insert"` `"Delete"` |
| Arrows | `"Up"` `"Down"` `"Left"` `"Right"` |
| Navigation | `"Home"` `"End"` `"PageUp"` `"PageDown"` — note: **no space** |
| Locks etc. | `"CapsLock"` `"PrintScreen"` — also no space |
| Function | `"F1"` … `"F12"` |
| Keypad | `"Keypad 0"` … `"Keypad 9"`, `"Keypad Enter"`, `"Keypad +"` — these **do** have a space |

If you're unsure, the starter file the app wrote is the reliable reference: anything appearing there
is known to work.

**If a rebind doesn't seem to happen, read the app's log.** An unrecognised key name is reported by
name and skipped; that one binding is lost and nothing else is. `"Ctrl"` is the usual culprit — it
has to be `"Left Ctrl"` or `"Right Ctrl"`.

If you list the same key under two buttons, only one of them gets it, and the log says which.

On Android the hardware **Back** key is always **B**, whatever this section says — so a file you
edited on a desktop can't leave you unable to back out of a screen on a phone.

### Controller bindings

The same idea for a gamepad or a handheld's built-in buttons. Nothing needs listing unless you want a
change; the defaults are:

```json
"gamepad": {
  "DPAD_UP":    ["dpup"],
  "DPAD_DOWN":  ["dpdown"],
  "DPAD_LEFT":  ["dpleft"],
  "DPAD_RIGHT": ["dpright"],
  "A":      ["a", "x"],
  "B":      ["b", "y"],
  "L":      ["leftshoulder"],
  "R":      ["rightshoulder"],
  "SELECT": ["back"],
  "START":  ["start"]
}
```

X and Y do the same as A and B out of the box, so they are free to take something else. To put START
and SELECT on Y and X:

```json
"gamepad": {
  "START":  ["start", "y"],
  "SELECT": ["back", "x"]
}
```

The rules are the keyboard's: a listed button replaces its defaults and takes what it lists from
any other button, so these two lines are all it takes — A and B keep their own buttons.

Names are what is **printed** on the pad: `a` `b` `x` `y`, `back` (SELECT), `start`, `leftshoulder`,
`rightshoulder`, `dpup` `dpdown` `dpleft` `dpright`. `leftstick` and `rightstick` (pressing a stick
in), `guide` and `paddle1`–`paddle4` work too where the pad has them, and so do the triggers,
`lefttrigger` and `righttrigger` (L2/R2), which do nothing until you bind them. If **ABXY** on the
SETTINGS screen is set to NINTENDO, `y` still means the button printed Y. The sticks cannot be bound.

> **On a Miyoo Mini** this section takes the Miyoo's own button names: `UP` `DOWN` `LEFT` `RIGHT`
> `A` `B` `X` `Y` `L1` `L2` `R1` `R2` `SELECT` `START` `MENU`, and `L` / `R` for both shoulders on a
> side. For the shoulders on X and Y: `"L": ["X"], "R": ["Y"]`. A file from an older version that
> lists them under `keyboard`, with names like `"Left Shift"`, still works.

### Key repeat

```json
"repeat": { "delay": 400, "interval": 32 }
```

How a held direction (or A/B + direction) repeats, in milliseconds. **delay** is the wait before it
starts repeating (100–2000). **interval** is the gap between repeats at full speed (16–500): the
repeat starts at twice that and speeds up to it over about a second. Smaller is faster. A value out
of range is pulled back into it, and the log says so.

### Default folders

```json
"folders": {
  "samples":     "Samples",
  "soundfonts":  "Soundfonts",
  "instruments": "Instruments",
  "projects":    "Projects",
  "themes":      "Themes"
}
```

Sets the folder each **load** browse starts in. If your samples live somewhere outside the
PocketTracker folder, this saves climbing out of it every time.

**A plain name is inside your PocketTracker folder**, and can be several levels deep:
`"samples": "Samples/Packs/Breaks"` starts a sample load two folders down. This is how the starter
file is written, and it is what makes the file portable — copy it to another device and it still
means the same thing.

**A path beginning with `/` (or a Windows drive, `C:\Music`) is used exactly as written**, so a
sample library that lives nowhere near PocketTracker is still one line away.

A folder that doesn't exist — or that this device cannot read — is ignored, and that category quietly
falls back to its default. A typo, a folder you've since moved, or a config file carried over from
another machine costs one convenience, never a broken file browser.

**A path written under someone else's PocketTracker folder still works.** If the file came off another
device, or was written before this one moved its home folder, a value like
`/storage/emulated/0/Documents/PocketTracker/Samples` is matched up to its `PocketTracker/` part and
re-read against *your* home folder — the same thing that happens to the sample paths inside a project
you copy between devices. Only the part below `PocketTracker/` is kept, so a folder that was never
inside one falls back to the default instead of being guessed at.

> **On Android**, a folder outside your home folder has to be granted before the app can see it —
> `ADD FOLDER...` at the top of the browser (section 2). Reaching one that way is easier than naming
> it here: the granted path is not something you can type, and a plain `/storage/emulated/0/...` path
> is not readable at all unless it is inside the folder you granted.

This changes only where browsing **starts**. It does not move where anything is **saved** — renders,
exports and sample-editor saves keep their own folders.

> **Related:** the SETTINGS screen's **FOLDER** row (`REMEMBER` / `REFRESH`) is a separate, smaller
> convenience — with `REMEMBER`, a sample load reopens at the folder you last loaded a sample from,
> for that session. It takes priority over `folders.samples` once you've loaded something.

---

## Appendix: Controls Cheat Sheet

*Print this page and keep it handy.*

---

### UNIVERSAL — work on every screen

| Input | Action |
|---|---|
| D-pad | Move cursor |
| A | Insert / confirm |
| A + LEFT / RIGHT | Edit value (+1 / −1) |
| A + UP / DOWN | Edit value (+16 / −16, or ±1 octave for notes) |
| A + B | Delete / clear value |
| B | Cancel / back / delete |
| START | Play / Stop |

---

### SCREEN NAVIGATION

| Input | Action |
|---|---|
| R + RIGHT / LEFT | Move between columns (SONG → CHAIN → PHRASE → INST → TABLE) |
| R + UP | Move to screen above in current column |
| R + DOWN | Move to screen below in current column |

**Quick nav:**

| From | To | How |
|---|---|---|
| Any Row 2 screen | GROOVE | R + UP (column 2) |
| INSTRUMENT | MODULATION | R + UP (column 3) |
| Any Row 2 screen | MIXER | R + DOWN |
| MIXER | EFFECTS | R + DOWN |
| SONG or CHAIN | PROJECT | R + UP (column 0 or 1) |

**Popup screens:**

| Screen | How to open |
|---|---|
| SAMPLE EDITOR | INSTRUMENT → TYPE row → cursor on **EDIT >** → **A** |
| EQ EDITOR | INSTRUMENT / INST.POOL / MIXER / EFFECTS → cursor on EQ → A; close with B |
| SETTINGS | PROJECT → cursor on SETTINGS → A |
| THEME EDITOR | SETTINGS → cursor on THEME → A |

---

### CONTEXT NAVIGATION — B + D-pad

| Input | Screen | Action |
|---|---|---|
| B + LEFT / RIGHT | PHRASE | Previous / next phrase |
| B + LEFT / RIGHT | CHAIN | Previous / next chain |
| B + LEFT / RIGHT | INSTRUMENT | Previous / next instrument |
| B + LEFT / RIGHT | TABLE | Previous / next table |
| B + LEFT / RIGHT | GROOVE | Previous / next groove |
| B + LEFT / RIGHT | MODULATION | Previous / next instrument (mods follow) |
| B + UP / DOWN | SONG | Page up / down (16 rows) |
| B + UP / DOWN | INSTRUMENT, MODULATION | Jump 16 instruments |
| B + UP / DOWN | TABLE | Jump 16 tables |

---

### COPY / PASTE — PHRASE, CHAIN, SONG, TABLE

| Input | Action |
|---|---|
| L + B | Enter selection mode (tap again: CELL → ROW → SCREEN) |
| B *(in selection)* | Copy, exit selection |
| L + A *(in selection)* | Cut (copy + clear), exit selection |
| L + A *(outside selection)* | Paste at cursor |
| A + B *(in selection)* | Delete selection (no clipboard), exit |
| A + LEFT / RIGHT *(in selection)* | Increment / decrement all selected values |
| L + B + A | Deep-clone the chain / phrase under the cursor |
| L + D-pad | Fill rows from one cell (PHRASE) |
| L + R *(in selection)* | Leave selection mode; the copy buffer survives |
| L + R *(outside selection)* | Clear the copy buffer |

---

### PLAYBACK

| Input | Action |
|---|---|
| START | Play / Stop |
| START on SONG | Play from current row |
| START on CHAIN | Play current chain |
| START on PHRASE, INSTRUMENT, MODULATION, TABLE | Play current phrase (loops) |
| R + START on CHAIN, PHRASE, INSTRUMENT, MODULATION, TABLE | Play the whole song |
| A + START on INSTRUMENT, MODULATION, TABLE | Preview instrument |
| START on SAMPLE EDITOR | Preview sample |
| START in file browser | Preview highlighted WAV |

---

### FILE BROWSER

| Input | Action |
|---|---|
| D-pad UP / DOWN | Move through files / folders |
| A | Load file / enter folder |
| A on `..`, or R + LEFT | Go up one directory level |
| B | Close the browser |
| START | Preview highlighted WAV |
| SELECT + A | Rename |
| SELECT + B | Delete, or delete the selection (asks first) |
| SELECT + R | New folder |
| L + B | Start a file selection (tap again: select all) |
| B *(in selection)* | Copy the selected files |
| L + A *(in selection)* | Cut them |
| L + A *(outside selection)* | Paste them here |
| L + R | Cancel the file selection |

---

### SONG SCREEN

| Input | Action |
|---|---|
| A | Insert last-used chain ID |
| A + LEFT / RIGHT | ±1 chain ID |
| A + UP / DOWN | ±16 chain IDs |
| A + B | Delete (set to --) |
| B + UP / DOWN | Page up / down (16 rows) |

---

### CHAIN SCREEN

| Input | Action |
|---|---|
| A | Insert last-used phrase / TSP |
| A + LEFT / RIGHT | ±1 |
| A + UP / DOWN | ±16 (PHR), ±12 semitones (TSP) |
| A + B | Delete slot |
| B + LEFT / RIGHT | Previous / next chain |

---

### PHRASE SCREEN

| Input | Action |
|---|---|
| A | Insert last-used note / value |
| A + LEFT / RIGHT | ±1 semitone (note), ±1 (other) |
| A + UP / DOWN | ±1 octave (note), ±16 (other) |
| A + B | Delete value |
| B + LEFT / RIGHT | Previous / next phrase |

---

### INSTRUMENT SCREEN

| Input | Action |
|---|---|
| A (on TYPE row, LOAD) | Open file browser |
| A (on TYPE row, EDIT >) | Open SAMPLE EDITOR |
| A (on NAME) | Edit instrument name |
| A (on EQ) | Open EQ EDITOR |
| A + LEFT / RIGHT | Edit current parameter |
| A + B | Reset to default |
| B + LEFT / RIGHT | Previous / next instrument |
| B + UP / DOWN | Jump 16 instruments |

---

### SAMPLE EDITOR

| Input | Action |
|---|---|
| R + UP / DOWN | Zoom in / out, from any row |
| A + LEFT / RIGHT | Zoom in / out (cursor on the ZOOM cell) |
| A + D-pad (on START / END) | Move the selection marker — LEFT/RIGHT fine, UP/DOWN coarse |
| A + D-pad (on slice position) | Move the boundary — LEFT/RIGHT fine, UP/DOWN coarse |
| A + B (on slice row) | Delete the boundary (MANUAL), or reset it (TRANSIENT / DIVIDE) |
| A (on slice row, while playing) | Cut a boundary at the playhead (MANUAL) |
| A (on EQ-effect slot) | Open EQ EDITOR |
| START | Preview sample |
| B | Close (asks first if there are unsaved changes) |

---

### TABLE SCREEN

| Input | Action |
|---|---|
| A + LEFT / RIGHT | Edit value |
| A + B | Delete value |
| B + LEFT / RIGHT | Previous / next table |
| B + UP / DOWN | Jump 16 tables |
| L + B | Enter selection mode |

---

### GROOVE SCREEN

| Input | Action |
|---|---|
| D-pad UP / DOWN | Move between rows |
| D-pad RIGHT / LEFT | Move into the panel and back |
| A | SAVE / LOAD, or add a step on a `--` row |
| A + LEFT / RIGHT | Edit tick value, pick a built-in groove, or set QNT |
| A + UP / DOWN | Large step |
| A + B | Clear row, or back to STRAIGHT |
| B + UP / DOWN | Set QNT |
| B + LEFT / RIGHT | Previous / next groove |

---

### MODULATION SCREEN

| Input | Action |
|---|---|
| D-pad UP / DOWN | Move between parameters |
| D-pad LEFT / RIGHT | Switch between paired slots |
| A + LEFT / RIGHT | Edit value |
| A + UP / DOWN | Large step |
| A + B | Reset to default |
| B + LEFT / RIGHT | Previous / next instrument |
| B + UP / DOWN | Jump 16 instruments |

---

### MIXER SCREEN

| Input | Action |
|---|---|
| D-pad LEFT / RIGHT | Select track column |
| D-pad UP / DOWN | Move between rows |
| A + LEFT / RIGHT | ±1 |
| A + UP / DOWN | ±16 |
| A (on master EQ) | Open EQ EDITOR |

---

### EQ EDITOR

Open with **A** on an EQ cell.

| Input | Action |
|---|---|
| D-pad LEFT / RIGHT | Switch between bands 1–3 |
| D-pad UP / DOWN | Move between parameters |
| A + LEFT / RIGHT | Edit value |
| A + UP / DOWN | Large step |
| B + LEFT / RIGHT | Switch EQ preset slot |
| B | Close and apply |

---

### THEME EDITOR

| Input | Action |
|---|---|
| D-pad UP / DOWN | Move between color rows |
| D-pad LEFT / RIGHT | Move between R / G / B (color rows) or name / SAVE / LOAD (row 0) |
| A + LEFT / RIGHT | ±1 to selected channel |
| A + UP / DOWN | ±16 to selected channel |
| B | Close |

---

### EFFECTS QUICK REFERENCE

| Code | Name | Value | Notes |
|---|---|---|---|
| ARP | Arpeggio | `XY` = intervals | Persists — cancel with `ARP 00` |
| ARC | Arpeggio Config | `XY` | High nibble=mode (0=UP 1=DN 2=PP 3=RND), low=speed |
| CHA | Chance | `XY` | X = chance of the nearest filled FX to its left (or the note), Y = to its right (0=never F=always) |
| NTH | Nth Pass | `XY` | The row plays on pass X of every Y passes of its phrase (Y=0: on pass X only). Phrase only |
| LAT | Latency | `XX` ticks | Delays row trigger |
| GRV | Groove | `XX` | Assigns groove to this track |
| HOP | Hop/Jump | `XY` | Phrase: next phrase starts at row Y (FF=stop track). Table: jump to row Y, X times (0=forever) |
| KIL | Kill | `XX` ticks | Stop after XX ticks (00=now, 0C=next step) |
| OFF | Offset | `XX` | Sample start position jump |
| PIT | Pitch Offset | `XX` signed | 00–7F up, 80–FF down |
| PSL | Pitch Slide | `XX` ticks | Portamento |
| PBN | Pitch Bend | `XX` | 00–7F up, 80–FF down — **persists** |
| PVB | Vibrato | `XY` | X=speed, Y=depth — **persists** |
| PVX | Extreme Vibrato | `XY` | 4× deeper, 2× faster than PVB |
| RPT | Repeat/Retrigger | `XY` | Y=0: every X ticks; Y≠0: fade — **persists** |
| RND | Randomize | `XY` | Adds `00`–`XY` at random to the last FX above it in the column |
| RNL | Randomize Left | `XY` | Adds `00`–`XY` at random to the FX on its left; in FX1, `X` = note, `Y` = instrument |
| SLI | Slice Index | `XX` | Direct slice selection |
| TBL | Table Set | `XX` | Override instrument's table |
| THO | Table Hop | `XX` | Jump table to row 0X |
| TIC | Tick Rate | `XX` | Table speed (00=trigger 06=default FC=octave FE=note FF=200Hz) |
| VOL | Volume | `XX` | Immediate volume at this tick |
| PAN | Pan | `XX` | Per-note pan (00=L 80=center FF=R); next note reverts |
| BCK | Direction | `0X` | Sampler: 00=reverse 01=forward; flip live to scratch |
| REV | Reverb Send | `XX` | Per-note reverb send level |
| DEL | Delay Send | `XX` | Per-note delay send level |
| EQN | EQ (note) | `XX` | Per-note EQ preset slot (00–7F) |
| EQM | EQ (mixer) | `XX` | Master EQ preset slot; holds till next EQM, resets on stop |
| VTR | Track Fader | `XX` | This track's MIXER fader; replaces it, **persists**, restored on stop |
| VMV | Master Fader | `XX` | The master fader, from any track; replaces it, **persists**, restored on stop |
| TIM | Delay Time | `XX` | The delay's echo time (00–FF = 0–2 s), from any track; the repeats bend in pitch as it moves. Replaces the DELAY screen's time, **persists**, restored on stop |
| AUS | Automation Start | `XX` = curve | Fades the automatable effect to its LEFT (00=ease-in 80=linear FF=ease-out) |
| AUF | Automation Finish | `XX` | Destination value; a later step, may be a later phrase of the same chain |
| CUT | Filter Cutoff | `XX` | This note's filter cutoff (20 Hz–20 kHz, log). Needs a FILTER TYPE on the instrument |
| RES | Filter Resonance | `XX` | This note's filter resonance. Needs a FILTER TYPE on the instrument |
| LPF | Low-Pass On | `XX` | Switches a low-pass on for this note at cutoff `XX` |
| HPF | High-Pass On | `XX` | Switches a high-pass on for this note at cutoff `XX` |
| BPF | Band-Pass On | `XX` | Switches a band-pass on for this note at centre `XX` |
| DRV | Overdrive | `XX` | This note's overdrive, `00` clean to `FF` heavy |
| CRU | Crush + Downsample | `XY` | `X` = bits crushed, `Y` = rate drop; both `0` = clean |
| FIN | Fine Tune | `XX` | `80` in tune, a semitone either way; retunes a note already playing |
| TSX | Transpose Multiplier | `XX` | How far TSP moves this note: `01` normal, `00` not at all, `FF` the other way. Phrase only |
| INS | Instrument | `XX` | This note plays instrument `XX` (00–7F); randomize it with RND or RNL. On a table row it hands the note on to that instrument and its table |
| SCA | Track Scale | `XY` | Puts this track on scale `Y` in key `X` (`0`=C … `B`=B); resets on stop |
| SCG | Global Scale | `XY` | The same for all eight tracks |
| MPG | MIDI Program | `XX` | Program change (00–7F) on an EXTERNAL instrument's channel |
| MPB | MIDI Bend | `XX` | Pitch bend position (00=down 80=centre FF=up); EXTERNAL only, centred on stop |
| CCA–CCD | MIDI CC slot | `XX` | Value for the controller in the EXTERNAL instrument's CC A–D row |

---

### HEX / NOTE QUICK REFERENCE

```
 Dec  Hex  |  Dec  Hex
   0   00  |  128   80
  16   10  |  160   A0
  32   20  |  192   C0
  64   40  |  224   E0
  96   60  |  255   FF
```

```
Note offsets:  C   C#  D   D#  E   F   F#  G   G#  A   A#  B
               00  01  02  03  04  05  06  07  08  09  0A  0B
```

- **Middle C** = `C-4` = MIDI 60
- **Full volume** = `FF` · **PAN center** = `80`
- **+1 octave** = +12 semitones = `0C`
- **+1 perfect fifth** = +7 semitones = `07`

---

*PocketTracker is open-source (GPL-3.0). Contributions and bug reports welcome.*
