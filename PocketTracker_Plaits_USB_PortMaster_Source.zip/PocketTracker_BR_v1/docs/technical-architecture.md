# PocketTracker — Technical Architecture

How PocketTracker is built. This document describes the system as it currently works.

**Audience:** developers and contributors.

---

## Table of Contents

1. [Overview](#overview)
2. [Source Layout](#source-layout)
3. [The Seams](#the-seams)
4. [Audio Engine](#audio-engine)
5. [Songcore — the platform-free runtime](#songcore--the-platform-free-runtime)
6. [The Event Bus](#the-event-bus)
7. [Data Model and File Formats](#data-model-and-file-formats)
8. [UI Layer](#ui-layer)
9. [Input Layer](#input-layer)
10. [Rendering and Export](#rendering-and-export)
11. [Platform Shells](#platform-shells)
12. [Built to Be Measured](#built-to-be-measured)
13. [Build](#build)
14. [Coding Conventions](#coding-conventions)

---

## Overview

PocketTracker is **one C++17 program with four thin platform shells**. The audio engine, the
sequencer, the document model, the file formats and the entire user interface are portable C++ with
no platform dependency at all. A shell provides a window, an audio device, a clock, buttons and a
filesystem root — and nothing else.

```
                    ┌─────────────────────────────────────────────┐
                    │  native/ui   (pt-ui)                        │  the whole UI: screens,
                    │  no SDL, no POSIX, no window, no engine*    │  cursor, input dispatch
                    ├─────────────────────────────────────────────┤
                    │  native/songcore                            │  document, sequencer,
                    │  platform-free                              │  event bus, render, I/O
                    ├─────────────────────────────────────────────┤
                    │  native/  (the engine)                      │  voices, modulation, DSP
                    └─────────────────────────────────────────────┘
                       ▲            ▲             ▲            ▲
            ┌──────────┴──┐  ┌──────┴──────┐  ┌───┴──────┐  ┌──┴──────────┐
            │ shell/      │  │ shell/      │  │ shell/   │  │ shell/      │
            │ Android SDL │  │ PortMaster  │  │ Linux    │  │ Windows     │
            └─────────────┘  └─────────────┘  └──────────┘  └─────────────┘
```

\* one file in `pt-ui` includes the engine: `ui/engine_feed.h`, the 60 Hz read-back of scope samples
and meters. Every screen module takes plain pointers, and a null pointer draws silence — which is
what lets a headless tool render any screen with no engine in the process.

**Android has no Kotlin UI.** `app/src/main/java` is a seven-file shim: `MainActivity` (an
`SDLActivity` subclass that owns the splash, the folder grants and the settings import), the virtual button
skin's sound and haptic managers, the two MIDI device managers, `PadClassifier` (decides whether an
attached device is a real controller, which picks the touch UI or the full layout), and
`VirtualButton` (the enum whose ordinals the JNI feedback call passes, mirroring `ui/buttons.h`).
Everything a user sees is drawn by `pt-ui` into a software framebuffer.

---

## Source Layout

```
native/                            The portable program
├── audio-engine.cpp / .h          The engine: lifecycle, scheduling, modulation, meters, buses
├── engine-mix.cpp                 processAudioBlock: the queue drain, the triggers, every voice's mix
├── engine-tables.cpp              The table walk, the INS chain, the TABLE screen's row readout
├── engine-samples.cpp             The sample pool: loading, clearing, the memory count
├── engine-soundfont.cpp           The SoundFont bank: parsing a preset, the slot cache
├── engine-voice-ops.h             Per-voice writes the table walk and the drain share
├── audio-decoders.cpp / .h        WAV, MP3, FLAC, OGG, Opus, M4A decoding
├── sampler-voice.h                Per-voice state for sample playback
├── soundfont-voice.cpp / .h       Per-voice state for SF2/SF3 (TinySoundFont — see the note below)
├── note-queue.h                   Sample-accurate note + parameter scheduling queues
├── sample-editor.cpp              Destructive waveform operations
├── transient-detector.cpp         Slice-point detection
├── oboe-audio-engine.cpp / .h     Android audio backend (the only Oboe-coupled TU)
├── mods/                          Modulation: routing, runner, AHD/ADSR/LFO/vibrato/tracking
├── effects/                       DSP, three layers:
│   ├── instrument-chain.h           per voice: Crush → Drive → Filter
│   ├── send-chain.h                 send buses: reverb (DaisySP ReverbSc) + stereo delay
│   ├── master-chain.h               output bus: masterEq → OTT | DUST → Limiter
│   ├── primitives/                  biquad, filter, vendored DaisySP
│   └── modules/                     FilterModule, DriveModule, BitcrushModule, DustChain
│
├── common/                        Below every layer: pt_fopen and the URI hooks, the memory
│                                  probe a load asks first, a slow load's progress and cancel
│
├── songcore/                      Platform-free. No SDL, no JNI, no POSIX.
│   ├── model.h                      Project, Chain, Phrase, Table, Groove, Instrument, Note
│   ├── project_io.h                 .ptp / .pti parse + emit (minified), and JsonWriter
│   ├── project_ops.h                Compact, transitive table walks, slot surgery
│   ├── timing.h                     frames_per_step / _tic, groove timing, transpose
│   ├── effects.h                    Effect codes, names, EFFECT_TYPES, resolve_step_params
│   ├── automation.h                 AUS/AUF: the automatable registry, the curve, the pairing
│   ├── table_automation.h           AUS/AUF over a table's rows — shared by the engine and the editor
│   ├── traversal.h                  Song walks, collect_used_instruments
│   ├── rng.h                        PCG32, seeded and bounded like kotlin.random
│   ├── event.h                      The event schema (versioned, frozen)
│   ├── router.h                     MidiRouter, IMidiConsumer, TrackInstruments
│   ├── scheduler.h / .cpp           The sequencer: phrases, chains, song, transport
│   ├── engine_consumer.h            Events → engine calls
│   ├── voice_derive.h               Note → voice parameters
│   ├── engine_setup.h               Project → engine push (instruments, buses, EQ bank)
│   ├── host.h / .cpp                SongcoreHost — the one runtime object a shell constructs
│   ├── render.h / wav_writer.h      Offline render, WAV output
│   ├── midi_out.h / midi_in.h       The MIDI seams, serializer, parser, router
│   ├── midi_clock.h                 24 PPQN clock, transport, song position
│   ├── trace_writer.h               Conformance trace serializer
│   └── note_tables.h                Baked pitch tables (bit-exact across toolchains)
│
└── ui/                            pt-ui — the UI, portable C++ with no platform anything
    ├── canvas.h / .cpp              FOUR primitives: fill rect, stroke rect, text, clip
    ├── app_state.h                  The one mutable UI state object
    ├── platform_caps.h              Which features this build has (a VALUE, not an #ifdef)
    ├── screen.h / navigation.h      Screens and the R+DPAD navigation grid
    ├── cursor.h / cursor_move.h     CursorContext: what is under the cursor, and how it steps
    ├── input_dispatcher.cpp / .h    Every button and combo: one class, its spine here
    ├── dispatch/                    …its gesture bodies, and route.cpp: the layer stack and the
    │   ├── layers/                  screen table. One file per modal (dialogs, editors, pickers)
    │   └── screens/                 and per screen: its buttons, cursor and edits
    ├── selection.h / clipboard.*    Multi-cell selection and copy/paste
    ├── layout.cpp / .h              Screen composition, top strip, right bar
    ├── theme.h / theme_io.h         Palettes and the theme file
    ├── settings_store.*             settings.json
    ├── font5x5.h                    The pixel font
    ├── filesystem.h                 The file I/O interface a shell implements
    └── modules/                     One module per screen (song, chain, phrase, table, groove,
                                     instrument, instrument pool, modulation, mixer, effects, eq,
                                     sample editor, settings, project, midi, file browser,
                                     qwerty keyboard, oscilloscope, nav map, fx helper, confirm)

shell/                             The only SDL in the tree
├── main.cpp                       Desktop / handheld entry point
├── app.cpp / .h                   The shared frame loop, signal handling, config
├── sdl/                           The device: video, audio, input, touch
├── skin/                          Presentation: skins, CRT overlay, button font, images, assets
├── midi/                          The platform-free half of MIDI in and out, and the sender thread
├── android/                       SDL_main, the SAF filesystem, MIDI over JNI
├── linux/                         ALSA MIDI (libasound loaded at runtime, no link-time dependency)
├── windows/                       ASIO output, winmm MIDI, the exe's icon and manifest
├── miyoo/, portmaster/            Handheld launch scripts and metadata
└── build-*.sh, build-windows.ps1, Dockerfile.*, toolchain-*.cmake

app/                               Android: manifest, resources, and a seven-file Kotlin shim
docs/                              The manual, this document, and the licence notices
```

> **TinySoundFont carries five local changes**, all marked in `vendor/tsf/tsf.h`, and all of them must
> be **re-applied on any tsf update**.
>
> 1. It records the length of the sample buffer it allocates (`fontSampleCount`, plus a
>    `tsf_get_fontsamplecount()` accessor); upstream computes that number during load and then
>    discards it. Without it a loaded font's PCM is unmeasurable, and the engine's USED RAM total
>    would silently omit the largest thing it holds.
> 2. The accumulating sample buffer the SF3 decoder fills grows **geometrically** instead of by
>    upstream's fixed 1 M-element step. The step makes the realloc count linear in the decoded size and
>    the bytes copied quadratic — a cost paid only where `realloc` copies. glibc and bionic serve a
>    multi-megabyte block from `mmap` and grow it with `mremap`, so nothing moves; the MSVC CRT copies
>    every time, which is why the symptom was ever only visible on Windows. The factor is 1.5× and not
>    2×, because a `realloc` holds the old block and the new one at once and it is that sum a small
>    device runs out of.
> 3. A failed `realloc` in the Ogg decoder leaves the buffer for its caller to free. Upstream frees it
>    and returns, and the caller frees the same pointer again — unreachable until an allocator that can
>    actually refuse is installed underneath, which this project does.
> 4. The SF3 decode reports progress and can be stopped, one call per sample header. There is no
>    callback in the API to hang that on, and the loop is the only place with a usable granularity.
> 5. **Samples are stored as 16-bit, not `float`.** Both sources are 16-bit — an uncompressed SF2
>    stores shorts, and an SF3's Vorbis streams were encoded from them — so widening on load doubles
>    the resident cost of every font and buys no precision. The scale back to −1..1 is folded into the
>    per-block voice gain rather than applied per sample, which is exact because everything between the
>    fetch and that gain (the interpolation, the lowpass) is linear.

---

## The Seams

Four interfaces are all a platform has to implement. Everything else is shared code.

| Seam | Header | What a shell provides |
|---|---|---|
| **Canvas** | `ui/canvas.h` | Nothing — the canvas is a software framebuffer the UI owns. The shell scales the finished 640×480 frame onto a texture. |
| **Filesystem** | `ui/filesystem.h` | Directory listing, read, write, and the app root. `ui/std_filesystem.*` is the `std::filesystem` implementation the desktop and handheld shells use. |
| **Audio** | `audio-backend.h` | A device that calls `processAudioBlock`. Oboe on Android, SDL audio elsewhere. |
| **MIDI** | `songcore/midi_out.h`, `midi_in.h` | A port that moves bytes. winmm, ALSA and Android backends exist. |

Two design rules make this hold:

**The canvas has exactly four primitives, permanently.** Fill rect, stroke rect, bitmap text, clip.
That is all the UI has ever used, and keeping it at four is what makes a new platform a rendering
back end rather than a port. Skinning, scaling and post-processing happen shell-side, on the
finished frame.

**Platform differences are a VALUE, not an `#ifdef`** (`ui/platform_caps.h`). Which SETTINGS rows
exist, whether PROJECT has an EXIT row, whether the MIDI surfaces can be authored — all fields on a
`PlatformCaps` struct. The same compiled code answers every platform's question, which is what lets
a headless tool drive any platform's UI and compare the results.

---

## Audio Engine

A sample-accurate queue system in C++.

- **Stereo float, at the device's own rate.** A rate is asked for, never assumed: whatever the device
  negotiates is what the engine is told, and every pitch ratio and filter coefficient is derived from
  it rather than from a constant. Android uses Oboe (AAudio Exclusive, which takes the direct MMAP
  path where the device has one, then OpenSL ES Exclusive → Shared → None/Shared); every other
  platform uses SDL audio. A device whose AAudio open ever took over 3 s stays on OpenSL ES — a
  marker file in private storage, written before the attempt, so a hang counts too.
- **The audio device is opened once, at startup.** It is reopened only by the frame loop — after
  Android backgrounds the app with nothing playing, or when the backend reports the device lost.
- **On Android the frame loop keeps running off the screen** (`SDL_HINT_ANDROID_BLOCK_ON_PAUSE` off),
  drawing nothing, so a song left playing is still fed by the lookahead pump. It may keep its stream
  only while the playback foreground service holds the process — a frozen process loses its stream
  silently — and that service is started by Java in `onPause`, the last moment Android allows it.
- `AudioEngine` **must be heap-allocated** — its DSP scratch buffers, spectrum rings and 256-slot
  table pool blow a 1 MB stack instantly.

### The one processing rule

**All DSP happens in `processAudioBlock`.** `onAudioReady` (Oboe), the SDL callback and
`renderOffline` are thin wrappers around it, and none of them contains signal processing. It is also
the **only** place the note and parameter queues drain. A second drain point is a second timeline.

The three queues — parameters, kills, notes — **are one timeline**, and each yields to whatever is due
earlier in the ones after it. Frames equal, the written order stands: parameters, then kills, then
notes. That order is what lets a per-voice effect be stamped one frame behind its note so it reaches
the voice the note starts rather than the one it replaces, and what lets a `K00` share its step's
frame and still cut only the note before it. Frames unequal — which is any event the block has already
passed, and the first step of a take can be one — the earlier frame goes first regardless of which
queue it came from. Draining each queue to exhaustion in turn would collapse them all onto one frame
index and apply them in queue order instead, which silently drops every effect whose note has not
started yet.

**The audio thread waits for nothing, allocates nothing and frees nothing, and the UI never writes
what it reads.** A setter records its value and publishes it — per-instrument data and the tables in a
two-sided copy (`StagedTable`, `TableStore`), the bus settings as one sequence-locked record whose
groups each carry a number — and the block takes it in right after the queues drain, so an edit made
before an event was queued is in force when that event runs. The screen reads the voices the same
way, from a view the block publishes as it ends. What has to be built or freed goes by handover
instead: a reverb engine is built by the control thread and taken at the next block, a SoundFont is
closed only after the block that might hold its handle has ended, and a replaced sample buffer ends
the voices still pointing at it through a per-slot generation rather than a stop from the UI.

### Signal path

```
  voice ─► instrument chain (Crush → Drive → Filter) ─► instrument EQ ─┬─► track fader ─┐
                                                                       ├─► reverb bus ─┤
                                                                       └─► delay bus ──┤
                                                                                       ▼
                                    out ◄─ Limiter ◄─ OTT | DUST ◄─ master EQ ◄─ MASTER FADER
```

Reverb and delay are **send buses**, not inserts: a per-note or per-instrument send amount feeds
them, and the delay can additionally feed the reverb. Both have their own input EQ. `-1` is the
documented bypass value for every EQ slot.

The reverb's SIZE stretches all eight of its delay lines by one factor, and ⚠️ **the loop gain is
derived from DCAY and SIZE together** — a gain is a loss per pass, so the same gain in a longer room
is a longer tail. The lines are sized once for the largest room, so a SIZE edit is a glide of the read
heads rather than a reallocation or a clear, and the default cell is exactly the room that shipped.

Note where the two faders sit relative to that tap. A send is **pre-fader with respect to the track
fader** and post-everything on the instrument, so pulling a track down leaves its tails alone. The
**master fader is downstream of the returns** — it multiplies the summed bus, dry and wet together,
which is what makes it a master rather than a dry-mix gain. ⚠️ It is therefore one multiply over the
whole block and not a per-voice gain: `VMV` and a `VTR`/`VMV` automation ramp both move it through the
parameter queue, which drains once per block, so a per-voice application would buy no extra
resolution and would silently exclude the returns.

The **metronome is the one thing that is not on that path at all.** Its click is summed in below the
limiter, carries no event, and is muted whenever `isOfflineRendering` is set — so it is never
compressed by the master chain, never visible to the trace tools, and never written into an export.
Its grid is a quarter note measured from the transport's own start frame, which is the same grid the
24 PPQN MIDI clock runs on; groove is per track and moves neither of them.

### Voices

Two voice types — `SamplerVoice` and `SoundfontVoice` — both driven by the same note path. A
dedicated **preview lane** (voice 9) carries auditions, so hearing a note you are dialling in never
steals a voice from the song.

Note-offs are **KIL-only**, plus a live MIDI key release. There is no step-end note-off: an ADSR or
TRIG voice rings until something explicitly stops it.

**A SoundFont slot holds ONE PRESET, not a file.** `soundfont-trim.h` reads a SoundFont's index —
the small tables at the end of the file that say which samples each preset reaches — and writes a
complete, minimal SoundFont in memory holding just the chosen preset and its sample bytes; tsf parses
that, unmodified and unaware. The index costs kilobytes where the bank costs hundreds of megabytes,
which is what lets the instrument screen list the patches in a file nothing has loaded, or could load.

⚠️ **The identity of a slot is therefore `(path, bank, preset)`, not the path.** Two instruments on
one `.sf2` at different patches are two slots; matching on the path alone hands the second one whatever
loaded first, and the only symptom is the wrong instrument playing. The same triple keys the sharing
guards that decide when a slot may be freed.

⚠️ **A file the trimmer cannot cut apart loads whole**, which is the behaviour that predates this and
is still correct — a false answer from the trimmer means "not this layout", never "broken file".

⚠️ **Parsing a preset and owning a slot are separate jobs on separate threads.** A compressed preset
still has to be Vorbis-decoded, which does not fit in a frame, so the parse runs on a worker and only
the slot table's own thread chooses, evicts and publishes. The instrument goes on playing what it had
until the new handle arrives. One parse runs at a time — tsf's allocator guard, its progress sink and
its cancel are per-process hooks — and a load the user is *watching*, with a progress bar and a cancel,
is still made synchronously on the thread that draws it.

⚠️⚠️ **The frames just PAST a sample are what the two layouts exist to control.** Regions routinely
read a little beyond their own data: a loop end a frame past the stream, an `endAddrsOffset`
generator, the interpolator's lookahead. In a whole bank those frames belong to the next sample; in a
font holding one preset there is no next sample, so the read has to land on silence instead. An
uncompressed sample is copied with the spec's silent padding after it. A compressed one cannot be
padded from the inside — its decoded length is not in the header — so it is followed in the sample
TABLE by a silent sample header, which puts zeros in the decoded buffer exactly where the overrun
reads; tsf decodes the table in order, so the two are equivalent by the time a region indexes them.

⚠️ **A compressed font's sample chunk is also padded to an even length**, and that is not RIFF's own
pad byte: tsf's chunk walk advances by exactly the declared size and does not know about it, so an
odd chunk leaves the stream one byte adrift and everything after the samples — `pdta` included — is
never read. Uncompressed sizes are frames × 2 and cannot be odd; Ogg streams are any length at all.

---

## Songcore — the platform-free runtime

`native/songcore/` has no platform dependency whatsoever. It is the whole program minus the pixels
and the device. It is headers, except the sequencer's and the host's bodies (`scheduler.cpp`,
`host.cpp`), which build as the `songcore` library.

`SongcoreHost` (`host.h`) is the object a shell constructs. It owns the one `Project` in the process,
the sequencer, the engine consumer, the external MIDI consumer and the transport. There is exactly
**one mutable copy of the document** — `AppState` holds a pointer, never a copy, and the UI edits the
host's project in place. Two mutable copies of a document is a desync waiting to happen.

### The sequencer

`scheduler.h` walks the song. It schedules ahead by a lookahead window, tracks per-track state
(current chain, phrase, step, table row, groove position), applies effects, resolves chance and
randomization, and emits **events** rather than engine calls.

The window is short — `Sequencer::HORIZON_MS`, filled a phrase row at a time — so an edit is heard
from the next row not yet scheduled, and **an edit never rewinds the walk**: what is already scheduled
plays as it was. Only the frame loop's poll refills the window: anything that holds the UI thread
longer calls `InputDispatcher::before_long_operation()` first, which fills deeper. No edit can arrive
while the thread is blocked, but the depth outlives the operation — an edit made just after it waits
for the walk to get past it — so a save, which fits inside the window, only tops it up.

Timing is frame-based: `frames_per_step` and `frames_per_tic` derive from the tempo, and grooves
change a step's length per position. A groove counts its lengths in a ruler of its own (6, 12 or 24
tics to the plain step); an effect's tic is always a twelfth of the step it is in, so no effect
changes meaning when a track changes groove. Everything downstream is stamped in frames.

**Mute and solo never reach the sequencer.** A muted track is scheduled exactly like any other; the
gate is `AudioEngine::setTrackMuted`, folded into the track's gain where the audio block snapshots it,
so it lands within one block and silences voices already ringing. Routing mute through the scheduler
instead looks equivalent and is not: note-offs are KIL-only, so the voice playing when a track is
muted is gated rather than stopped, and a scheduler that stops triggering has nothing else to reveal
when the gate lifts — unmuting mid-phrase brings back that one stale note and holds it until the next
phrase boundary. The offline render is the single exception, deliberately: `scheduleSongRowRange`
skips an inaudible track outright, because an export is a file you keep.

The chord addresses ten channels, not eight: the reverb and delay **returns** carry the same mute and
solo flags, in a solo set of their own — soloing a track must leave the returns alone, and soloing a
return must not stop a track. A soloed return silences the dry mix through one gate over the summed
bus, placed below every send tap and above the returns. Expressing that as eight track mutes would
starve the return being soloed: the SoundFont send tap sits below its track's gate, and the offline
render skips an inaudible track outright, so the reverb would be soloed into silence.

**A song row the walk cannot enter is the end of a BLOCK, and the boundary is derived in one place.**
A track runs its own run of consecutive playable cells and loops back to that run's first row for
ever; there is no whole-song restart, and therefore no unit of work that moves all eight tracks at
once. That mattered structurally: the restart needed a rollback record of its own precisely because it
was the one multi-track unit, and a per-track loop is an ordinary unit with an ordinary checkpoint
behind it. ⚠️ A cell naming a chain whose **first** row is empty is a boundary too — the one case
where "the cell names a chain" is not enough — while a later hole in the same chain is still walked
over. Three sites ask the question (the start, the step down, the walk back up) and all three ask the
same predicate, so none of them can drift.

⚠️ **The bounded walk and the unbounded one are the same function**, told apart by whether a last row
was supplied: a block that loops for ever has no length, so a render would never end. An export plays
its range once through and a track that meets a boundary inside the range is finished there.

**LIVE mode is a modifier on SONG, not a fifth transport mode.** The mode changes only what happens at
a track's boundary — a launched song row re-enters itself instead of the cursor moving down the column
— so everything that branches on the playback mode (the playhead readback, the event trace) needs no
arm for it, and a project that never enters LIVE schedules identically. A launch is **the one place the
walk is undone**: it rewinds one track to its earliest unplayed phrase boundary (a per-track checkpoint
ring, SONG mode only) and hands the host a frame to drop queued notes from, which is why a launch
pressed in the last moments before a boundary still lands on it rather than a bar or a lap late.

**Scale quantization happens once, where a note is emitted.** By that point the chain and project
transposes are folded into the note and the PIT and ARP offsets sit beside it, so quantizing that sum
in the emit funnel covers the written note, both transposes, the pitch offset and the arpeggio
together — a quantizer written per site would be four sites, and a fifth added later would be the one
that forgot. The correction lands on the base note rather than on the offsets, which are re-applied
below the seam, and never on `transpose`, which the slice derivation subtracts back out. Two cases are
excluded at the funnel rather than downstream: an instrument with transposition disabled, and a note
that is selecting a slice, where the value is not a pitch at all.

**The editor, playback and the SCALE screen's marker read the scale from three different places, and
that is the design.** A track's live scale is scheduler state, advanced a lookahead ahead of what is
audible, so only the scheduler reads it. The note cursor walks the authored `SCA`/`SCG` cells at or
above the cursor row — a value no transport can move, identical whether the song is playing or
stopped. The marker reads the engine's voices, because it has to show what is being heard rather than
what has been queued. Any two of the three sharing a source would put one of them on a clock that is
not its own.

### Parameter automation

`AUS` opens a ramp on the automatable effect in the slot to its **left**, taking that cell's value as
the start and its own as the curve; `AUF`, on a later step, carries the destination. The value is
interpolated in the authored 0–255 byte domain by a polynomial — `+ − ×` only, for the determinism
reason above — and emitted **once per tic** as the parameter's own `EV_CC`.

That last point is what keeps automation cheap. A ramp of this kind is not a new kind of event: it is
the CC the per-step effect already emits, emitted more often. So a parameter becomes automatable by
paying the price of live control at all — a CC id, an arm in `EngineConsumer::consume`, a queued apply
on the audio thread — plus a row in `automation.h`'s registry, and no `SCHEMA_VERSION` bump. Those rows
are `VOL`, `PAN`, `REV`, `DEL`, `VTR`, `VMV`, `CUT` and `RES`; the set is that table, not a property of
the feature.

**A registry row also declares what its two endpoints MEAN**, and there are two answers. The eight
above are `BYTE`: the endpoints are values, and the authored byte itself is what moves. `EQN` and `EQM`
are `EQ_PRESET`: their cells hold a preset **index**, and interpolating an index would walk presets 05,
06, 07 — a slideshow, not a fade. What moves instead is the twelve numbers the two referenced presets
hold, so `EQM 05 · AUS 80` … `AUF 12` slides the FREQ, GAIN and Q of all three bands from one preset to
the other. Those ticks carry band values rather than a controller, so they ride their own tags
(`EV_EXT_EQ_MORPH`, `EV_EXT_MASTER_EQ_MORPH`) — which is the one thing a new ramp kind can cost that a
new row cannot.

The interpolation runs on the **authored hex**, not on the Hz it converts to: frequency and Q are
exponential in hex (`20 · 1000^(hex/255)`), so linear-in-hex is linear in log-frequency, which is what a
sweep should sound like — and it keeps every value a morph produces in the same integer domain
everything else already emits.

⚠️ **A band's TYPE is not interpolable** — there is no continuous path from BELL to HISHELF, and the
two cut types run through the SVF and have no gain at all. The start preset's three types therefore
hold for the whole span, arrival included, and only FREQ/GAIN/Q move. When the two presets' types agree
the arrival **is** the destination preset exactly; when they differ the ramp rests on a setting no
preset names, and nothing clicks. To land on the real destination, write it: `EQM 12` on the step after
the `AUF`. A band that is OFF in the start preset stays off, so `active` cannot change mid-sweep and no
band pops in or out.

⚠️ An `AUF` cell accepts 00–FF while a preset slot is 00–7F, so an `AUF` above 7F over an `EQ_PRESET`
ramp names nothing: it does not close the span, it draws dimmed like any unused automation cell, and
the open `AUS` waits for the next legal `AUF`.

Pairing lives in `automation.h` and is **pure**: it answers "which spans does this walk declare", in
step indices, and never touches frames, tics, grooves or the transport. The emitter already holds each
step's real duration as it walks, so a groove-warped span costs it nothing.

A span may cross phrases, and **the chain is the boundary** — a chain is the unit a track repeats and
re-enters, so pairing that ran past it would have to survive a chain played from two song rows at once
and CHAIN mode's wrap. ⚠️ The open ramp is **re-derived from `(chain, chainRow)` on every call**, never
carried in `TrackState`: a chain re-entered from a later song row would inherit the previous one's
open ramp, and a phrase scheduled twice (a LIVE rewind) would advance it twice. Deriving makes both
unaskable.

The PHRASE editor draws an `AUS`/`AUF` cell that no ramp uses **dimmed**, and it asks the same pairing
code the emitter does, so the grid can neither claim a fade that will not play nor deny one that will.
A phrase has no single playing context — it may sit at several chain rows, in several chains, in none —
so the editor unions the answer over every chain row that plays it (`find_ramp_cells`) and falls back
to pairing within the phrase only for a phrase no chain references.

A **table** takes the same pair and shares none of that mechanism. It has no scheduler and emits no
event: it runs inside `AudioEngine`, per voice, off the row the voice is standing on, over sixteen rows
with a `HOP` that can jump backwards. So the ramp **holds no state** — its position is re-derived on
every audio block from the current row and the table's cells, which is why a `HOP` anywhere into or out
of a span needs no code to handle it. What a table `AUS` can move is the **intersection** of what the
table engine has an arm for and what the registry above takes, held together by `static_assert` in the
one file that sees both lists rather than written down as a third. ⚠️ A phrase `EQM` is an event, so the
scheduler arms the restore-on-stop as it emits one; a table `EQM` is emitted nowhere, so the engine
latches it and the host consumes the latch — one restore, armed from either end.

### Determinism

The floats have to be bit-identical across compilers and architectures, because the event stream is
compared as raw binary32 bits:

- `note_tables.h` bakes all 132 note frequencies and 256 detune values as constants rather than
  computing `pow()` at runtime.
- The `songcore` library, and every target that includes a songcore header, is compiled with
  `-ffp-contract=off` and without `-ffast-math`. GCC defaults to contracting `a + b*c` into an FMA,
  which would silently change the last bits.

Random effects (CHA, RND, RNL, random-mode ARP), `oscShape >= 8` RND/DRNK LFOs, and DUST on the
master bus are clock-seeded and therefore **not** byte-reproducible. Whether a given project can be
byte-compared at all is a property of the project, and has to be answered before any A/B.

---

## The Event Bus

The sequencer does not call the engine. It publishes **events** on a bus, and consumers turn them
into whatever they are for.

```
   scheduler ──► MidiRouter ──┬──► EngineConsumer    → voices (the internal sound)
                              ├──► ExternalConsumer  → MIDI bytes (the cable)
                              └──► TraceConsumer     → a conformance trace
```

The event vocabulary is MIDI's: note on, note off, control change, program change, pitch bend. That
is the payoff of the seam — one command vocabulary reaches an internal sampler voice and an external
synthesizer without either knowing about the other.

`event.h` holds a **versioned, frozen schema**. Adding a tag, a field, or changing the order requires
a `SCHEMA_VERSION` bump, regenerated goldens and a doc update, together.

`TrackInstruments` (`router.h`) resolves which instrument a track-scoped event belongs to: the last
note-on on a track names it. Both consumers use the same resolver, so they cannot disagree.

### MIDI

All three shipping platforms have MIDI in and out (winmm on Windows, ALSA on Linux, the Android MIDI
API on Android), with a 24 PPQN clock, transport messages and song-position pointer.

**MIDI in is drained on the audio thread.** A port's bytes land in a lock-free ring; the engine
empties it at the top of every live block, parses, routes and puts each record into its own queues
stamped at that block's first frame, so a key sounds in the block after its bytes arrive. The router
never reads the project: it reads a `MidiRoute`, a flat snapshot of the routing facts the host builds
on the UI thread and publishes through a sequence lock whenever they change. Everything that needs
the project — the controller mappings, MIDI thru, the counters a screen shows — runs on the UI thread
from a second ring the drain fills, one poll behind the sound. The engine resolves a live note from
the same copies it resolves a sequenced one from, which is why every table and instrument setting is
pushed when it changes rather than a note ahead of when it is needed.

A project also carries the **controller mappings** — which knob moves which parameter. The drain
withholds a claimed controller from the tracks and the host applies it to the song, neither behind
the screen that authors it. The channel those knobs arrive on is in `settings.json` instead, because
it describes the cable on this desk rather than the song.

The `osc` loop mode is held back from release builds (`PlatformCaps::loopWindow`) on authoring-only
terms: a build that hides it cannot create it, but displays and plays a project that has it, since
drawing persisted data as something else would misrepresent the file on disk. The MIDI authoring
surfaces sit behind the same kind of flag (`PlatformCaps::midi`), on in every shipping profile, and
the `LPO` effect behind `loopWindow` as well — which is why it shows wherever MIDI does. Hiding an
effect works only on a
**tail** of `EFFECT_TYPES`: a cell stores an index into that array while a `.ptp` stores the effect
*code*, so shortening the list leaves every remaining index naming the effect it always named. `LPO`
sits directly below the MIDI six for that reason, which also means the two trims nest — nothing can
drop an entry from the middle of the list.

The FX picker is a second list of the same effects, and deliberately not that array: its groups hold
effect *codes* in their own reading order, so the picker can be re-ordered freely and a command can
appear in two groups at once. Both lists are filtered by the same visible count, which is what stops
a build from reaching a command through one and not the other. A group left with no effects is then
dropped whole rather than drawn as an empty heading — which is how the MIDI group disappears, and why
the blank entry each group offers is added *after* that decision and is never a member of one.

---

## Data Model and File Formats

```
Project
├── name, tempo, transpose
├── song[256][8]          chain references per row per track   (-1 = empty)
├── chains[256]           16 phrase slots + a transpose each
├── phrases[256]          16 steps: note, volume, instrument, 3 × (FX type, FX value)
├── tables[128]           16 rows: transpose, volume, 3 × (FX type, FX value)
├── grooves[128]          16 step lengths in tics, the ruler they count in, and a name
├── instruments[128]      sampler | SoundFont | external
├── eqPresets[128]        the shared EQ slot bank
├── mixer, master bus, reverb, delay
└── midi settings         sync out, program change, per-track input channels
```

**`-1` is the empty value everywhere** — chain references, table volume, every EQ slot. Not `0xFF`.

**An instrument is empty iff `sampleFilePath` is null.** Not `sampleId < 0`, not an empty name. A
note-on on an empty instrument is still a valid *event*; the consumer is what drops it.

### Files

| Extension | Contents |
|---|---|
| `.ptp` | A project. JSON, minified, defaults omitted. |
| `.pti` | A single instrument preset — any type, including external. |
| `settings.json` | Device and app settings. Shared shape across platforms. |
| `config.json` | Optional overrides: the browser's folders, the gamepad's face-button layout, and the keyboard bindings. |
| `.ptt` | A theme. |

`project_io.h` pins the **schema**, not the layout: field order and the default-omission rules are
fixed, and a set of golden projects round-trips against them under the headless test suite (developed
separately — see [`building.md`](building.md)). Any new serialized field must be default-guarded or
those goldens break.

A `.ptp` is written **minified** and a `.ptt` **pretty-printed**, from the same emitter, and the split
is not cosmetic. Autosave rewrites the whole project every few seconds, and layout was 82 % of the
bytes; a theme is a few hundred bytes a person may open or hand to someone else. The goldens stay
pretty-printed either way — they are the only artifact here written by an implementation that no
longer exists, so regenerating them from the emitter they exist to check would prove nothing.

### Storage

Everything the app does to a disk goes through one interface, `ui/filesystem.h` — twenty-three methods,
string-typed paths, `FileInfo` structs. Screen modules never see a file handle, which is what lets a
headless tool drive the file browser against a temp directory. There are two implementations:
`StdFileSystem` (portable C++17 `<filesystem>`, used by Windows, Linux and PortMaster) and
`SafFileSystem` (Android).

**Android declares no storage permission at all.** `/storage/emulated/0` is unreadable to the process,
and the only way to a user's files is a folder they hand over through the system picker
(`ACTION_OPEN_DOCUMENT_TREE`). The browser's virtual `pt://roots` directory lists every granted folder
plus an `ADD FOLDER…` action row; the first folder granted is persisted as the home root, so granting a
second one never relocates the app's six directories.

**Paths stay composable, and the document URI is an implementation detail.** The interface assumes
paths compose — the browser's `..` is a string trim, a rename builds its target as `parent / name` — and
a SAF document URI is an opaque handle with no derivable parent or child. So `SafFileSystem` addresses
files as `pt://<root-id>/Projects/song.ptp`, where `<root-id>` is a hash of the granted tree's URI, and
resolves that to a document URI internally. The id is derived rather than stored, so it re-derives from
the grant list on any boot in any order.

**A second seam sits below the UI**, because samples, SoundFonts, projects and the WAV writer open
paths directly rather than through the interface. `common/byte_source.h` provides `pt_fopen`, `pt_remove` and
`pt_rename`: a plain path takes libc's branch, a URI is handed to a host-installed hook. The decision is
derived from the string, once, below every call site — not repeated at each of them. On every platform
but Android no hook is installed and all three are a rename of the libc call.

Three files — `settings.json`, `template.ptp` and the crash-recovery autosave — live in app-private
storage on Android, because they are read at boot before any folder can have been granted. `config.json`
stays in the granted tree: it is the one file the user hand-edits, and its `folders` values are relative
to the app's root unless written as absolute paths, so the file means the same thing on every device.

---

## UI Layer

640×480, drawn into a software framebuffer with four primitives. The shell scales the finished frame.

**Sixteen screens** (`ui/screen.h`). Twelve of them sit on the R+DPAD navigation grid; four are
reached from a row on another screen:

| | |
|---|---|
| Grid — main row | SONG, CHAIN, PHRASE, INSTRUMENT, TABLE |
| Grid — column rows | PROJECT, GROOVE, SCALE, MODS, INST.POOL |
| Grid — shared rows | MIXER, EFFECTS |
| Reached from a row | FILE BROWSER, SETTINGS, SAMPLE EDITOR, MIDI |

Five more surfaces are **overlays** rather than screens — they draw over whatever is up and do not
change `currentScreen`: the THEME editor, the EQ editor, the qwerty keyboard, the FX helper and the
confirm dialog.

Screen geometry lives in **one table per screen** that the cursor walks and the module draws. Where
rows are conditional (SETTINGS, PROJECT), a row's **number is its identity** — hidden rows are
skipped, never renumbered, so a stored cursor and a recorded test case keep meaning the same thing.

Under `NAV = SONG` the CHAIN and PHRASE screens point at a **song cell** rather than at a pool slot.
`currentChain` and `currentPhrase` stop being state and become a reading of the SONG and CHAIN cursors
— the three fields `go_to_screen` already saves and restores — so the ruleset adds no field, which is
the invariant rather than an economy: storing "which chain am I looking at" would mean carrying the
cell beside it as a second copy, and the two diverge on the first move that lands on the same chain
from a different cell. The two `current*` fields are still written, by one refresh sitting below the
three places the pointer can move, because the call sites that index `project.chains[currentChain]`
number about thirty and deriving at each of them is the bug this avoids.

Two modules are stateful, both because their output is a function of the *previous* frame: the
oscilloscope (peak-hold dots, falling bars) and the mixer (falling peak markers).

The sample editor holds **three marker lists behind one accessor** — the file's own `cue ` chunk, the
detector's output, and the boundaries the user has moved. Every reader goes through `marker_count()` /
`marker_position()`, because one vector answering several questions is how a save under `SLICE = OFF`
once wrote the detector's markers into a file. The hand-moved list overrides the others while a stamp
of the `(method, parameter)` it was made under still matches the screen, so "changing the method resets
what you moved" is **derived** rather than asked of each write to those fields; an *empty* stamped list
is a real answer, not an absent one. Each boundary carries the frame its method gave it, since a
boundary may be dragged past its neighbours and its number follows its position — an index says where
it sits on screen, not which cut it is. ⚠️ An op that changes the sample's **length** drops all three:
a marker is a frame index, and the frames have been replaced.

**Modals own the buttons while they are up** — the layer stack, under Input Layer below.

---

## Input Layer

`ui/input_dispatcher.*` and `ui/dispatch/` are every button and combo — one class, split by screen.
Each entry point the mapper calls (`on_a_up`, `on_start`, …) names its gesture and hands it to
`route()`, which asks two tables in `ui/dispatch/route.cpp`:

1. **`LAYERS`, the modal stack**, top first — every dialog, editor and picker drawn over a screen. The
   first open one gets the gesture. ⚠️ **A layer takes every gesture it does not answer**, so a button
   pressed under a dialog never edits the screen behind it; letting one through is the deliberate
   exception (START under the theme and EQ editors, so the song plays while you dial). The table's order
   is which modal sits on top of which, and it is the only list of modals: a new one is a row here.
2. **`SCREENS`, one row per screen**: its own buttons (`ui/dispatch/screens/`), what is under its cursor,
   how an edit applies, and for the four grids where the cursor and the selection's bounds live. A
   gesture the screen passes on runs the generic path below, which reads the same row.

A new screen is a file under `screens/` and one row; no gesture function learns its name. What must
happen under any layer — releasing a held preview note, the R-chord's modifier snapshot — runs in the
entry point before `route()`.

**Modifiers are snapshotted at EVENT time, not at poll time.** SDL delivers a whole frame's events at
once, so asking "is A held?" while processing a B press describes the *end* of the frame. Roll B and
A down inside one 16 ms frame and a poll-time reader fires A+B on what was a plain B. Each queued
event carries its own modifier snapshot.

**The mapper's check order is the specification**, not style. L+B+A is tested before L+A or a clone
pastes; A+B before a plain A or a delete inserts; R+A is consumed so holding R to change screens
cannot also fire an edit underneath.

Cursor behaviour is a `CursorContext`: what the cell holds, what it can do (increment, decrement,
delete, insert), its range and its step sizes. The five generic handlers (`on_a`, `on_b`,
`on_a_left`, `on_a_right`, `on_a_b`) turn a button into an `InputAction` without ever asking which
screen is up.

That makes a cursor position a **seat and not a name**, which is fine for editing and not enough for
anything that has to be *stored*. MIDI mapping is the one feature that needs the name, so three
screens answer a second question beside `cursor_context()` — what this cell is CALLED, from an
append-only catalogue — and decline everywhere else. The same seat is a different parameter on two
instrument types, so a stored `(row, column)` would point somewhere else after a type change.

⚠️ MIDI learn is also **the one gesture the combo matrix cannot resolve**: it is "hold R and turn a
knob", and a knob is a CC on a cable that never becomes a button event. The matrix publishes R's held
state and nothing more; the arm lives on the host, which is the layer the MIDI drain can reach.

---

## Rendering and Export

Offline render (`songcore/render.h`) is **prepare → render → finish**, with scheduling deliberately
outside those verbs. It pushes the project into the engine, walks the requested song rows, and writes
a WAV.

- **A render is deterministic**: the same project rendered twice produces a byte-identical file, with
  a different project rendered in between. Engine state surviving from one render to the next was a
  real bug; back-to-back renders would be the weaker test.
- **The tail is appended**: a render whose last note is still ringing continues until the audio
  decays to zero, rather than stopping dead at full amplitude. A runaway cap bounds it. ⚠️ What ends
  the notes at the range's last frame is a **KIL, not a key release** — a key release is defined to
  leave a one-shot alone so a live keyboard cannot cut a drum hit short, and at the end of a render
  that is the one place the definition is wrong.
- **A repeat is one scheduling pass**, never a file joined to itself: the engine is not told the range
  ended, so tails and table positions cross every seam. ⚠️ Every track restarts at the **longest**
  one's end rather than its own — blocks of unequal length drift apart within a pass, so per-track
  restarts would compound that drift with each repetition.
- **The row range is resolved once, above the stem loop**, and held. Recomputing it per pass is a set
  of stems that no longer line up. The same range decides which tracks earn a stem at all, so
  exporting one part does not write a silent file per track that plays elsewhere in the song.
- **Live and render must be identical.** `push_live_params` and `prepare_render` push the same
  parameters, and a standing test asserts a live-configured engine and a render-configured engine
  produce byte-identical audio. They did not always: the shell once played a project on the engine's
  factory defaults while rendering it correctly.

Export modes: full mix, per-track stems, and resampling a song selection into a new sample. The first
two are one modal panel over the PROJECT screen with the output chosen on the way in, rather than two
actions that render on the spot.

---

## Platform Shells

| | Android | PortMaster | Linux desktop | Windows |
|---|---|---|---|---|
| Entry | `android-main.cpp` | `main.cpp` | `main.cpp` | `main.cpp` |
| Audio | Oboe | SDL2 | SDL2 | SDL2 |
| SDL2 | vendored, built in | **the device's own** | system | vendored, static |
| MIDI | Android MIDI (JNI) | ALSA (dlopen) | ALSA (dlopen) | winmm |
| App root | a folder the user grants | the port's `data/` | `$XDG_DATA_HOME/PocketTracker` | `Documents\PocketTracker` |
| Storage | Storage Access Framework | `std::filesystem` | `std::filesystem` | `std::filesystem` |
| Exit | — (the launcher owns it) | PROJECT → EXIT | PROJECT → EXIT | PROJECT → EXIT |

**PortMaster links the device's libSDL2, deliberately.** The CFW patched that copy for the hardware's
display (KMSDRM) and audio (ALSA); shipping our own would shadow the one that actually knows the
screen. The build cross-compiles against a *pinned old* SDL2 as a link-time SDK — a compatibility
floor, so reaching for a newer SDL API fails loudly on a dev box instead of as `undefined symbol` on
a stranger's handheld.

**The PortMaster launcher must never run gptokeyb.** The app reads the gamepad itself through SDL's
GameController API *and* reads the keyboard (the same source builds the desktop binary), so gptokeyb
delivers every press twice by two paths with conflicting meanings.

**Renderer creation falls back.** `SDL_RENDERER_ACCELERATED` means *require*, not *prefer*, so
`SDL_CreateRenderer` fails outright on hardware with no accelerated driver. The shell tries
accelerated+vsync → accelerated → anything.

**The frame loop runs at two rates, and it owns the only wait.** Input, incoming MIDI and the
sequencer's refill are pumped every few milliseconds; the drawing, and the per-frame derivations that
feed it, run once per refresh. Nothing else may pace the loop — with vsync `SDL_RenderPresent` blocks,
but a tick that draws nothing never reaches it, and a spun core is a battery bug on a handheld. The
next frame is anchored on the present's *return*, which is a vblank: a deadline that is a fraction
short of the real refresh walks into the vblank a frame at a time until the present is blocking most
of a refresh with nothing being polled behind it.

**Signal handling: a handler may only set a flag.** "SIGTERM → autosave" read literally is a heap-lock
deadlock — hundreds of KB of JSON, none of it async-signal-safe — which hangs in exactly the case it
exists for. The handler writes a `volatile sig_atomic_t`; the frame loop does the work. The handler
must be installed *before* `SDL_Init`.

---

## Built to Be Measured

Most of the structure described above exists so that each layer can be driven and compared from
outside, with no window, no audio device and no Android. That property is a design constraint, not a
side effect, and three consequences of it are load-bearing.

**Every layer can be driven headlessly.** `pt-ui` links nothing platform-specific — no SDL, no POSIX,
no window — so a whole screen can be rendered to a pixel buffer by a plain host program. The day the
UI reaches for SDL, that stops linking, which is the point. The sequencer publishes events rather
than calling the engine, so the event stream can be captured without any audio at all. And
`renderOffline` runs the same `processAudioBlock` the live callback does, so rendered and played
audio are the same computation.

**Events and engine calls are byte-exact; audio is not.** Measured, not argued: gcc/x86-64 differs
from MSVC/x86-64 in 9.7% of samples by at most 5 LSB of 32767, and clang/arm64 with fast-math differs
in 17.0% by at most 16 LSB. Both are inaudible, and neither can be made to go away without giving up
`-ffast-math` in the DSP. So exact claims are made about the event stream and the engine calls a note
produces, and audio is compared as a tolerance fingerprint.

**Nothing above the engine touches a file directly.** `native/ui/filesystem.h` is a 23-method pure
interface, string-typed; module logic never sees a file handle. That is what lets the file browser be
driven against a temporary directory on a desktop.

---

## Build

### Android

```
./gradlew :app:assembleDebug        # the APK
./gradlew :app:buildCMakeDebug      # the native side — assembleDebug does NOT imply this
./gradlew :app:assembleRelease      # the only build that runs R8
```

Two native libraries ship: **`libpockettracker-sdl.so` is the app**; `libpockettracker.so` is the
engine alone and is legitimately older.

⚠️ **Every C++→Kotlin JNI callback resolved by name needs an explicit `-keep` in
`app/proguard-rules.pro`, and this only bites in release** (debug never runs R8). AGP keeps a native
method's *class* but not its *members*. Verify in the DEX, not in `mapping.txt`.

### Desktop / handheld

```
cmake -S shell -B shell/build -DCMAKE_BUILD_TYPE=Release
cmake --build shell/build
```

`CMAKE_BUILD_TYPE` explicitly: a Debug engine may not keep up with a real-time audio callback.

### Packaging

| Platform | Script | Output |
|---|---|---|
| Windows | `shell/build-windows.ps1` | `build/windows/PocketTracker-<v>-windows-x64.zip` |
| Linux | `shell/build-linux.sh` | `build/linux/PocketTracker-<v>-linux-x64.tar.gz` |
| PortMaster | `shell/build-portmaster.sh` (in `Dockerfile.portmaster`) | `build/portmaster/pockettracker.zip` |

Each one verifies the *artifact* — that it is newer than every source file, links what it claims to,
carries the right version — and then reads the finished archive back out. `.github/workflows/release.yml`
runs all three on a `v*` tag and opens a draft release. The signed APK is built locally, because CI
has no access to the signing key and an APK signed with a different key cannot install as an update.

---

## Conventions

`snake_case` for functions and variables in songcore and pt-ui; `camelCase` for model fields, which
mirror the JSON they serialize to.

Screen geometry lives in one table per screen that the cursor walks and the module draws, rather than
in a chain of branches — see [UI Layer](#ui-layer).

**A row's or an enum member's number is its identity: append, never insert.** An FX cell stores an
*index* into `EFFECT_TYPES` while the project file stores the effect *code*, so inserting an entry
renumbers every cell a user has already typed. The same applies to `SettingsRow`, `ProjectRow` and
`InstrumentType`, all of which are persisted or recorded by number. Where a build hides a member, it
hides one from the **end** of the list and the walkers skip it — they never close the gap.
