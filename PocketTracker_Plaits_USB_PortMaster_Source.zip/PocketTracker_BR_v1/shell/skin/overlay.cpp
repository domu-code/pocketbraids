#include "skin/overlay.h"

#include "skin/assets.h"
#include "skin/image.h"

#include <cstdio>

namespace ptshell {

bool ScreenOverlay::load(SDL_Renderer* renderer, int index, bool log) {
    unload();

    if (index <= 0 || index > kScreenOverlayCount) {
        if (log) std::printf("overlay: OFF (no overlay)\n");
        return false;  // OFF — not an error
    }

    const ScreenOverlayDef& def = kScreenOverlays[index - 1];

    const std::vector<std::uint8_t> bytes = read_asset(def.file);
    if (bytes.empty()) {
        if (log) std::printf("overlay: %-16s MISS (not found / unreadable)\n", def.file);
        return false;
    }

    const Image img = decode_png(bytes.data(), bytes.size());
    if (!img.ok()) {
        if (log) std::printf("overlay: %-16s DECODE FAILED (%zu bytes)\n", def.file, bytes.size());
        return false;
    }

    // ARGB8888 matches Image's packing on little-endian targets; STATIC, uploaded once.
    SDL_Texture* tex = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888,
                                         SDL_TEXTUREACCESS_STATIC, img.width, img.height);
    if (tex == nullptr) {
        if (log) std::printf("overlay: %-16s TEXTURE FAILED: %s\n", def.file, SDL_GetError());
        return false;
    }
    SDL_UpdateTexture(tex, nullptr, img.pixels.data(), img.width * static_cast<int>(sizeof(uint32_t)));

    // Blended, alpha per draw from STRENGTH; linear, since the PNG is stretched to the frame.
    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
    SDL_SetTextureScaleMode(tex, SDL_ScaleModeLinear);

    tex_ = tex;
    if (log) std::printf("overlay: %-16s %dx%d ok\n", def.file, img.width, img.height);
    return true;
}

void ScreenOverlay::unload() {
    if (tex_) SDL_DestroyTexture(tex_);
    tex_ = nullptr;
}

void ScreenOverlay::draw(SDL_Renderer* renderer, const SDL_Rect& dst, int strength) const {
    if (tex_ == nullptr || strength <= 0) return;
    const Uint8 alpha = static_cast<Uint8>(strength > 255 ? 255 : strength);
    SDL_SetTextureAlphaMod(tex_, alpha);
    SDL_RenderCopy(renderer, tex_, nullptr, &dst);
}

}  // namespace ptshell
