#include "sdl/sdl-touch.h"

#include "sdl/sdl-input.h"

#include "skin/button_glyphs.h"  // shared with the portrait cluster

#include <cstdio>

namespace tl = pt::ui::touch_layout;

namespace {

// Narrower bars are not finger-sized.
constexpr int MIN_PANEL_PX = 150;

constexpr uint32_t BTN_NORMAL  = 0x3D5A80;
constexpr uint32_t BTN_PRESSED = 0x98C1D9;
constexpr uint32_t PANEL_BG    = 0x1A1A1A;

void fill(SDL_Renderer* r, const SDL_Rect& rc, uint32_t rgb) {
    SDL_SetRenderDrawColor(r, static_cast<Uint8>((rgb >> 16) & 0xFF),
                           static_cast<Uint8>((rgb >> 8) & 0xFF), static_cast<Uint8>(rgb & 0xFF), 255);
    SDL_RenderFillRect(r, &rc);
}

}  // namespace

void SdlTouch::layout(const SDL_Rect& frame, int outW, int outH) {
    outW_ = outW;
    outH_ = outH;
    portrait_ = false;

    // The bars either side of the centred frame; none wide enough → inactive.
    const int leftW  = frame.x;
    const int rightX = frame.x + frame.w;
    const int rightW = outW - rightX;

    active_ = enabled_ && outH > 0 && leftW >= MIN_PANEL_PX && rightW >= MIN_PANEL_PX;
    if (!active_) {
        left_.count  = 0;
        right_.count = 0;
        return;
    }

    leftBox_  = {0, 0, leftW, outH};
    rightBox_ = {rightX, 0, rightW, outH};
    left_     = tl::left_rects(leftW, outH);
    right_    = tl::right_rects(rightW, outH);
}

void SdlTouch::layout_portrait2(const SDL_Rect& cluster, const tl::BoxRects& rects, int outW, int outH) {
    outW_            = outW;
    outH_            = outH;
    portrait_        = true;
    portraitCluster_ = cluster;
    portrait_rects_  = rects;
    // PortraitSkin fills rects only on a portrait output, so count 0 means nothing to press.
    active_ = enabled_ && rects.count > 0;
}

bool SdlTouch::hit_window(int px, int py, Button& out) const {
    // Portrait: one cluster, rects local to its origin.
    if (portrait_) {
        return tl::hit(portrait_rects_, px - portraitCluster_.x, py - portraitCluster_.y, out);
    }
    if (px >= leftBox_.x && px < leftBox_.x + leftBox_.w) {
        return tl::hit(left_, px - leftBox_.x, py - leftBox_.y, out);
    }
    if (px >= rightBox_.x && px < rightBox_.x + rightBox_.w) {
        return tl::hit(right_, px - rightBox_.x, py - rightBox_.y, out);
    }
    return false;
}

void SdlTouch::handle_finger(const SDL_Event& e, SdlInput& input, uint64_t now_ms) {
    if (!active_) return;

    // SDL normalises fingers to [0,1] over the window — the output's pixel space on Android.
    const SDL_TouchFingerEvent& t  = e.tfinger;
    const int                   px = static_cast<int>(t.x * outW_);
    const int                   py = static_cast<int>(t.y * outH_);

    if (e.type == SDL_FINGERDOWN) {
        Button b{};
        if (hit_window(px, py, b)) {
            input.touch_press(b, now_ms);
            emit_feedback(b, /*down=*/true);
            finger_[t.fingerId] = b;
            if (trace_) std::printf("input:   TOUCH DOWN  %4d,%-4d       -> %s\n", px, py, pt::ui::button_name(b));
        } else if (trace_) {
            // ⚠️ A tap that hits nothing says so: a gap, vs no event at all.
            std::printf("input:   TOUCH DOWN  %4d,%-4d       -> (no button)\n", px, py);
        }
    } else if (e.type == SDL_FINGERUP) {
        auto it = finger_.find(t.fingerId);
        if (it != finger_.end()) {
            input.touch_release(it->second);
            emit_feedback(it->second, /*down=*/false);
            if (trace_) std::printf("input:   TOUCH UP                    -> %s\n", pt::ui::button_name(it->second));
            finger_.erase(it);
        }
    } else if (e.type == SDL_FINGERMOTION) {
        // Sliding off releases; sliding back in does not re-press.
        auto it = finger_.find(t.fingerId);
        if (it != finger_.end()) {
            Button b{};
            const bool still = hit_window(px, py, b) && b == it->second;
            if (!still) {
                input.touch_release(it->second);
                emit_feedback(it->second, /*down=*/false);
                if (trace_)
                    std::printf("input:   TOUCH SLIDE-OFF             -> %s released\n",
                                pt::ui::button_name(it->second));
                finger_.erase(it);
            }
        }
    }
}

void SdlTouch::draw(SDL_Renderer* r, const SdlInput& input) const {
    if (!active_ || portrait_) return;   // the portrait cluster is PortraitSkin's

    fill(r, leftBox_, PANEL_BG);
    fill(r, rightBox_, PANEL_BG);

    auto draw_box = [&](const tl::BoxRects& box, int ox, int oy) {
        for (int i = 0; i < box.count; ++i) {
            const tl::ButtonRect& br = box.r[i];
            const SDL_Rect        rc{br.x + ox, br.y + oy, br.w, br.h};
            fill(r, rc, input.is_held(br.button) ? BTN_PRESSED : BTN_NORMAL);
            ptshell::draw_label(r, br.button, rc);
        }
    };
    draw_box(left_, leftBox_.x, leftBox_.y);
    draw_box(right_, rightBox_.x, rightBox_.y);
}

uint64_t SdlTouch::signature(const SdlInput& input) const {
    if (!active_) return 0;

    uint64_t bits = 0;
    for (int i = 0; i < left_.count; ++i)
        if (input.is_held(left_.r[i].button)) bits |= (1ull << static_cast<int>(left_.r[i].button));
    for (int i = 0; i < right_.count; ++i)
        if (input.is_held(right_.r[i].button)) bits |= (1ull << static_cast<int>(right_.r[i].button));

    // Geometry too, so a resize repaints; bit 63 keeps it non-zero while active.
    return bits | (static_cast<uint64_t>(outW_ & 0xFFFF) << 16) |
           (static_cast<uint64_t>(outH_ & 0xFFFF) << 32) | (1ull << 63);
}
