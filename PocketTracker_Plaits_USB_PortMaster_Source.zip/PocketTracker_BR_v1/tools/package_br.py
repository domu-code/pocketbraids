#!/usr/bin/env python3
"""Repackage the verified PortMaster build into an isolated BR install."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile
from verify_mutable import verify, ROOT

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=ROOT / "build/portmaster/pockettracker.zip")
    p.add_argument("--output", type=Path, default=ROOT / "release")
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(a.input) as z:
        entries = {n: z.read(n) for n in z.namelist() if not n.endswith("/")}
    info = verify(entries["pockettracker/pockettracker.aarch64"])
    info.update({"source_zip_sha256": os.environ.get("BR_SOURCE_SHA256", "local build"),
                 "github_commit": os.environ.get("GITHUB_SHA", "local build"),
                 "github_run_id": os.environ.get("GITHUB_RUN_ID", "local build"),
                 "github_run_number": os.environ.get("GITHUB_RUN_NUMBER", "local build"),
                 "mutable_upstream_commit": "f4cfa7697095a28d292bff758beb51deb49b5a86",
                 "plaits_upstream_commit": (ROOT / "native/vendor/mutable/plaits/PT-UPSTREAM-REVISION").read_text().strip(),
                 "stmlib_commit": "e3bd7c9cc00e4364166f9905c0509b6ffd0535ec"})
    output = {}
    for name, data in entries.items():
        if name == "PocketTracker.sh":
            launcher = data.decode()
            old = "GAMEDIR=/$directory/ports/pockettracker"
            if launcher.count(old) != 1:
                raise ValueError("Unexpected launcher path; refusing unsafe repackage")
            output["PocketTracker BR.sh"] = launcher.replace(old, old + "_br").encode()
        elif name.startswith("pockettracker/"):
            output[name.replace("pockettracker/", "pockettracker_br/", 1)] = data
        else:
            raise ValueError(f"Unexpected package member: {name}")
    output["pockettracker_br/pockettracker_br.md"] = output.pop("pockettracker_br/pockettracker.md").replace(b"ports/pockettracker/data/", b"ports/pockettracker_br/data/")
    meta = json.loads(output["pockettracker_br/port.json"])
    meta["name"] = "pockettracker_br.zip"
    meta["items"] = ["PocketTracker BR.sh", "pockettracker_br"]
    meta["attr"].update(title="PocketTracker BR", exp=True,
        desc="Experimental PocketTracker port with original Braids, Rings and Plaits synthesis.")
    output["pockettracker_br/port.json"] = json.dumps(meta, indent=2).encode()
    xml = output["pockettracker_br/gameinfo.xml"].decode()
    xml = xml.replace("./PocketTracker.sh", "./PocketTracker BR.sh").replace("<name>PocketTracker</name>", "<name>PocketTracker BR</name>").replace("./pockettracker/", "./pockettracker_br/")
    output["pockettracker_br/gameinfo.xml"] = xml.encode()
    output["pockettracker_br/licenses/MUTABLE-MIT.txt"] = (ROOT / "docs/licenses/MUTABLE-MIT.txt").read_bytes()
    output["pockettracker_br/licenses/stmlib-LICENSE"] = (ROOT / "native/vendor/mutable/stmlib/LICENSE").read_bytes()
    output["pockettracker_br/licenses/plaits-MIT.txt"] = (ROOT / "native/vendor/mutable/plaits/dsp/voice.h").read_text().split("// -----------------------------------------------------------------------------")[0].encode()
    output["pockettracker_br/PLAIT_USB_GUIDE.md"] = (ROOT / "PLAIT_USB_GUIDE.md").read_bytes()
    output["pockettracker_br/BR_ENGINE_GUIDE.md"] = (ROOT / "BR_ENGINE_GUIDE.md").read_bytes()
    output["pockettracker_br/USB_AUDIO_MIDI_GUIDE.md"] = (ROOT / "USB_AUDIO_MIDI_GUIDE.md").read_bytes()
    info_bytes = (json.dumps(info, indent=2) + "\n").encode()
    output["pockettracker_br/BUILD_INFO.json"] = info_bytes
    target = a.output / "pockettracker_br.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in sorted(output.items()):
            member = zipfile.ZipInfo(name)
            member.create_system = 3
            member.external_attr = (0o100755 if name.endswith((".sh", ".aarch64")) else 0o100644) << 16
            z.writestr(member, data, compress_type=zipfile.ZIP_DEFLATED)
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None: raise ValueError("Corrupt package ZIP")
        verify(z.read("pockettracker_br/pockettracker.aarch64"))
        assert "PocketTracker BR.sh" in z.namelist()
        assert "pockettracker_br/screenshot.png" in z.namelist()
        assert b"ports/pockettracker_br" in z.read("PocketTracker BR.sh")
    (a.output / "BUILD_INFO.json").write_bytes(info_bytes)
    (a.output / "SHA256SUMS.txt").write_text(hashlib.sha256(target.read_bytes()).hexdigest() + "  pockettracker_br.zip\n")
    print(info_bytes.decode())
    print(f"PASS: verified original DSP and isolated package: {target}")

if __name__ == "__main__":
    main()
