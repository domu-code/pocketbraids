#!/usr/bin/env bash
# Fetch the exact official Mutable Instruments Plaits revision (MIT licensed).
# This bootstrap tree deliberately does not replace existing Braids/Rings/stmlib.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="$ROOT/native/vendor/mutable/plaits"
REV="08460a6"
if [[ -f "$TARGET/dsp/voice.cc" && -f "$TARGET/resources.cc" ]]; then
  if [[ ! -f "$TARGET/PT-UPSTREAM-REVISION" ]]; then
    echo "Plaits sources present but revision unknown: $TARGET" >&2
    exit 1
  fi
  COMMIT="$(cat "$TARGET/PT-UPSTREAM-REVISION")"
  [[ "$COMMIT" == "$REV"* ]] || { echo "Unexpected Plaits revision: $COMMIT (expected $REV)" >&2; exit 1; }
  echo "Plaits already installed: $COMMIT"
  exit 0
fi
if [[ -e "$TARGET" ]]; then
  echo "Incomplete Plaits directory exists, refusing to overwrite: $TARGET" >&2
  exit 1
fi
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
# Clone full commit history so the immutable revision is always reachable; an abbreviated
# SHA is not a legal remote ref for git fetch on every GitHub transport.
git clone --quiet https://github.com/pichenettes/eurorack.git "$TEMP/eurorack"
git -C "$TEMP/eurorack" checkout --quiet --detach "$REV"
COMMIT="$(git -C "$TEMP/eurorack" rev-parse HEAD)"
[[ "$COMMIT" == "$REV"* ]] || { echo "Upstream SHA mismatch $COMMIT" >&2; exit 1; }
test -f "$TEMP/eurorack/plaits/dsp/voice.cc"
test -f "$TEMP/eurorack/plaits/resources.cc"
test -f "$TEMP/eurorack/plaits/user_data.h"
mkdir -p "$ROOT/native/vendor/mutable"
mv "$TEMP/eurorack/plaits" "$TARGET"
printf '%s\n' "$COMMIT" > "$TARGET/PT-UPSTREAM-REVISION"
echo "Installed official Plaits DSP $COMMIT"
