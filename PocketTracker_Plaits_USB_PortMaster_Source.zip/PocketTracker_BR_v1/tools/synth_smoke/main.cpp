#include "../../native/synth/m8_voice_dsp.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
int main(){
  using namespace pt::synth;
  for(int model=0;model<47;++model){
    MacroVoice v;double energy=0;
    for(int i=0;i<48000;++i){const float s=v.next(220.f,48000.f,model,.6f,.4f);assert(std::isfinite(s));assert(std::abs(s)<=1.f);energy+=s*s;}
    assert(energy>1.e-8); // no unexpectedly silent models
  }
  std::vector<float> wave(48000);
  for(int i=0;i<48000;++i)wave[i]=std::sin(2*PI*220*i/48000);
  GranularVoice g;SampleView src{wave.data(),nullptr,(int)wave.size()};double energy=0;
  for(int i=0;i<48000;++i){float l,r;g.render(src,48000,.5f,.2f,.3f,.5f,.5f,.3f,1.f,l,r);
    assert(std::isfinite(l)&&std::isfinite(r));energy+=l*l+r*r;}
  assert(energy>1.e-8);
  std::cout<<"47 macro models and granular render: PASS\n";
}
