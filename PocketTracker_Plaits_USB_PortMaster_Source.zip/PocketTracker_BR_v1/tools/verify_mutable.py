#!/usr/bin/env python3
"""Check the shipped ELF itself, including original DSP lookup tables."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parents[1]
MARKER = b"PocketTracker BR v1 | ORIGINAL BRAIDS + ORIGINAL RINGS"

def verify(binary, require_aarch64=True):
    data = Path(binary).read_bytes() if not isinstance(binary, bytes) else binary
    if data[:4] != b"\x7fELF" or data[4:6] != b"\x02\x01":
        raise ValueError("Expected a 64-bit little-endian ELF")
    machine = struct.unpack_from("<H", data, 18)[0]
    if require_aarch64 and machine != 183:
        raise ValueError(f"Expected AArch64 (183), found ELF machine {machine}")
    checks = []
    for engine, ctype, name, fmt in [
        ("braids", "int16_t", "wav_sine", "h"),
        ("braids", "uint8_t", "wt_waves", "B"),
        ("rings", "float", "lut_stiffness", "f"),
        ("rings", "float", "lut_4_decades", "f"),
    ]:
        source = (ROOT / "native/vendor/mutable" / engine / "resources.cc").read_text()
        match = re.search(r"const " + ctype + r" " + name + r"\[\]\s*=\s*\{(.*?)\};", source, re.S)
        if not match:
            raise ValueError(f"Source table missing: {engine}::{name}")
        vals = [v.strip().rstrip("fFuUlL") for v in match[1].split(",") if v.strip()]
        vals = [float(v) if fmt == "f" else int(v, 0) for v in vals]
        packed = struct.pack("<" + fmt * len(vals), *vals)
        if packed not in data:
            raise ValueError(f"Original DSP table absent in binary: {engine}::{name}")
        checks.append(f"{engine}::{name} ({len(packed)} bytes)")
    for label in [MARKER, b"SYMPATHETIC STRING", b"QUANTIZED STRING", b"WAVE PARAPHONIC"]:
        if label not in data:
            raise ValueError(f"Build marker or UI model label absent: {label!r}")
    return {"build": "PocketTracker BR v1", "elf_machine": machine,
            "binary_sha256": hashlib.sha256(data).hexdigest(),
            "braids_models": 47, "rings_models": 6, "original_tables_found": checks}

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("binary")
    p.add_argument("--allow-host", action="store_true")
    a = p.parse_args()
    print(json.dumps(verify(a.binary, not a.allow_host), indent=2))
