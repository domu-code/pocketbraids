# PocketTracker BR: Plaits + USB audio (development build)

## Plaits instrument

Select `TYPE → PLAITS` in the instrument editor. The editor has `MODEL` (decimal 0–23), `HARMONICS`, `TIMBRE`, `MORPH`, `DECAY`, and `LPG COLOR` (all hex `00–FF`). Both original OUT and AUX outputs are mixed as left and right, respecting PocketTracker's pan, gain, reverb and delay sends. These six fields are saved in projects and instrument presets. The original engine runs internally at 48 kHz. A source checkout at `08460a6` is used to build the official DSP with all 24 models; the bootstrap ZIP has no copies of its upstream sources until the fetch step succeeds.

Models: 0 VIRTUAL ANALOG VCF, 1 PHASE DISTORTION, 2–4 6-OP FM, 5 WAVE TERRAIN, 6 STRING MACHINE, 7 CHIPTUNE, 8 VIRTUAL ANALOG, 9 WAVESHAPING, 10 2-OP FM, 11 GRANULAR FORMANT, 12 ADDITIVE, 13 WAVETABLE, 14 CHORD, 15 SPEECH, 16 SWARM, 17 NOISE, 18 PARTICLES, 19 STRING, 20 MODAL, 21 BASS DRUM, 22 SNARE, 23 HI-HAT.

Audio uses original Plaits DSP. In the desktop build source is fetched from `https://github.com/pichenettes/eurorack`, retaining upstream MIT notices. The generated executable is not an official Mutable Instruments firmware; Plaits is a *DSP engine* in PocketTracker.

## USB audio output on Knulli/RG28XX

USB-host DAC output is opt-in using the existing SDL/ALSA route. Create `ports/pockettracker_br/data/audio_device.txt` with one safe ALSA device identifier, e.g. `plughw:CARD=Device,DEV=0`. Replace `Device` with the detected USB card (`aplay -l` / `aplay -L`), restart and check the port's `log.txt`. Empty or remove the file for normal internal audio. USB hardware-host mode and the USB card have to be available in the handheld's firmware; the USB-C connector alone is insufficient.

USB *gadget* audio, where the handheld appears as a USB sound card to a computer, is NOT implemented. It needs USB Device Controller hardware, kernel gadget driver support and ALSA loopback, which must be tested for the exact firmware/kernel. No claim of compatibility with the RG28XX is made.

## USB MIDI

Go to PROJECT → MIDI and select an ALSA output device. An `EXTERNAL` instrument chooses the MIDI channel (1–16), bank, program, note length and CC slots. Host-mode USB MIDI is supported through the existing ALSA backend when Knulli exposes the port. This update does not change that backend.

## Build / source

The bootstrap source ZIP omits the upstream Plaits sources because this environment cannot fetch them. On a network-enabled build machine run `bash tools/fetch_plaits.sh`, then configure/build normally. The provided GitHub Actions workflow performs this automatically. Keep the Plaits sources and MIT notices with any redistributed binaries, as well as the PocketTracker GPL-3.0 source.

The C++/serialization/UI wiring was produced in this environment. **Not** yet confirmed by a complete C++ build against fetched Plaits sources, AArch64 ELF verification, or real handheld/audio device testing. See workflow build logs for outcomes.

## Tracker FX: SYNTH command picker

The existing hold-A command picker now has a **SYNTH** group. The first two command groups still work as before. Commands are applied to the currently sounding voice on the same track; a subsequent note uses the instrument's saved defaults. Model command values are **hexadecimal**.

| Engine | Command | Parameter | Value |
|---|---|---|---|
| Braids | BMD | Model | `00`–`2E` (0–46) |
| Braids | BTM | Timbre | `00`–`FF` |
| Braids | BCL | Colour | `00`–`FF` |
| Rings | RMD | Model | `00`–`05` |
| Rings | RST | Structure | `00`–`FF` |
| Rings | RBR | Brightness | `00`–`FF` |
| Rings | RDP | Damping | `00`–`FF` |
| Rings | RPO | Position | `00`–`FF` |
| Plaits | PMD | Model | `00`–`17` (0–23) |
| Plaits | PHA | Harmonics | `00`–`FF` |
| Plaits | PTM | Timbre | `00`–`FF` |
| Plaits | PMO | Morph | `00`–`FF` |
| Plaits | PDC | Decay | `00`–`FF` |
| Plaits | PLG | LPG colour | `00`–`FF` |

The on-screen picker shows a description for each new command. These are PocketTracker-specific tracker commands, not a copied implementation of the closed-source M8 firmware. Effects are currently phrase-step live-note controls, not a modulation matrix or guaranteed modulation of notes triggered in the future.

## Build validation

After fetching Plaits, run `bash tests/run_mutable_smoke.sh`, `bash tests/run_plaits_smoke.sh`, and `bash tests/run_synth_fx_schema_smoke.sh`. The workflow also compiles an AArch64 PortMaster build and invokes the existing Mutable verification script. A green workflow only proves its build and smoke tests pass, not that a particular RG28XX USB DAC is electrically supported by its firmware.
