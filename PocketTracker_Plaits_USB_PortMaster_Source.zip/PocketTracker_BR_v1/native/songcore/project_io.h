#ifndef POCKETTRACKER_SONGCORE_PROJECT_IO_H
#define POCKETTRACKER_SONGCORE_PROJECT_IO_H

// .ptp / .pti: read with nlohmann/json (unknown keys ignored), written by a hand-rolled MINIFIED
// emitter — autosave rewrites the whole file every 3 s.
// ⚠️ The golden .ptp files are pretty-printed by the ORIGINAL implementation; never regenerate them
// from this emitter.
// Output: keys in declaration order (model.h); a field equal to its default is omitted, except
// fixed-size arrays and fields with no default; nulls omitted; enums by NAME; integers only.

#include "midi_map.h"
#include "model.h"
#include "../vendor/nlohmann/json.hpp"

#include <algorithm>
#include <string>
#include <vector>
#include <optional>
#include <cstdio>

namespace songcore {

using nlohmann::json;

// ─── parse helpers (missing / wrong-typed key → the supplied default) ──────────────────────────

namespace detail {

inline int get_int(const json& j, const char* k, int def) {
    auto it = j.find(k);
    return (it != j.end() && it->is_number()) ? it->get<int>() : def;
}

inline bool get_bool(const json& j, const char* k, bool def) {
    auto it = j.find(k);
    return (it != j.end() && it->is_boolean()) ? it->get<bool>() : def;
}
inline std::string get_str(const json& j, const char* k, const std::string& def) {
    auto it = j.find(k);
    return (it != j.end() && it->is_string()) ? it->get<std::string>() : def;
}
// Nullable string: absent or json null → nullopt.
inline std::optional<std::string> get_opt_str(const json& j, const char* k) {
    auto it = j.find(k);
    if (it != j.end() && it->is_string()) return it->get<std::string>();
    return std::nullopt;
}

inline Note parse_note(const json& j) {
    Note n;
    n.pitch  = get_int(j, "pitch",  n.pitch);
    n.octave = get_int(j, "octave", n.octave);
    return n;
}

inline PhraseStep parse_phrase_step(const json& j) {
    PhraseStep s;
    auto it = j.find("note");
    if (it != j.end() && it->is_object()) s.note = parse_note(*it);
    s.instrument = get_int(j, "instrument", s.instrument);
    s.volume     = get_int(j, "volume",     s.volume);
    s.fx1Type = get_int(j, "fx1Type", s.fx1Type);  s.fx1Value = get_int(j, "fx1Value", s.fx1Value);
    s.fx2Type = get_int(j, "fx2Type", s.fx2Type);  s.fx2Value = get_int(j, "fx2Value", s.fx2Value);
    s.fx3Type = get_int(j, "fx3Type", s.fx3Type);  s.fx3Value = get_int(j, "fx3Value", s.fx3Value);
    return s;
}

inline Phrase parse_phrase(const json& j, int index) {
    Phrase p(get_int(j, "id", index));
    auto it = j.find("steps");
    if (it != j.end() && it->is_array()) {
        p.steps.clear();
        for (const auto& e : *it) p.steps.push_back(parse_phrase_step(e));
    }
    return p;
}

inline std::vector<int> parse_int_array(const json& j, const char* k, const std::vector<int>& def) {
    auto it = j.find(k);
    if (it == j.end() || !it->is_array()) return def;
    std::vector<int> v;
    v.reserve(it->size());
    for (const auto& e : *it) v.push_back(e.is_number() ? e.get<int>() : 0);
    return v;
}

inline Chain parse_chain(const json& j, int index) {
    Chain c(get_int(j, "id", index));
    c.phraseRefs      = parse_int_array(j, "phraseRefs",      c.phraseRefs);
    c.transposeValues = parse_int_array(j, "transposeValues", c.transposeValues);
    // ⚠️ The CHAIN editor indexes these by cursor row, and a hand-edited file can hold short ones.
    c.phraseRefs.resize(CHAIN_ROWS, -1);
    c.transposeValues.resize(CHAIN_ROWS, 0);
    return c;
}

inline TableRow parse_table_row(const json& j) {
    TableRow r;
    r.transpose = get_int(j, "transpose", r.transpose);
    r.volume    = get_int(j, "volume",    r.volume);
    r.fx1Type = get_int(j, "fx1Type", r.fx1Type);  r.fx1Value = get_int(j, "fx1Value", r.fx1Value);
    r.fx2Type = get_int(j, "fx2Type", r.fx2Type);  r.fx2Value = get_int(j, "fx2Value", r.fx2Value);
    r.fx3Type = get_int(j, "fx3Type", r.fx3Type);  r.fx3Value = get_int(j, "fx3Value", r.fx3Value);
    return r;
}

inline Table parse_table(const json& j, int index) {
    Table t(get_int(j, "id", index));
    t.name = get_str(j, "name", t.name);
    auto it = j.find("rows");
    if (it != j.end() && it->is_array()) {
        t.rows.clear();
        for (const auto& e : *it) t.rows.push_back(parse_table_row(e));
    }
    return t;
}

inline ModSlot parse_mod_slot(const json& j) {
    ModSlot m;
    { auto it = j.find("type"); if (it != j.end() && it->is_string()) mod_type_from_name(it->get<std::string>(), m.type); }
    { auto it = j.find("dest"); if (it != j.end() && it->is_string()) mod_dest_from_name(it->get<std::string>(), m.dest); }
    m.amount      = get_int(j, "amount",      m.amount);
    m.attack      = get_int(j, "attack",      m.attack);
    m.hold        = get_int(j, "hold",        m.hold);
    m.decay       = get_int(j, "decay",       m.decay);
    m.sustain     = get_int(j, "sustain",     m.sustain);
    m.release     = get_int(j, "release",     m.release);
    m.oscShape    = get_int(j, "oscShape",    m.oscShape);
    m.lfoTrigMode = get_int(j, "lfoTrigMode", m.lfoTrigMode);
    m.lfoFreq     = get_int(j, "lfoFreq",     m.lfoFreq);
    return m;
}

inline Groove parse_groove(const json& j, int index) {
    Groove g(get_int(j, "id", index));
    g.name  = get_str(j, "name", g.name);
    g.steps = parse_int_array(j, "steps", g.steps);
    g.ticksPerStep = get_int(j, "ticksPerStep", g.ticksPerStep);
    // The GROOVE screen indexes all sixteen by cursor row; same repair as `parse_chain`.
    g.steps.resize(16, -1);
    return g;
}

inline Scale parse_scale(const json& j, int index) {
    Scale s(get_int(j, "id", index));
    s.name    = get_str(j, "name", s.name);
    s.enabled = parse_int_array(j, "enabled", s.enabled);
    s.offset  = parse_int_array(j, "offset",  s.offset);
    // A hand-edited or truncated array must not leave a 12-degree consumer reading past its end.
    s.enabled.resize(12, 1);
    s.offset.resize(12, 0);
    return s;
}

inline EqBand parse_eq_band(const json& j) {
    EqBand b;
    b.type = get_int(j, "type", b.type);
    b.freq = get_int(j, "freq", b.freq);
    b.gain = get_int(j, "gain", b.gain);
    b.q    = get_int(j, "q",    b.q);
    return b;
}

inline EqPreset parse_eq_preset(const json& j, int index) {
    EqPreset e(get_int(j, "id", index));
    auto it = j.find("bands");
    if (it != j.end() && it->is_array()) {
        e.bands.clear();
        for (const auto& b : *it) e.bands.push_back(parse_eq_band(b));
    }
    return e;
}

inline Track parse_track(const json& j, int index) {
    Track t(get_int(j, "id", index));
    auto it = j.find("chainRefs");
    if (it != j.end() && it->is_array()) {
        t.chainRefs.clear();
        for (const auto& e : *it) t.chainRefs.push_back(e.is_number() ? e.get<int>() : 0);
    }
    t.volume = get_int(j, "volume", t.volume);
    t.mute   = get_bool(j, "mute",  t.mute);
    t.solo   = get_bool(j, "solo",  t.solo);
    return t;
}

inline SFOverrides parse_sf_overrides(const json& j) {
    SFOverrides s;
    s.ampAttack  = get_int(j, "ampAttack",  s.ampAttack);
    s.ampDecay   = get_int(j, "ampDecay",   s.ampDecay);
    s.ampSustain = get_int(j, "ampSustain", s.ampSustain);
    s.ampRelease = get_int(j, "ampRelease", s.ampRelease);
    s.filterCut  = get_int(j, "filterCut",  s.filterCut);
    s.filterRes  = get_int(j, "filterRes",  s.filterRes);
    return s;
}

inline Instrument parse_instrument(const json& j, int index) {
    Instrument i(get_int(j, "id", index));
    i.name           = get_str(j, "name", i.name);
    i.sampleId       = get_int(j, "sampleId", i.sampleId);   // absent → -1 (field default), not the index
    i.volume         = get_int(j, "volume", i.volume);
    i.pan            = get_int(j, "pan", i.pan);
    { auto it = j.find("root"); if (it != j.end() && it->is_object()) i.root = parse_note(*it); }
    i.detune         = get_int(j, "detune", i.detune);
    i.drive          = get_int(j, "drive", i.drive);
    i.crush          = get_int(j, "crush", i.crush);
    i.downsample     = get_int(j, "downsample", i.downsample);
    i.filterType     = get_str(j, "filterType", i.filterType);
    i.filterCut      = get_int(j, "filterCut", i.filterCut);
    i.filterRes      = get_int(j, "filterRes", i.filterRes);
    i.sampleStart    = get_int(j, "sampleStart", i.sampleStart);
    i.sampleEnd      = get_int(j, "sampleEnd", i.sampleEnd);
    i.reverse        = get_bool(j, "reverse", i.reverse);
    i.loopMode       = get_str(j, "loopMode", i.loopMode);
    i.loopStart      = get_int(j, "loopStart", i.loopStart);
    i.loopEnd        = get_int(j, "loopEnd", i.loopEnd);
    i.sampleFilePath = get_opt_str(j, "sampleFilePath");
    i.tableId        = get_int(j, "tableId", i.tableId);
    i.tableTicRate   = get_int(j, "tableTicRate", i.tableTicRate);
    { auto it = j.find("modSlots");
      if (it != j.end() && it->is_array()) {
          i.modSlots.clear();
          for (const auto& m : *it) i.modSlots.push_back(parse_mod_slot(m));
      } }
    { auto it = j.find("instrumentType"); if (it != j.end() && it->is_string()) instrument_type_from_name(it->get<std::string>(), i.instrumentType); }
    i.soundfontPath  = get_opt_str(j, "soundfontPath");
    i.sfBank         = get_int(j, "sfBank", i.sfBank);
    i.sfPreset       = get_int(j, "sfPreset", i.sfPreset);
    i.macroModel = std::clamp(get_int(j,"macroModel",i.macroModel),0,46);
    i.macroTimbre = std::clamp(get_int(j,"macroTimbre",i.macroTimbre),0,255);
    i.macroColor = std::clamp(get_int(j,"macroColor",i.macroColor),0,255);
    i.plaitsModel = std::clamp(get_int(j,"plaitsModel",i.plaitsModel),0,23);
    i.plaitsHarmonics = std::clamp(get_int(j,"plaitsHarmonics",i.plaitsHarmonics),0,255);
    i.plaitsTimbre = std::clamp(get_int(j,"plaitsTimbre",i.plaitsTimbre),0,255);
    i.plaitsMorph = std::clamp(get_int(j,"plaitsMorph",i.plaitsMorph),0,255);
    i.plaitsDecay = std::clamp(get_int(j,"plaitsDecay",i.plaitsDecay),0,255);
    i.plaitsLpgColor = std::clamp(get_int(j,"plaitsLpgColor",i.plaitsLpgColor),0,255);
    i.grainPosition = std::clamp(get_int(j,"grainPosition",i.grainPosition),0,255);
    i.grainSize = std::clamp(get_int(j,"grainSize",i.grainSize),0,255);
    i.grainDensity = std::clamp(get_int(j,"grainDensity",i.grainDensity),0,255);
    i.grainScatter = std::clamp(get_int(j,"grainScatter",i.grainScatter),0,255);
    i.grainScan = std::clamp(get_int(j,"grainScan",i.grainScan),0,255);
    i.grainSpread = std::clamp(get_int(j,"grainSpread",i.grainSpread),0,255);
    { auto it = j.find("sfOverrides"); if (it != j.end() && it->is_object()) i.sfOverrides = parse_sf_overrides(*it); }
    i.reverbSend     = get_int(j, "reverbSend", i.reverbSend);
    i.delaySend      = get_int(j, "delaySend", i.delaySend);
    i.eqSlot         = get_int(j, "eqSlot", i.eqSlot);
    i.slicingMode    = get_int(j, "slicingMode", i.slicingMode);
    i.transposeEnabled = get_bool(j, "transposeEnabled", i.transposeEnabled);
    { auto it = j.find("sliceMarkers");
      if (it != j.end() && it->is_array())
          for (const auto& e : *it) i.sliceMarkers.push_back(e.is_number() ? e.get<int64_t>() : 0); }
    i.midiChannel = get_int(j, "midiChannel", i.midiChannel);
    i.midiBank    = get_int(j, "midiBank", i.midiBank);
    i.midiProgram = get_int(j, "midiProgram", i.midiProgram);
    i.midiLen     = get_int(j, "midiLen", i.midiLen);
    i.midiBendRange = std::clamp(get_int(j, "midiBendRange", i.midiBendRange),
                                 MIDI_BEND_RANGE_MIN, MIDI_BEND_RANGE_MAX);
    { auto it = j.find("midiCC");
      if (it != j.end() && it->is_array()) {
          // Re-sized, never appended: the slot count is a UI constant, and a newer build's file must
          // not hand this one more slots than the screen can draw.
          for (size_t s = 0; s < i.midiCC.size() && s < it->size(); ++s) {
              const json& e = (*it)[s];
              if (!e.is_object()) continue;
              i.midiCC[s].cc    = get_int(e, "cc", i.midiCC[s].cc);
              i.midiCC[s].value = get_int(e, "value", i.midiCC[s].value);
          }
      } }
    return i;
}

// ⚠️ A destination this build does not know is KEPT (greyed), so a downgrade deletes no mapping.
// Each range end is clamped separately, so an inverted range survives.
inline MidiMapping parse_midi_mapping(const json& j) {
    MidiMapping m;
    m.controller = (uint8_t)std::clamp(get_int(j, "controller", m.controller), 0, 127);
    m.dest       = (uint8_t)std::clamp(get_int(j, "dest", m.dest), 0, 255);
    m.scopeIndex = (uint8_t)std::clamp(get_int(j, "scopeIndex", m.scopeIndex), 0, 255);
    m.rangeMin   = get_int(j, "rangeMin", m.rangeMin);
    m.rangeMax   = get_int(j, "rangeMax", m.rangeMax);
    if (const MapDest* d = map_dest(m.dest)) {
        m.rangeMin = std::clamp(m.rangeMin, d->min, d->max);
        m.rangeMax = std::clamp(m.rangeMax, d->min, d->max);
    }
    // ⚠️ The scope index is not clamped: the pools are unpadded yet, and an index past the end is the
    // "destination gone" case `map_dest_present` already greys.
    return m;
}

template <class T, class F>
inline std::vector<T> parse_pool(const json& j, const char* k, F&& parse_elem) {
    std::vector<T> v;
    auto it = j.find(k);
    if (it != j.end() && it->is_array()) {
        int idx = 0;
        for (const auto& e : *it) v.push_back(parse_elem(e, idx++));
    }
    return v;  // absent/empty → normalize pads to canonical size
}

}  // namespace detail

// Parse a decoded .ptp object into a Project (field defaults for anything missing). Pools are taken
// verbatim; normalize_project() repairs their sizes.
inline Project parse_project(const json& j) {
    using namespace detail;
    Project p;  // scalar members hold their field defaults; pools start EMPTY
    p.version         = get_int(j, "version", p.version);
    p.name            = get_str(j, "name", p.name);
    p.tempo           = get_int(j, "tempo", p.tempo);
    p.transpose       = get_int(j, "transpose", p.transpose);
    p.masterVolume    = get_int(j, "masterVolume", p.masterVolume);
    p.ottDepth        = get_int(j, "ottDepth", p.ottDepth);
    p.masterBusFx     = get_int(j, "masterBusFx", p.masterBusFx);
    p.dustDepth       = get_int(j, "dustDepth", p.dustDepth);
    p.limiterPreGain  = get_int(j, "limiterPreGain", p.limiterPreGain);
    p.eqPresets       = parse_pool<EqPreset>(j, "eqPresets", parse_eq_preset);
    p.reverbFeedback  = get_int(j, "reverbFeedback", p.reverbFeedback);
    p.reverbDamp      = get_int(j, "reverbDamp", p.reverbDamp);
    p.reverbWet       = get_int(j, "reverbWet", p.reverbWet);
    p.reverbInputEq   = get_int(j, "reverbInputEq", p.reverbInputEq);
    p.reverbPreDelay  = get_int(j, "reverbPreDelay", p.reverbPreDelay);
    p.reverbWidth     = get_int(j, "reverbWidth", p.reverbWidth);
    p.reverbMod       = get_int(j, "reverbMod", p.reverbMod);
    p.reverbSize      = get_int(j, "reverbSize", p.reverbSize);
    p.reverbAlgo      = get_int(j, "reverbAlgo", p.reverbAlgo);
    p.reverbPreset    = get_str(j, "reverbPreset", p.reverbPreset);
    p.delayPreset     = get_str(j, "delayPreset", p.delayPreset);
    p.delayTime       = get_int(j, "delayTime", p.delayTime);
    p.delaySync       = get_bool(j, "delaySync", p.delaySync);
    p.delayFeedback   = get_int(j, "delayFeedback", p.delayFeedback);
    p.delayWet        = get_int(j, "delayWet", p.delayWet);
    p.delayReverbSend = get_int(j, "delayReverbSend", p.delayReverbSend);
    p.delayInputEq    = get_int(j, "delayInputEq", p.delayInputEq);
    p.delayPong       = get_bool(j, "delayPong", p.delayPong);
    p.delayTone       = get_int(j, "delayTone", p.delayTone);
    p.delayWobble     = get_int(j, "delayWobble", p.delayWobble);
    p.reverbMute      = get_bool(j, "reverbMute", p.reverbMute);
    p.reverbSolo      = get_bool(j, "reverbSolo", p.reverbSolo);
    p.delayMute       = get_bool(j, "delayMute", p.delayMute);
    p.delaySolo       = get_bool(j, "delaySolo", p.delaySolo);
    p.masterEqSlot    = get_int(j, "masterEqSlot", p.masterEqSlot);
    p.phrases     = parse_pool<Phrase>(j, "phrases", parse_phrase);
    p.chains      = parse_pool<Chain>(j, "chains", parse_chain);
    p.tracks      = parse_pool<Track>(j, "tracks", parse_track);
    p.instruments = parse_pool<Instrument>(j, "instruments", parse_instrument);
    p.tables      = parse_pool<Table>(j, "tables", parse_table);
    p.grooves     = parse_pool<Groove>(j, "grooves", parse_groove);
    p.scales      = parse_pool<Scale>(j, "scales", parse_scale);
    p.scaleKey    = get_int(j, "scaleKey", p.scaleKey);
    p.midiSyncOut           = get_int(j, "midiSyncOut", p.midiSyncOut);
    p.midiSendProgramChange = get_bool(j, "midiSendProgramChange", p.midiSendProgramChange);
    // ⚠️ Truncated at the cap: every incoming CC sweeps this list, so its length is paid on the audio
    // path. The ADD row refuses past the same number.
    { auto it = j.find("midiMappings");
      if (it != j.end() && it->is_array())
          for (const auto& e : *it) {
              if ((int)p.midiMappings.size() >= MIDI_MAP_MAX) break;
              if (e.is_object()) p.midiMappings.push_back(parse_midi_mapping(e));
          } }
    return p;
}

inline InstrumentPreset parse_instrument_preset(const json& j) {
    InstrumentPreset ip;
    ip.version = detail::get_int(j, "version", ip.version);
    auto it = j.find("instrument");
    if (it != j.end() && it->is_object()) ip.instrument = detail::parse_instrument(*it, ip.instrument.id);
    auto tr = j.find("tableRows");
    if (tr != j.end() && tr->is_array()) {
        std::vector<TableRow> rows;
        for (const auto& e : *tr) rows.push_back(detail::parse_table_row(e));
        ip.tableRows = std::move(rows);
    }
    return ip;
}

// Repair, don't reject: truncate over-long pools, pad short ones. True if anything changed.
inline bool normalize_project(Project& p) {
    if ((int)p.phrases.size() == POOL_PHRASES && (int)p.chains.size() == POOL_CHAINS &&
        (int)p.tracks.size() == POOL_TRACKS && (int)p.instruments.size() == POOL_INSTRUMENTS &&
        (int)p.tables.size() == POOL_TABLES && (int)p.grooves.size() == POOL_GROOVES &&
        (int)p.eqPresets.size() == POOL_EQPRESETS && (int)p.scales.size() == POOL_SCALES) {
        return false;
    }
    Project d = make_default_project();
    auto fix = [](auto& pool, auto& def, int n) {
        std::decay_t<decltype(pool)> out;
        out.reserve(n);
        for (int i = 0; i < n; ++i) out.push_back(i < (int)pool.size() ? pool[i] : def[i]);
        pool = std::move(out);
    };
    fix(p.phrases,     d.phrases,     POOL_PHRASES);
    fix(p.chains,      d.chains,      POOL_CHAINS);
    fix(p.tracks,      d.tracks,      POOL_TRACKS);
    fix(p.instruments, d.instruments, POOL_INSTRUMENTS);
    fix(p.tables,      d.tables,      POOL_TABLES);
    fix(p.grooves,     d.grooves,     POOL_GROOVES);
    fix(p.eqPresets,   d.eqPresets,   POOL_EQPRESETS);
    fix(p.scales,      d.scales,      POOL_SCALES);
    return true;
}

// Version 0 → 1: a table row volume of 0xFF meant "full"; it now means "no change", spelled -1.
inline void migrate_project(Project& p) {
    if (p.version < 1) {
        for (auto& t : p.tables)
            for (auto& r : t.rows)
                if (r.volume == 0xFF) r.volume = -1;
        p.version = 1;
    }
}

// The full loader tail: normalize pools, then migrate. (decode is the caller's json::parse.)
inline void normalize_and_migrate(Project& p) {
    normalize_project(p);
    migrate_project(p);
}

// ─── writer ─────────────────────────────────────────────────────────────────────────────────────

// Same schema either way. No default: MINIFIED for .ptp/.pti, PRETTY for hand-editable .ptt themes.
enum class JsonLayout { Minified, Pretty };

class JsonWriter {
public:
    std::string out;

    explicit JsonWriter(JsonLayout layout) : pretty_(layout == JsonLayout::Pretty) {}

    void begin_object() { out += '{'; stack_.push_back(true); ++depth_; }
    void end_object()   { close('}'); }
    void begin_array()  { out += '['; stack_.push_back(true); ++depth_; }
    void end_array()    { close(']'); }

    // In an object: emit the separator + `"key":` prefix (`"key": ` when pretty). Follow with a
    // value_* call or a nested begin_object/begin_array.
    void key(const char* k) {
        separator();
        out += '"'; escape_into(k); out += pretty_ ? "\": " : "\":";
    }
    // In an array: emit the separator before an element value.
    void element() { separator(); }

    void value_int(long long v)          { out += std::to_string(v); }
    void value_bool(bool b)              { out += b ? "true" : "false"; }
    void value_string(const std::string& s) { out += '"'; escape_into(s.c_str(), s.size()); out += '"'; }

    void field_int(const char* k, long long v)          { key(k); value_int(v); }
    void field_bool(const char* k, bool v)              { key(k); value_bool(v); }
    void field_string(const char* k, const std::string& v) { key(k); value_string(v); }

private:
    std::vector<bool> stack_;  // per open container: still empty? (true = no members yet)
    int depth_ = 0;
    bool pretty_;

    // The comma before every member except a container's first, and — pretty only — the newline and
    // indent. With key()'s colon, the only places layout is emitted.
    void separator() {
        if (!stack_.back()) out += ',';
        stack_.back() = false;
        newline_indent();
    }
    // An empty container stays `{}` / `[]` on one line, with or without pretty-printing.
    void close(char brace) {
        const bool had = !stack_.back();
        stack_.pop_back();
        --depth_;
        if (had) newline_indent();
        out += brace;
    }
    void newline_indent() {
        if (!pretty_) return;
        out += '\n';
        out.append((size_t)depth_ * 4, ' ');
    }

    void escape_into(const char* s) { escape_into(s, std::char_traits<char>::length(s)); }
    void escape_into(const char* s, size_t n) {
        for (size_t i = 0; i < n; ++i) {
            unsigned char c = (unsigned char)s[i];
            switch (c) {
                case '"':  out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\b': out += "\\b";  break;
                case '\t': out += "\\t";  break;
                case '\n': out += "\\n";  break;
                case '\f': out += "\\f";  break;
                case '\r': out += "\\r";  break;
                default:
                    if (c < 0x20) { char buf[8]; std::snprintf(buf, sizeof buf, "\\u%04x", c); out += buf; }
                    else out += (char)c;  // pass UTF-8 / printable ASCII through
            }
        }
    }
};

namespace detail {

inline void emit_note(JsonWriter& w, const Note& n) {
    w.begin_object();
    w.field_int("pitch",  n.pitch);
    w.field_int("octave", n.octave);
    w.end_object();
}

inline void emit_phrase_step(JsonWriter& w, const PhraseStep& s) {
    w.begin_object();
    if (s.note != Note::EMPTY())  { w.key("note"); emit_note(w, s.note); }
    if (s.instrument != 0x00)     w.field_int("instrument", s.instrument);
    if (s.volume     != 0x7F)     w.field_int("volume",     s.volume);
    if (s.fx1Type  != 0x00)       w.field_int("fx1Type",  s.fx1Type);
    if (s.fx1Value != 0x00)       w.field_int("fx1Value", s.fx1Value);
    if (s.fx2Type  != 0x00)       w.field_int("fx2Type",  s.fx2Type);
    if (s.fx2Value != 0x00)       w.field_int("fx2Value", s.fx2Value);
    if (s.fx3Type  != 0x00)       w.field_int("fx3Type",  s.fx3Type);
    if (s.fx3Value != 0x00)       w.field_int("fx3Value", s.fx3Value);
    w.end_object();
}

inline void emit_int_array(JsonWriter& w, const char* key, const std::vector<int>& a) {
    w.key(key);
    w.begin_array();
    for (int v : a) { w.element(); w.value_int(v); }
    w.end_array();
}

inline void emit_phrase(JsonWriter& w, const Phrase& p) {
    w.begin_object();
    w.field_int("id", p.id);
    w.key("steps");
    w.begin_array();
    for (const auto& s : p.steps) { w.element(); emit_phrase_step(w, s); }
    w.end_array();
    w.end_object();
}

inline void emit_chain(JsonWriter& w, const Chain& c) {
    w.begin_object();
    w.field_int("id", c.id);
    emit_int_array(w, "phraseRefs",      c.phraseRefs);
    emit_int_array(w, "transposeValues", c.transposeValues);
    w.end_object();
}

inline void emit_table_row(JsonWriter& w, const TableRow& r) {
    w.begin_object();
    if (r.transpose != 0x00) w.field_int("transpose", r.transpose);
    if (r.volume    != -1)   w.field_int("volume",    r.volume);
    if (r.fx1Type  != 0x00)  w.field_int("fx1Type",  r.fx1Type);
    if (r.fx1Value != 0x00)  w.field_int("fx1Value", r.fx1Value);
    if (r.fx2Type  != 0x00)  w.field_int("fx2Type",  r.fx2Type);
    if (r.fx2Value != 0x00)  w.field_int("fx2Value", r.fx2Value);
    if (r.fx3Type  != 0x00)  w.field_int("fx3Type",  r.fx3Type);
    if (r.fx3Value != 0x00)  w.field_int("fx3Value", r.fx3Value);
    w.end_object();
}

inline void emit_table(JsonWriter& w, const Table& t) {
    w.begin_object();
    w.field_int("id", t.id);
    if (t.name != default_table_name(t.id)) w.field_string("name", t.name);
    w.key("rows");
    w.begin_array();
    for (const auto& r : t.rows) { w.element(); emit_table_row(w, r); }
    w.end_array();
    w.end_object();
}

inline void emit_mod_slot(JsonWriter& w, const ModSlot& m) {
    w.begin_object();
    if (m.type != ModType::NONE) w.field_string("type", mod_type_name(m.type));
    if (m.dest != ModDest::NONE) w.field_string("dest", mod_dest_name(m.dest));
    if (m.amount      != 0xFF) w.field_int("amount",      m.amount);
    if (m.attack      != 0x00) w.field_int("attack",      m.attack);
    if (m.hold        != 0x00) w.field_int("hold",        m.hold);
    if (m.decay       != 0x00) w.field_int("decay",       m.decay);
    if (m.sustain     != 0x80) w.field_int("sustain",     m.sustain);
    if (m.release     != 0x00) w.field_int("release",     m.release);
    if (m.oscShape    != 0x00) w.field_int("oscShape",    m.oscShape);
    if (m.lfoTrigMode != 0x00) w.field_int("lfoTrigMode", m.lfoTrigMode);
    if (m.lfoFreq     != 0x40) w.field_int("lfoFreq",     m.lfoFreq);
    w.end_object();
}

inline void emit_groove(JsonWriter& w, const Groove& g) {
    w.begin_object();
    w.field_int("id", g.id);
    if (!g.name.empty()) w.field_string("name", g.name);
    // ⚠️ `steps` is never default-guarded: every project on disk writes all sixteen, so old blank
    // grooves load back blank whatever a fresh Groove is born with.
    emit_int_array(w, "steps", g.steps);
    if (g.ticksPerStep != 12) w.field_int("ticksPerStep", g.ticksPerStep);
    w.end_object();
}

inline void emit_scale(JsonWriter& w, const Scale& s) {
    w.begin_object();
    w.field_int("id", s.id);
    if (!s.name.empty()) w.field_string("name", s.name);
    // ⏸️ `offset` is written once non-default although nothing reads it yet, so microtuning will need
    // no migration.
    if (s.enabled != std::vector<int>(12, 1)) emit_int_array(w, "enabled", s.enabled);
    if (s.offset  != std::vector<int>(12, 0)) emit_int_array(w, "offset",  s.offset);
    w.end_object();
}

inline void emit_eq_band(JsonWriter& w, const EqBand& b) {
    w.begin_object();
    if (b.type != 0)    w.field_int("type", b.type);
    if (b.freq != 0x80) w.field_int("freq", b.freq);
    if (b.gain != 120)  w.field_int("gain", b.gain);
    if (b.q    != 0x80) w.field_int("q",    b.q);
    w.end_object();
}

inline void emit_eq_preset(JsonWriter& w, const EqPreset& e) {
    w.begin_object();
    w.field_int("id", e.id);
    w.key("bands");
    w.begin_array();
    for (const auto& b : e.bands) { w.element(); emit_eq_band(w, b); }
    w.end_array();
    w.end_object();
}

inline void emit_track(JsonWriter& w, const Track& t) {
    w.begin_object();
    w.field_int("id", t.id);
    if (!t.chainRefs.empty()) {
        w.key("chainRefs");
        w.begin_array();
        for (int v : t.chainRefs) { w.element(); w.value_int(v); }
        w.end_array();
    }
    if (t.volume != 0xFF) w.field_int("volume", t.volume);
    if (t.mute)           w.field_bool("mute", t.mute);
    if (t.solo)           w.field_bool("solo", t.solo);
    w.end_object();
}

inline void emit_sf_overrides(JsonWriter& w, const SFOverrides& s) {
    w.begin_object();
    if (s.ampAttack  != -1) w.field_int("ampAttack",  s.ampAttack);
    if (s.ampDecay   != -1) w.field_int("ampDecay",   s.ampDecay);
    if (s.ampSustain != -1) w.field_int("ampSustain", s.ampSustain);
    if (s.ampRelease != -1) w.field_int("ampRelease", s.ampRelease);
    if (s.filterCut  != -1) w.field_int("filterCut",  s.filterCut);
    if (s.filterRes  != -1) w.field_int("filterRes",  s.filterRes);
    w.end_object();
}

inline void emit_instrument(JsonWriter& w, const Instrument& i) {
    w.begin_object();
    w.field_int("id", i.id);
    if (i.name != default_instrument_name(i.id)) w.field_string("name", i.name);
    if (i.sampleId != -1)   w.field_int("sampleId", i.sampleId);
    if (i.volume != 0xFF)   w.field_int("volume", i.volume);
    if (i.pan != 0x80)      w.field_int("pan", i.pan);
    if (i.root != Note::C4()) { w.key("root"); emit_note(w, i.root); }
    if (i.detune != 0x80)   w.field_int("detune", i.detune);
    if (i.drive != 0x00)    w.field_int("drive", i.drive);
    if (i.crush != 0x0)     w.field_int("crush", i.crush);
    if (i.downsample != 0x0) w.field_int("downsample", i.downsample);
    if (i.filterType != "off") w.field_string("filterType", i.filterType);
    if (i.filterCut != 0x00) w.field_int("filterCut", i.filterCut);
    if (i.filterRes != 0x00) w.field_int("filterRes", i.filterRes);
    if (i.sampleStart != 0x00) w.field_int("sampleStart", i.sampleStart);
    if (i.sampleEnd != 0xFF) w.field_int("sampleEnd", i.sampleEnd);
    if (i.reverse)          w.field_bool("reverse", i.reverse);
    if (i.loopMode != "off") w.field_string("loopMode", i.loopMode);
    if (i.loopStart != 0x00) w.field_int("loopStart", i.loopStart);
    if (i.loopEnd != 0xFF)  w.field_int("loopEnd", i.loopEnd);
    if (i.sampleFilePath)   w.field_string("sampleFilePath", *i.sampleFilePath);
    if (i.tableId != -1)    w.field_int("tableId", i.tableId);
    if (i.tableTicRate != 0x06) w.field_int("tableTicRate", i.tableTicRate);
    w.key("modSlots");
    w.begin_array();
    for (const auto& m : i.modSlots) { w.element(); emit_mod_slot(w, m); }
    w.end_array();
    if (i.instrumentType != InstrumentType::SAMPLER) w.field_string("instrumentType", instrument_type_name(i.instrumentType));
    if (i.soundfontPath)    w.field_string("soundfontPath", *i.soundfontPath);
    if (i.sfBank != 0)      w.field_int("sfBank", i.sfBank);
    if (i.sfPreset != 0)     w.field_int("sfPreset", i.sfPreset);
    if (i.macroModel) w.field_int("macroModel",i.macroModel);
    if (i.macroTimbre != 128) w.field_int("macroTimbre",i.macroTimbre);
    if (i.macroColor != 128) w.field_int("macroColor",i.macroColor);
    if (i.plaitsModel != 8) w.field_int("plaitsModel",i.plaitsModel);
    if (i.plaitsHarmonics != 128) w.field_int("plaitsHarmonics",i.plaitsHarmonics);
    if (i.plaitsTimbre != 128) w.field_int("plaitsTimbre",i.plaitsTimbre);
    if (i.plaitsMorph != 128) w.field_int("plaitsMorph",i.plaitsMorph);
    if (i.plaitsDecay != 128) w.field_int("plaitsDecay",i.plaitsDecay);
    if (i.plaitsLpgColor != 128) w.field_int("plaitsLpgColor",i.plaitsLpgColor);
    if (i.grainPosition != 128) w.field_int("grainPosition",i.grainPosition);
    if (i.grainSize != 96) w.field_int("grainSize",i.grainSize);
    if (i.grainDensity != 96) w.field_int("grainDensity",i.grainDensity);
    if (i.grainScatter != 32) w.field_int("grainScatter",i.grainScatter);
    if (i.grainScan != 128) w.field_int("grainScan",i.grainScan);
    if (i.grainSpread != 128) w.field_int("grainSpread",i.grainSpread);
    if (i.sfOverrides != SFOverrides{}) { w.key("sfOverrides"); emit_sf_overrides(w, i.sfOverrides); }
    if (i.reverbSend != 0x00) w.field_int("reverbSend", i.reverbSend);
    if (i.delaySend != 0x00) w.field_int("delaySend", i.delaySend);
    if (i.eqSlot != -1)     w.field_int("eqSlot", i.eqSlot);
    if (i.slicingMode != 0) w.field_int("slicingMode", i.slicingMode);
    // ⚠️ Defaults to TRUE, so the guard is inverted: the field appears only once turned OFF.
    if (!i.transposeEnabled) w.field_bool("transposeEnabled", i.transposeEnabled);
    if (!i.sliceMarkers.empty()) {
        w.key("sliceMarkers");
        w.begin_array();
        for (int64_t v : i.sliceMarkers) { w.element(); w.value_int(v); }
        w.end_array();
    }
    // EXTERNAL: every field default-guarded; `midiCC` whole-or-nothing, so others grow no "{}".
    if (i.midiChannel != 0)  w.field_int("midiChannel", i.midiChannel);
    if (i.midiBank != -1)    w.field_int("midiBank", i.midiBank);
    if (i.midiProgram != -1) w.field_int("midiProgram", i.midiProgram);
    if (i.midiLen != 0)      w.field_int("midiLen", i.midiLen);
    if (i.midiBendRange != MIDI_BEND_RANGE_DEFAULT) w.field_int("midiBendRange", i.midiBendRange);
    if (i.midiCC != std::vector<MidiCcSlot>(MIDI_CC_SLOTS)) {
        w.key("midiCC");
        w.begin_array();
        for (const auto& s : i.midiCC) {
            w.element();
            w.begin_object();
            if (s.cc != -1)    w.field_int("cc", s.cc);
            if (s.value != -1) w.field_int("value", s.value);
            w.end_object();
        }
        w.end_array();
    }
    w.end_object();
}

template <class T, class F>
inline void emit_pool(JsonWriter& w, const char* key, const std::vector<T>& pool, F&& emit_elem) {
    w.key(key);
    w.begin_array();
    for (const auto& e : pool) { w.element(); emit_elem(w, e); }
    w.end_array();
}

}  // namespace detail

// Serialize a Project to its .ptp bytes (minified, no trailing newline).
inline std::string serialize_project(const Project& p) {
    using namespace detail;
    JsonWriter w{JsonLayout::Minified};
    w.begin_object();
    if (p.version != 0)         w.field_int("version", p.version);
    if (p.name != "UNTITLED")   w.field_string("name", p.name);
    if (p.tempo != 128)         w.field_int("tempo", p.tempo);
    if (p.transpose != 0)       w.field_int("transpose", p.transpose);
    if (p.masterVolume != 0xFF) w.field_int("masterVolume", p.masterVolume);
    if (p.ottDepth != 0)        w.field_int("ottDepth", p.ottDepth);
    if (p.masterBusFx != 0)     w.field_int("masterBusFx", p.masterBusFx);
    if (p.dustDepth != 0)       w.field_int("dustDepth", p.dustDepth);
    if (p.limiterPreGain != 0)  w.field_int("limiterPreGain", p.limiterPreGain);
    emit_pool(w, "eqPresets", p.eqPresets, emit_eq_preset);
    if (p.reverbFeedback != 0x60) w.field_int("reverbFeedback", p.reverbFeedback);
    if (p.reverbDamp != 0x80)     w.field_int("reverbDamp", p.reverbDamp);
    if (p.reverbWet != 0x80)      w.field_int("reverbWet", p.reverbWet);
    if (p.reverbInputEq != -1)    w.field_int("reverbInputEq", p.reverbInputEq);
    if (p.reverbPreDelay != 0)    w.field_int("reverbPreDelay", p.reverbPreDelay);
    if (p.reverbWidth != 0x80)    w.field_int("reverbWidth", p.reverbWidth);
    if (p.reverbMod != 0x10)      w.field_int("reverbMod", p.reverbMod);
    if (p.reverbSize != 0x60)     w.field_int("reverbSize", p.reverbSize);
    if (p.reverbAlgo != 0)        w.field_int("reverbAlgo", p.reverbAlgo);
    if (!p.reverbPreset.empty())  w.field_string("reverbPreset", p.reverbPreset);
    if (!p.delayPreset.empty())   w.field_string("delayPreset", p.delayPreset);
    if (p.delayTime != 0x40)      w.field_int("delayTime", p.delayTime);
    if (p.delaySync)              w.field_bool("delaySync", p.delaySync);
    if (p.delayFeedback != 0x60)  w.field_int("delayFeedback", p.delayFeedback);
    if (p.delayWet != 0x80)       w.field_int("delayWet", p.delayWet);
    if (p.delayReverbSend != 0)   w.field_int("delayReverbSend", p.delayReverbSend);
    if (p.delayInputEq != -1)     w.field_int("delayInputEq", p.delayInputEq);
    if (p.delayPong)              w.field_bool("delayPong", p.delayPong);
    if (p.delayTone != 0xFF)      w.field_int("delayTone", p.delayTone);
    if (p.delayWobble != 0)       w.field_int("delayWobble", p.delayWobble);
    if (p.reverbMute)             w.field_bool("reverbMute", p.reverbMute);
    if (p.reverbSolo)             w.field_bool("reverbSolo", p.reverbSolo);
    if (p.delayMute)              w.field_bool("delayMute", p.delayMute);
    if (p.delaySolo)              w.field_bool("delaySolo", p.delaySolo);
    if (p.masterEqSlot != -1)     w.field_int("masterEqSlot", p.masterEqSlot);
    emit_pool(w, "phrases",     p.phrases,     emit_phrase);
    emit_pool(w, "chains",      p.chains,      emit_chain);
    emit_pool(w, "tracks",      p.tracks,      emit_track);
    emit_pool(w, "instruments", p.instruments, emit_instrument);
    emit_pool(w, "tables",      p.tables,      emit_table);
    emit_pool(w, "grooves",     p.grooves,     emit_groove);
    // ⚠️ The scale pool is omitted WHOLE when nothing was authored (every other pool is always
    // written): absent and default both mean chromatic, and older files stay byte-identical.
    {
        bool anyAuthored = (int)p.scales.size() != POOL_SCALES;
        for (const Scale& s : p.scales)
            if (!s.name.empty() || s.enabled != std::vector<int>(12, 1) ||
                s.offset != std::vector<int>(12, 0)) { anyAuthored = true; break; }
        if (anyAuthored) emit_pool(w, "scales", p.scales, emit_scale);
    }
    if (p.scaleKey != 0) w.field_int("scaleKey", p.scaleKey);
    // MIDI. ⚠️ `midiSendProgramChange` defaults to TRUE: inverted guard.
    if (p.midiSyncOut != 0)          w.field_int("midiSyncOut", p.midiSyncOut);
    if (!p.midiSendProgramChange)    w.field_bool("midiSendProgramChange", p.midiSendProgramChange);
    // ⚠️ Omitted whole when empty, so a song that never mapped a knob gains no byte. Fields inside are
    // guarded against their struct defaults: the usual row is `{"controller":74,"dest":5}`.
    if (!p.midiMappings.empty()) {
        w.key("midiMappings");
        w.begin_array();
        for (const MidiMapping& m : p.midiMappings) {
            w.element();
            w.begin_object();
            if (m.controller != 0)  w.field_int("controller", m.controller);
            if (m.dest != 0)        w.field_int("dest", m.dest);
            if (m.scopeIndex != 0)  w.field_int("scopeIndex", m.scopeIndex);
            if (m.rangeMin != 0)    w.field_int("rangeMin", m.rangeMin);
            if (m.rangeMax != 255)  w.field_int("rangeMax", m.rangeMax);
            w.end_object();
        }
        w.end_array();
    }
    w.end_object();
    return std::move(w.out);
}

// Serialize an InstrumentPreset (.pti).
inline std::string serialize_instrument_preset(const InstrumentPreset& ip) {
    using namespace detail;
    JsonWriter w{JsonLayout::Minified};
    w.begin_object();
    if (ip.version != 1) w.field_int("version", ip.version);
    w.key("instrument");
    emit_instrument(w, ip.instrument);
    if (ip.tableRows) {
        w.key("tableRows");
        w.begin_array();
        for (const auto& r : *ip.tableRows) { w.element(); emit_table_row(w, r); }
        w.end_array();
    }
    w.end_object();
    return std::move(w.out);
}

}  // namespace songcore

#endif  // POCKETTRACKER_SONGCORE_PROJECT_IO_H
