#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include "rings/dsp/part.h"

namespace pt::synth {
// Original Rings Part, internal excitation, one voice per tracker voice.
class RingsVoice {
public:
    void reset(int model) {
        std::memset(static_cast<void*>(&part_), 0, sizeof(part_));
        std::fill(reverb_, reverb_ + 32768, uint16_t(0));
        part_.Init(reverb_);
        part_.set_polyphony(1);
        part_.set_model(static_cast<rings::ResonatorModel>(std::clamp(model, 0, 5)));
        index_ = 24; phase_ = 0; trigger_ = true;
        previousL_ = previousR_ = currentL_ = currentR_ = 0;
    }
    void next(float hz, float rate, int model, float structure, float brightness,
              float damping, float position, float& left, float& right) {
        left = right = 0;
        if (!(rate > 0) || !std::isfinite(hz)) return;
        phase_ += 48000.0 / rate;
        while (phase_ >= 1.0) {
            if (index_ >= 24) {
                rings::PerformanceState state{};
                state.internal_exciter = true;
                state.internal_strum = false;
                state.internal_note = false;
                state.strum = trigger_;
                state.note = 69.f + 12.f * std::log2(std::clamp(hz, 8.f, 12543.f) / 440.f);
                state.tonic = 0;
                state.chord = 0;
                rings::Patch patch{std::clamp(structure,0.f,1.f),std::clamp(brightness,0.f,1.f),
                                   std::clamp(damping,0.f,1.f),std::clamp(position,0.f,1.f)};
                part_.set_model(static_cast<rings::ResonatorModel>(std::clamp(model,0,5)));
                float input[24]{};
                part_.Process(state,patch,input,out_,aux_,24);
                trigger_ = false; index_ = 0;
            }
            previousL_ = currentL_; previousR_ = currentR_;
            currentL_ = out_[index_]; currentR_ = aux_[index_++];
            phase_ -= 1.0;
        }
        left = std::clamp(previousL_ + (currentL_-previousL_)*float(phase_),-1.f,1.f);
        right = std::clamp(previousR_ + (currentR_-previousR_)*float(phase_),-1.f,1.f);
    }
private:
    rings::Part part_;
    uint16_t reverb_[32768]{};
    float out_[24]{}, aux_[24]{};
    int index_ = 24;
    double phase_ = 0;
    bool trigger_ = true;
    float previousL_=0, previousR_=0, currentL_=0, currentR_=0;
};
}
