#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include "plaits/dsp/voice.h"
#include "stmlib/utils/buffer_allocator.h"

namespace pt::synth {
// Original Mutable Instruments Plaits v1.2 DSP, running at the engine's 48 kHz.
// The source is obtained separately by tools/fetch_plaits.sh and retains its MIT headers.
// No allocation or I/O in next(); all buffers are owned by the audio callback.
class PlaitsVoice {
public:
    void reset(int model) {
        std::fill(shared_.begin(), shared_.end(), uint8_t{0});
        stmlib::BufferAllocator allocator(shared_.data(), shared_.size());
        voice_.Init(&allocator);
        index_ = static_cast<int>(frames_.size());
        previousL_ = previousR_ = currentL_ = currentR_ = 0.f;
        phase_ = 0.0;
        model_ = std::clamp(model, 0, 23);
    }
    void next(float hz, float rate, int model, float harmonics, float timbre,
              float morph, float decay, float lpgColor, float& left, float& right) {
        left = right = 0.f;
        if (!(rate > 0.f) || !std::isfinite(hz)) return;
        model_ = std::clamp(model, 0, 23);
        phase_ += 48000.0 / static_cast<double>(rate);
        while (phase_ >= 1.0) {
            if (index_ >= static_cast<int>(frames_.size())) {
                plaits::Patch patch{};
                patch.note = 69.f + 12.f * std::log2(std::clamp(hz, 8.f, 12543.f) / 440.f);
                patch.engine = model_;
                patch.harmonics = std::clamp(harmonics, 0.f, 1.f);
                patch.timbre = std::clamp(timbre, 0.f, 1.f);
                patch.morph = std::clamp(morph, 0.f, 1.f);
                patch.decay = std::clamp(decay, 0.f, 1.f);
                patch.lpg_colour = std::clamp(lpgColor, 0.f, 1.f);
                plaits::Modulations mod{};
                mod.level = 1.f;
                mod.trigger = 1.f;
                mod.trigger_patched = true;
                voice_.Render(patch, mod, frames_.data(), frames_.size());
                index_ = 0;
            }
            previousL_ = currentL_;
            previousR_ = currentR_;
            currentL_ = frames_[index_].out / 32768.f;
            currentR_ = frames_[index_].aux / 32768.f;
            ++index_;
            phase_ -= 1.0;
        }
        left = std::clamp(previousL_ + (currentL_ - previousL_) * static_cast<float>(phase_), -1.f, 1.f);
        right = std::clamp(previousR_ + (currentR_ - previousR_) * static_cast<float>(phase_), -1.f, 1.f);
    }
private:
    // Plaits hardware allocates 16384 bytes. Per voice keeps independent engine state.
    alignas(8) std::array<uint8_t, 16384> shared_{};
    plaits::Voice voice_{};
    std::array<plaits::Voice::Frame, 12> frames_{};
    int index_ = 12, model_ = 8;
    double phase_ = 0.0;
    float previousL_ = 0, previousR_ = 0, currentL_ = 0, currentR_ = 0;
};
}
