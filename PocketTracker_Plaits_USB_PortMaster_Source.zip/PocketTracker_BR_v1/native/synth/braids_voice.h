#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include "braids/macro_oscillator.h"

namespace pt::synth {
// Original Braids DSP at 96 kHz; parameter updates occur at its 24-frame block boundary.
class BraidsVoice {
public:
    void reset(int shape = 0) {
        std::memset(static_cast<void*>(&osc_),0,sizeof(osc_));
        osc_.Init(); index_ = 24; position_ = 0;
        previous_ = current_ = 0;
        shape_ = std::clamp(shape,0,46);
        osc_.set_shape(static_cast<braids::MacroOscillatorShape>(shape_));
        osc_.Strike();
    }
    float next(float frequency,float rate,int shape,float timbre,float color) {
        if (!(rate > 0) || !std::isfinite(frequency)) return 0;
        position_ += 96000.0 / rate;
        while (position_ >= 1.0) {
            if (index_ >= 24) {
                int selected = std::clamp(shape,0,46);
                if (selected != shape_) {
                    osc_.set_shape(static_cast<braids::MacroOscillatorShape>(selected));
                    shape_ = selected;
                }
                float midi = 69.f + 12.f * std::log2(std::clamp(frequency,0.1f,20000.f)/440.f);
                osc_.set_pitch(static_cast<int16_t>(std::clamp(std::lround(midi*128.f),0l,16383l)));
                osc_.set_parameters(int16_t(std::lround(std::clamp(timbre,0.f,1.f)*32767.f)),
                                    int16_t(std::lround(std::clamp(color,0.f,1.f)*32767.f)));
                uint8_t sync[24]{};
                osc_.Render(sync,buffer_,24); index_=0;
            }
            previous_=current_; current_=buffer_[index_++]*(1.f/32768.f); position_-=1;
        }
        return std::clamp(previous_+(current_-previous_)*float(position_),-1.f,1.f);
    }
private:
    braids::MacroOscillator osc_;
    int16_t buffer_[24]{};
    int index_=24,shape_=0;
    double position_=0;
    float previous_=0,current_=0;
};
}
