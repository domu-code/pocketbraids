#pragma once
// Portable, allocation-free DSP building blocks for future PocketTracker MACRO/GRANULAR instruments.
// These are original approximations, NOT Mutable Instruments firmware or M8 DSP.
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace pt::synth {
constexpr float PI = 3.14159265358979323846f;
inline float clamp01(float x) { return std::max(0.0f, std::min(1.0f, x)); }
inline float bipolar(float x) { return 2.0f * clamp01(x) - 1.0f; }
inline float frac(float x) { return x - std::floor(x); }
inline float tri(float p) { return 1.0f - 4.0f * std::abs(frac(p) - 0.5f); }
inline float saw(float p) { return 2.0f * frac(p) - 1.0f; }
inline float pulse(float p, float width) { return frac(p) < width ? 1.0f : -1.0f; }
inline float sine(float p) { return std::sin(2.0f * PI * p); }
inline float fold(float x) { return 2.0f * std::abs(2.0f * frac(x * 0.25f + 0.25f) - 1.0f) - 1.0f; }
inline float lerp(float a,float b,float t) { return a + (b-a)*t; }

// The model index is deliberately stable for project persistence once wired into the instrument UI.
// These are compact synthesis families: several indices share primitives, with different modulation maps.
inline constexpr const char* MACRO_NAMES[47] = {
  "CSAW","MORPH","SAW SQUARE","SINE TRIANGLE","BUZZ","SQUARE SUB","SAW SUB","SQUARE SYNC",
  "SAW SYNC","TRIPLE SAW","TRIPLE SQUARE","TRIPLE TRI","TRIPLE SINE","RING",
  "SAW SWARM","SAW COMB","TOY","DIGITAL LP","DIGITAL PK","DIGITAL BP","DIGITAL HP",
  "VOSIM","VOWEL","VOWEL FOF","HARMONICS","FM","FEEDBACK FM","CHAOTIC FM",
  "PLUCK","BOW","BLOW","FLUTE","BELL","DRUM","KICK","CYMBAL","SNARE",
  "WAVETABLE","WAVEMAP","WAVE LINE","WAVE PARAPHONIC","FILTER NOISE",
  "TWIN PEAKS","CLOCK NOISE","CLOUD","PARTICLES","DIGITAL MOD"
};

struct MacroVoice {
  float phase=0, phase2=0, phase3=0, lp=0, feedback=0;
  uint32_t rng=0x9e3779b9u;
  float next(float hz, float sampleRate, int model, float timbre, float color) {
    if (!(sampleRate > 0.f)) return 0.f;
    const float step=std::clamp(hz/sampleRate,0.f,0.45f);
    const float t=clamp01(timbre), c=clamp01(color);
    phase=frac(phase+step);
    phase2=frac(phase2+step*(1.005f+2.995f*t));
    phase3=frac(phase3+step*(0.498f+3.002f*c));
    rng ^= rng<<13; rng ^= rng>>17; rng ^= rng<<5;
    const float noise=(float)((rng>>8)&0xffffu)/32768.f-1.f;
    const float s=sine(phase), sw=saw(phase), tr=tri(phase);
    const float pw=0.05f+0.9f*t;
    float out=0;
    switch (std::clamp(model,0,46)) {
      case 0: out=sw + bipolar(c)*(pulse(phase,0.02f+0.24f*t)-sw)*0.45f; break;
      case 1: out=lerp(tr,lerp(sw,pulse(phase,pw),t),c); break;
      case 2: out=lerp(sw,pulse(phase,pw),c); break;
      case 3: out=fold(lerp(s,tr,c)*(1+6*t)); break;
      case 4: out=sine(phase*(1+std::floor(t*15)))*0.8f; break;
      case 5: out=lerp(pulse(phase,pw),pulse(phase*.5f,pw),c); break;
      case 6: out=lerp(sw,saw(phase*.5f),c); break;
      case 7: case 8: { const float sync=frac(phase*(1+std::floor(t*12))); out=(model==7?pulse(sync,.5f):saw(sync))*(1-c)+s*c; break; }
      case 9: case 10: case 11: case 12: {
        const auto shape=[&](float p) { switch(model) {case 9:return saw(p);case 10:return pulse(p,.5f);case 11:return tri(p);default:return sine(p);} };
        out=(shape(phase)+shape(phase2)+shape(phase3))/3.f; break;
      }
      case 13: out=s*sine(phase2)*sine(phase3); break;
      case 14: {out=0; for(int k=-3;k<=3;++k) out+=saw(phase*(1+0.009f*t*k)); out/=7;break;}
      case 15: out=sw*(0.5f+0.5f*sine(phase2)); break;
      case 16: out=std::round(sw*(2+62*t))/(2+62*t);break;
      case 17: case 18: case 19: case 20: {
        const float a=.004f+.48f*t; lp+=a*(sw-lp);
        if(model==17)out=lp; else if(model==18)out=sw-lp*.6f;
        else if(model==19) out=(sw-lp)*(.4f+.6f*c);
        else out=sw-lp;
        break;
      }
      case 21: case 22: case 23: { const float f=2+16*t; const float env=std::pow(std::max(0.f,1-frac(phase*f)),1+5*c);
        out=env*(sine(phase*f*2)+.4f*sine(phase*f*(3+7*c)));break; }
      case 24: {out=0;for(int k=1;k<=12;++k)out+=sine(phase*k)/(float)k*(.3f+.7f*std::sin(k*c*3.1f)*std::sin(k*c*3.1f));break;}
      case 25: case 26: case 27: {float fb=model==25?0.f:feedback*(model==26?.6f:1.6f);
        out=sine(phase+ (1+12*t)*sine(phase2+fb));feedback=out;break; }
      case 28: case 29: case 30: case 31: {lp+=(.001f+.1f*t)*(noise-lp);out=lerp(s,lp,c);break;}
      case 32: out=(sine(phase)+.7f*sine(phase2)+.5f*sine(phase3))*.45f;break;
      case 33: case 34: out=(sine(phase)*(.5f+.5f*sine(phase2)))*(1-.6f*c);break;
      case 35: case 36: out=noise*(.3f+.7f*std::abs(sine(phase2)));break;
      case 37: case 38: case 39: case 40: out=lerp(sine(phase*(1+int(t*12))),tri(phase*(1+int(c*8))),c);break;
      case 41: case 42: {lp+=(.005f+.25f*t)*(noise-lp);out=model==41?lp:noise-lp;break;}
      case 43: out=std::floor(noise*(2+100*t))/(2+100*t);break;
      case 44: case 45: out=sine(phase2)*(.4f+.6f*noise);break;
      case 46: out=fold(s*(1+15*t)+noise*c);break;
    }
    return std::clamp(out*.65f,-1.f,1.f);
  }
};

// Read-only mono/stereo PCM view. Frames must remain alive during all calls.
struct SampleView {const float* left=nullptr;const float* right=nullptr;int frames=0;};
struct Grain {double position=0;float age=0,length=1,step=1,pan=0;bool active=false;};
struct GranularVoice {
  static constexpr int MAX_GRAINS=32;
  Grain grains[MAX_GRAINS]{};
  uint32_t rng=0x1234567u;
  float phase=0,scan=0;
  float rand01(){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return float(rng&0xffffu)/65535.f;}
  static float read(const float* pcm,int frames,double pos){
    if(!pcm||frames<2)return 0;
    const double p=std::clamp(pos,0.0,double(frames-2));
    const int i=int(p);const float f=float(p-i);return lerp(pcm[i],pcm[i+1],f);
  }
  void reset(){for(auto& g:grains)g=Grain{};phase=scan=0;}
  // position, scatter, size, density, scanSpeed and spread are normalized 0..1.
  // pitch is the source-frame increment per rendered output frame (1 = no transposition).
  void render(const SampleView& src,float sampleRate,float position,float scatter,float size,
              float density,float scanSpeed,float spread,float pitch,float& left,float& right){
    left=right=0;
    if(!src.left || src.frames<2 || sampleRate<=0)return;
    const float length=(.01f+.49f*clamp01(size))*sampleRate;
    const float spawnRate=1.f+79.f*clamp01(density);
    phase+=spawnRate/sampleRate;
    while(phase>=1){
      phase-=1;
      for(auto& g:grains)if(!g.active){
        g.active=true;g.age=0;g.length=length;g.step=std::clamp(pitch,.05f,8.f);
        g.position=std::clamp(double((clamp01(position)+scan+(.5f-rand01())*clamp01(scatter))*src.frames),0.,double(src.frames-2));
        g.pan=bipolar(rand01())*clamp01(spread);break;
      }
    }
    scan=frac(scan+bipolar(scanSpeed)*.1f/sampleRate);
    float normalizer=0;
    for(auto& g:grains)if(g.active){
      const float w=.5f-.5f*std::cos(2*PI*g.age/g.length);
      const float mono=read(src.left,src.frames,g.position);
      const float stereo=read(src.right?src.right:src.left,src.frames,g.position);
      left+=mono*w*(1-g.pan)*.5f;
      right+=stereo*w*(1+g.pan)*.5f;
      normalizer+=w;
      g.position+=g.step;
      g.age++;
      if(g.age>=g.length||g.position>=src.frames-2)g.active=false;
    }
    if(normalizer>1){left/=normalizer;right/=normalizer;}
  }
};
} // namespace pt::synth
